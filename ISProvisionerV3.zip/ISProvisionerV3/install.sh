#!/bin/bash

# ISProvisioner v3.0 Installation Script
# For Ubuntu Server 20.04/22.04/24.04
# Installs Node.js, PostgreSQL, and sets up the application as a systemd service

set -e

echo "======================================"
echo "ISProvisioner v3.0 Installation Script"
echo "======================================"
echo ""

# Check if running as root
if [ "$EUID" -ne 0 ]; then 
  echo "Please run as root (use sudo ./install.sh)"
  exit 1
fi

# Get the real user (not root)
REAL_USER=${SUDO_USER:-$USER}
REAL_HOME=$(getent passwd "$REAL_USER" | cut -d: -f6)

# Configuration
APP_DIR="/opt/isp-provisioner"
APP_USER="isp-provisioner"
DB_NAME="isp_provisioner"
DB_USER="isp_provisioner"
DB_PASSWORD=$(openssl rand -base64 32 | tr -d "=+/" | cut -c1-25)
SESSION_SECRET=$(openssl rand -base64 32)
NODE_VERSION="20"

# Check for non-interactive mode
NON_INTERACTIVE=${NON_INTERACTIVE:-false}

if [ "$NON_INTERACTIVE" != "true" ]; then
  echo "This script will:"
  echo "  1. Install Node.js v${NODE_VERSION}"
  echo "  2. Install PostgreSQL"
  echo "  3. Create database and user"
  echo "  4. Set up ISProvisioner application"
  echo "  5. Configure systemd service"
  echo "  6. Set up network scanning permissions"
  echo ""
  read -p "Continue? (y/n) " -n 1 -r
  echo ""
  if [[ ! $REPLY =~ ^[Yy]$ ]]; then
      echo "Installation cancelled."
      exit 1
  fi
fi

echo ""
echo "[1/8] Updating system packages..."
apt-get update -qq

echo ""
echo "[2/8] Installing Node.js v${NODE_VERSION}..."
# Check if Node.js is installed and meets version requirement
NODE_INSTALLED=false
if command -v node &> /dev/null; then
    CURRENT_NODE_VERSION=$(node --version | cut -d'v' -f2 | cut -d'.' -f1)
    if [ "$CURRENT_NODE_VERSION" -ge "$NODE_VERSION" ]; then
        NODE_INSTALLED=true
        echo "Node.js v$(node --version) already installed"
    else
        echo "Node.js v$(node --version) found but v${NODE_VERSION}+ required. Upgrading..."
    fi
fi

if [ "$NODE_INSTALLED" = false ]; then
    curl -fsSL https://deb.nodesource.com/setup_${NODE_VERSION}.x | sudo -E bash -
    apt-get install -y nodejs
fi
node --version
npm --version

echo ""
echo "[3/8] Installing PostgreSQL..."
if ! command -v psql &> /dev/null; then
    apt-get install -y postgresql postgresql-contrib
fi
systemctl start postgresql
systemctl enable postgresql

echo ""
echo "[4/8] Installing network scanning and discovery tools..."
# Network scanning tools
apt-get install -y nmap arp-scan wireless-tools iw || echo "Some network tools may not be available"

# Bluetooth tools (optional, may not be needed on all servers)
apt-get install -y bluetooth bluez bluez-tools 2>/dev/null || echo "Bluetooth tools installation skipped (optional)"

echo "Network tools installed successfully"

echo ""
echo "[5/8] Configuring PostgreSQL database..."

# Stop any existing connections to the database
echo "Terminating existing database connections..."
sudo -u postgres psql -c "SELECT pg_terminate_backend(pid) FROM pg_stat_activity WHERE datname = '${DB_NAME}';" 2>/dev/null || true

# Drop existing database and user if they exist (outside of functions)
echo "Cleaning up existing database and user..."
sudo -u postgres psql <<EOF 2>/dev/null || true
DROP DATABASE IF EXISTS ${DB_NAME};
DROP ROLE IF EXISTS ${DB_USER};
EOF

# Create fresh database and user
echo "Creating database user and database..."
sudo -u postgres psql <<EOF
CREATE ROLE ${DB_USER} WITH LOGIN PASSWORD '${DB_PASSWORD}';
CREATE DATABASE ${DB_NAME} OWNER ${DB_USER};
GRANT ALL PRIVILEGES ON DATABASE ${DB_NAME} TO ${DB_USER};
EOF

# Grant schema permissions
sudo -u postgres psql -d ${DB_NAME} <<EOF
GRANT ALL ON SCHEMA public TO ${DB_USER};
EOF

echo "Database configured successfully"

echo ""
echo "[6/8] Setting up application..."

# Stop existing service if running
systemctl stop isp-provisioner 2>/dev/null || true

# Create application user
if ! id -u $APP_USER &> /dev/null; then
    useradd -r -s /bin/bash -d $APP_DIR -m $APP_USER
fi

# Backup existing installation
if [ -d "$APP_DIR" ]; then
    BACKUP_DIR="${APP_DIR}.backup.$(date +%Y%m%d_%H%M%S)"
    echo "Backing up existing installation to ${BACKUP_DIR}..."
    mv $APP_DIR $BACKUP_DIR
fi

# Create fresh directory
mkdir -p $APP_DIR

# Copy all files including dotfiles, excluding node_modules and .git
echo "Copying application files to ${APP_DIR}..."
if command -v rsync &> /dev/null; then
    rsync -a --exclude 'node_modules' --exclude '.git' --exclude 'dist' --exclude '*.backup.*' ./ $APP_DIR/
else
    # Fallback if rsync not available
    shopt -s dotglob
    cp -r * $APP_DIR/ 2>/dev/null || true
    shopt -u dotglob
    rm -rf $APP_DIR/node_modules $APP_DIR/.git $APP_DIR/dist 2>/dev/null || true
fi

chown -R $APP_USER:$APP_USER $APP_DIR

# Create .env file
echo "Creating environment configuration..."
cat > $APP_DIR/.env << EOF
# Database Configuration
DATABASE_URL=postgresql://${DB_USER}:${DB_PASSWORD}@127.0.0.1:5432/${DB_NAME}
PGHOST=127.0.0.1
PGPORT=5432
PGUSER=${DB_USER}
PGPASSWORD=${DB_PASSWORD}
PGDATABASE=${DB_NAME}

# Session Configuration
SESSION_SECRET=${SESSION_SECRET}

# Application Configuration
NODE_ENV=production
PORT=5000
EOF

chown $APP_USER:$APP_USER $APP_DIR/.env
chmod 600 $APP_DIR/.env

# Install dependencies
echo "Installing dependencies..."
cd $APP_DIR
sudo -u $APP_USER npm install --legacy-peer-deps

echo "Building application..."
sudo -u $APP_USER npm run build

echo "Running database migrations..."
# Use environment variables from .env file
sudo -u $APP_USER bash -c "source $APP_DIR/.env && cd $APP_DIR && npm run db:push -- --force" || {
  echo "Warning: Migration had issues, trying alternative approach..."
  sudo -u $APP_USER bash -c "export DATABASE_URL=postgresql://${DB_USER}:${DB_PASSWORD}@127.0.0.1:5432/${DB_NAME} && cd $APP_DIR && npm run db:push -- --force"
}

echo "Creating default admin user..."
sudo -u $APP_USER bash -c "export DATABASE_URL=postgresql://${DB_USER}:${DB_PASSWORD}@127.0.0.1:5432/${DB_NAME} && cd $APP_DIR && npx tsx scripts/seed-admin.ts" || {
  echo "Warning: Could not create admin user automatically. You can create it on first login."
}

echo ""
echo "[7/8] Configuring sudo permissions for network scanning..."
# Grant specific sudo permissions for network scanning tools
cat > /etc/sudoers.d/isp-provisioner << EOF
# Allow isp-provisioner user to run network scanning tools without password
${APP_USER} ALL=(ALL) NOPASSWD: /usr/bin/arp-scan
${APP_USER} ALL=(ALL) NOPASSWD: /usr/sbin/arp-scan
${APP_USER} ALL=(ALL) NOPASSWD: /usr/bin/nmap
${APP_USER} ALL=(ALL) NOPASSWD: /usr/local/bin/nmap
${APP_USER} ALL=(ALL) NOPASSWD: /usr/bin/bluetoothctl
${APP_USER} ALL=(ALL) NOPASSWD: /usr/bin/hciconfig
${APP_USER} ALL=(ALL) NOPASSWD: /usr/bin/iwconfig
${APP_USER} ALL=(ALL) NOPASSWD: /sbin/iwconfig
${APP_USER} ALL=(ALL) NOPASSWD: /usr/sbin/ip
${APP_USER} ALL=(ALL) NOPASSWD: /usr/bin/ip
EOF
chmod 440 /etc/sudoers.d/isp-provisioner

echo ""
echo "[8/8] Creating systemd service..."
cat > /etc/systemd/system/isp-provisioner.service << EOF
[Unit]
Description=ISProvisioner v3.0 Network Device Provisioning System
After=network.target postgresql.service
Wants=postgresql.service

[Service]
Type=simple
User=${APP_USER}
WorkingDirectory=${APP_DIR}
ExecStart=/usr/bin/node ${APP_DIR}/dist/index.js
Restart=always
RestartSec=10
StandardOutput=journal
StandardError=journal
SyslogIdentifier=isp-provisioner

# Environment
Environment=NODE_ENV=production
EnvironmentFile=${APP_DIR}/.env

# Security hardening
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=strict
ProtectHome=true
ReadWritePaths=${APP_DIR}

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable isp-provisioner
systemctl start isp-provisioner

# Wait for service to start
echo "Waiting for service to start..."
sleep 3

# Check service status
if systemctl is-active --quiet isp-provisioner; then
    echo "✓ Service started successfully"
else
    echo "⚠ Service may have issues. Check with: journalctl -u isp-provisioner -n 50"
fi

echo ""
echo "======================================"
echo "Installation Complete!"
echo "======================================"
echo ""
echo "Application Details:"
echo "  - Installation directory: ${APP_DIR}"
echo "  - Service name: isp-provisioner"
echo "  - Application URL: http://$(hostname -I | awk '{print $1}'):5000"
echo ""
echo "Database Details:"
echo "  - Database name: ${DB_NAME}"
echo "  - Database user: ${DB_USER}"
echo "  - Database password: ${DB_PASSWORD}"
echo ""
echo "Default Login Credentials:"
echo "  - Username: admin"
echo "  - Password: admin"
echo "  ⚠️  CHANGE THIS PASSWORD IMMEDIATELY AFTER FIRST LOGIN!"
echo ""
echo "Service Commands:"
echo "  - Start:   systemctl start isp-provisioner"
echo "  - Stop:    systemctl stop isp-provisioner"
echo "  - Restart: systemctl restart isp-provisioner"
echo "  - Status:  systemctl status isp-provisioner"
echo "  - Logs:    journalctl -u isp-provisioner -f"
echo ""
echo "Troubleshooting:"
echo "  - View recent logs: journalctl -u isp-provisioner -n 100"
echo "  - Check service status: systemctl status isp-provisioner"
echo "  - Test database connection: sudo -u ${APP_USER} psql -h 127.0.0.1 -U ${DB_USER} -d ${DB_NAME}"
echo ""
echo "IMPORTANT: Save these credentials securely!"
echo "Database password: ${DB_PASSWORD}"
echo ""

# Save credentials to file for reference
cat > $APP_DIR/credentials.txt << EOF
ISProvisioner v3.0 Installation Credentials
Generated: $(date)

Database:
  Name: ${DB_NAME}
  User: ${DB_USER}
  Password: ${DB_PASSWORD}
  Connection: postgresql://${DB_USER}:${DB_PASSWORD}@127.0.0.1:5432/${DB_NAME}

Session Secret: ${SESSION_SECRET}

Application:
  URL: http://$(hostname -I | awk '{print $1}'):5000
  Default Login: admin / admin

Service:
  Name: isp-provisioner
  User: ${APP_USER}
  Directory: ${APP_DIR}
EOF

chown $APP_USER:$APP_USER $APP_DIR/credentials.txt
chmod 600 $APP_DIR/credentials.txt

echo "Credentials saved to: ${APP_DIR}/credentials.txt"
echo ""
echo "Installation complete! ISProvisioner is now running."
echo ""
