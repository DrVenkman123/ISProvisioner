import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Activity, CheckCircle2, Clock, Network, Wifi, Database, FileText, Settings, Trash2 } from "lucide-react";
import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import type { ActivityLog } from "@shared/schema";
import { formatDistanceToNow } from "date-fns";

const eventTypeLabels: Record<string, string> = {
  provision: "Device Provisioned",
  ping: "Ping Test",
  pop_created: "PoP Profile Created",
  pop_updated: "PoP Profile Updated",
  pop_deleted: "PoP Profile Deleted",
  template_created: "Template Created",
  template_updated: "Template Updated",
  template_deleted: "Template Deleted",
  credential_created: "Credential Created",
  credential_updated: "Credential Updated",
  credential_deleted: "Credential Deleted",
};

const eventTypeIcons: Record<string, typeof Network> = {
  provision: Network,
  ping: Wifi,
  pop_created: Database,
  pop_updated: Database,
  pop_deleted: Database,
  template_created: FileText,
  template_updated: FileText,
  template_deleted: Trash2,
  credential_created: Settings,
  credential_updated: Settings,
  credential_deleted: Settings,
};

export default function Dashboard() {
  // Dashboard statistics - showing fresh install state
  const stats = [
    { label: "Total Provisions", value: "0", icon: Network, color: "text-blue-500" },
    { label: "Successful", value: "0", icon: CheckCircle2, color: "text-green-500" },
    { label: "In Progress", value: "0", icon: Clock, color: "text-yellow-500" },
    { label: "Active Devices", value: "0", icon: Activity, color: "text-purple-500" },
  ];

  const { data: activityLogs = [], isLoading: isLoadingActivity, error: activityError } = useQuery<ActivityLog[]>({
    queryKey: ["/api/activity?limit=5"],
  });

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Dashboard</h1>
        <p className="text-muted-foreground mt-1">Overview of your device provisioning activity</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat) => {
          const Icon = stat.icon;
          return (
            <Card key={stat.label}>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">
                  {stat.label}
                </CardTitle>
                <Icon className={`h-5 w-5 ${stat.color}`} />
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold">{stat.value}</div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Quick Actions</CardTitle>
            <CardDescription>Common provisioning tasks</CardDescription>
          </CardHeader>
          <CardContent className="space-y-2">
            <Link href="/provision">
              <Button className="w-full justify-start" variant="outline" data-testid="button-provision-device">
                <Network className="h-4 w-4 mr-2" />
                Provision New Device
              </Button>
            </Link>
            <Link href="/templates">
              <Button className="w-full justify-start" variant="outline" data-testid="button-manage-templates">
                <Activity className="h-4 w-4 mr-2" />
                Manage Templates
              </Button>
            </Link>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Recent Activity</CardTitle>
            <CardDescription>Latest system events</CardDescription>
          </CardHeader>
          <CardContent>
            {isLoadingActivity ? (
              <p className="text-sm text-muted-foreground text-center py-6">Loading activity...</p>
            ) : activityError ? (
              <p className="text-sm text-destructive text-center py-6">
                Error loading activity: {activityError instanceof Error ? activityError.message : "Unknown error"}
              </p>
            ) : activityLogs.length === 0 ? (
              <p className="text-sm text-muted-foreground text-center py-6">No recent activity</p>
            ) : (
              <div className="space-y-3">
                {activityLogs.map((log) => {
                  const Icon = eventTypeIcons[log.eventType] || Activity;
                  const label = eventTypeLabels[log.eventType] || log.eventType;
                  return (
                    <div 
                      key={log.id} 
                      className="flex items-start gap-3 py-2 border-b last:border-0"
                      data-testid={`activity-log-${log.id}`}
                    >
                      <Icon className="h-4 w-4 mt-0.5 text-muted-foreground flex-shrink-0" />
                      <div className="flex-1 min-w-0 space-y-1">
                        <p className="font-medium text-sm">{label}</p>
                        {log.deviceIp ? (
                          <p className="text-xs text-muted-foreground font-mono">{String(log.deviceIp)}</p>
                        ) : null}
                        {log.metadata && typeof log.metadata === "object" && 
                          Object.keys(log.metadata).length > 0 ? (
                          <p className="text-xs text-muted-foreground truncate">
                            {Object.entries(log.metadata as Record<string, unknown>)
                              .filter(([key]) => !["userId", "timestamp"].includes(key))
                              .map(([key, value]) => `${key}: ${String(value)}`)
                              .join(" • ")}
                          </p>
                        ) : null}
                      </div>
                      <div className="text-right flex-shrink-0">
                        <div className={`text-xs font-medium ${
                          log.status === "success" ? "text-green-500" : 
                          log.status === "error" ? "text-red-500" : "text-muted-foreground"
                        }`} data-testid={`activity-status-${log.id}`}>
                          {log.status || "—"}
                        </div>
                        <p className="text-xs text-muted-foreground mt-1">
                          {formatDistanceToNow(new Date(log.createdAt), { addSuffix: true })}
                        </p>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
