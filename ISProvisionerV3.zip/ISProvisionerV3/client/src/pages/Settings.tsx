import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import { Save, Moon, Sun, AlertTriangle } from "lucide-react";
import PopProfileManager, { PopProfile } from "@/components/PopProfileManager";
import DefaultCredentialsManager from "@/components/DefaultCredentialsManager";
import type { DefaultCredential, InsertDefaultCredential } from "@shared/schema";
import DonationLink from "@/components/DonationLink";
import { useToast } from "@/hooks/use-toast";
import { queryClient, apiRequest } from "@/lib/queryClient";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

export default function Settings() {
  const { toast } = useToast();
  const [darkMode, setDarkMode] = useState(false);
  const [autoConnect, setAutoConnect] = useState(true);
  const [sshTimeout, setSshTimeout] = useState("30");
  const [uispKey, setUispKey] = useState("");
  const [provisioningPort, setProvisioningPort] = useState("22");

  // Fetch PoP profiles from backend
  const { data: popProfiles = [] } = useQuery<PopProfile[]>({
    queryKey: ['/api/pop-profiles'],
  });

  // Fetch default credentials from backend
  const { data: credentials = [] } = useQuery<DefaultCredential[]>({
    queryKey: ['/api/credentials'],
  });

  // Fetch settings from backend
  const { data: settings } = useQuery<Record<string, any>>({
    queryKey: ['/api/settings'],
  });

  // Load settings when fetched
  useEffect(() => {
    if (settings) {
      if (settings.darkMode !== undefined) setDarkMode(settings.darkMode);
      if (settings.autoConnect !== undefined) setAutoConnect(settings.autoConnect);
      if (settings.sshTimeout !== undefined) setSshTimeout(settings.sshTimeout);
      if (settings.uispKey !== undefined) setUispKey(settings.uispKey);
      if (settings.provisioningPort !== undefined) setProvisioningPort(settings.provisioningPort);
    }
  }, [settings]);

  // Add PoP profile mutation
  const addProfileMutation = useMutation({
    mutationFn: async (profile: Omit<PopProfile, 'id'>) => {
      const response = await apiRequest('POST', '/api/pop-profiles', profile);
      return await response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/pop-profiles'] });
      toast({
        title: "Success",
        description: "PoP profile added successfully",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to add PoP profile",
        variant: "destructive",
      });
    },
  });

  // Update PoP profile mutation
  const updateProfileMutation = useMutation({
    mutationFn: async ({ id, updates }: { id: string; updates: Partial<PopProfile> }) => {
      const response = await apiRequest('PUT', `/api/pop-profiles/${id}`, updates);
      return await response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/pop-profiles'] });
      toast({
        title: "Success",
        description: "PoP profile updated successfully",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update PoP profile",
        variant: "destructive",
      });
    },
  });

  // Delete PoP profile mutation
  const deleteProfileMutation = useMutation({
    mutationFn: async (id: string) => {
      const response = await apiRequest('DELETE', `/api/pop-profiles/${id}`);
      return await response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/pop-profiles'] });
      toast({
        title: "Success",
        description: "PoP profile deleted successfully",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to delete PoP profile",
        variant: "destructive",
      });
    },
  });

  // Add default credential mutation
  const addCredentialMutation = useMutation({
    mutationFn: async (credential: InsertDefaultCredential) => {
      const response = await apiRequest('POST', '/api/credentials', credential);
      return await response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/credentials'] });
      toast({
        title: "Success",
        description: "Credential added successfully",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to add credential",
        variant: "destructive",
      });
    },
  });

  // Update default credential mutation
  const updateCredentialMutation = useMutation({
    mutationFn: async ({ id, updates }: { id: string; updates: Partial<InsertDefaultCredential> }) => {
      const response = await apiRequest('PUT', `/api/credentials/${id}`, updates);
      return await response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/credentials'] });
      toast({
        title: "Success",
        description: "Credential updated successfully",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update credential",
        variant: "destructive",
      });
    },
  });

  // Delete default credential mutation
  const deleteCredentialMutation = useMutation({
    mutationFn: async (id: string) => {
      const response = await apiRequest('DELETE', `/api/credentials/${id}`);
      return await response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/credentials'] });
      toast({
        title: "Success",
        description: "Credential deleted successfully",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to delete credential",
        variant: "destructive",
      });
    },
  });

  // Save settings mutation
  const saveSettingsMutation = useMutation({
    mutationFn: async (settingsToSave: Record<string, any>) => {
      const promises = Object.entries(settingsToSave).map(async ([key, value]) => {
        const response = await apiRequest('PUT', '/api/settings', { key, value });
        return await response.json();
      });
      return await Promise.all(promises);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/settings'] });
      toast({
        title: "Success",
        description: "Settings saved successfully",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to save settings",
        variant: "destructive",
      });
    },
  });

  // Factory reset mutation
  const factoryResetMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest('POST', '/api/system/factory-reset', {});
      return await response.json();
    },
    onSuccess: () => {
      toast({
        title: "Factory Reset Complete",
        description: "All data cleared. Redirecting to login...",
      });
      // Redirect to login after a brief delay
      setTimeout(() => {
        window.location.href = '/';
      }, 2000);
    },
    onError: (error: any) => {
      toast({
        title: "Factory Reset Failed",
        description: error.message || "Failed to perform factory reset",
        variant: "destructive",
      });
    },
  });

  const handleSave = () => {
    saveSettingsMutation.mutate({
      darkMode,
      autoConnect,
      sshTimeout,
      uispKey,
      provisioningPort,
    });
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Settings</h1>
        <p className="text-muted-foreground mt-1">Manage application preferences and PoP profiles</p>
      </div>

      <PopProfileManager
        profiles={popProfiles}
        onAdd={(profile) => {
          addProfileMutation.mutate(profile);
        }}
        onEdit={(id, updates) => {
          updateProfileMutation.mutate({ id, updates });
        }}
        onDelete={(id) => {
          deleteProfileMutation.mutate(id);
        }}
      />

      <DefaultCredentialsManager
        credentials={credentials}
        onAdd={async (credential) => {
          await addCredentialMutation.mutateAsync(credential);
        }}
        onEdit={async (id, updates) => {
          await updateCredentialMutation.mutateAsync({ id, updates });
        }}
        onDelete={async (id) => {
          await deleteCredentialMutation.mutateAsync(id);
        }}
        isAddPending={addCredentialMutation.isPending}
        isEditPending={updateCredentialMutation.isPending}
        isDeletePending={deleteCredentialMutation.isPending}
      />

      <Card>
        <CardHeader>
          <CardTitle>UISP Configuration</CardTitle>
          <CardDescription>Settings for device adoption and management</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="uisp-key">UISP Adoption Key</Label>
            <Input
              id="uisp-key"
              type="password"
              value={uispKey}
              onChange={(e) => setUispKey(e.target.value)}
              placeholder="Enter your UISP key for auto-adoption"
              data-testid="input-uisp-key"
            />
            <p className="text-xs text-muted-foreground">
              Optional: Used to automatically adopt devices into UISP after provisioning
            </p>
          </div>
          <div className="space-y-2">
            <Label htmlFor="provisioning-port">Provisioning Port</Label>
            <Input
              id="provisioning-port"
              type="number"
              value={provisioningPort}
              onChange={(e) => setProvisioningPort(e.target.value)}
              data-testid="input-provisioning-port"
            />
            <p className="text-xs text-muted-foreground">
              Default SSH port for connecting to devices (usually 22)
            </p>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Connection Settings</CardTitle>
          <CardDescription>Configure SSH connection behavior</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label htmlFor="auto-connect">Auto-connect on Discovery</Label>
              <p className="text-xs text-muted-foreground">
                Automatically connect to devices when discovered
              </p>
            </div>
            <Switch
              id="auto-connect"
              checked={autoConnect}
              onCheckedChange={setAutoConnect}
              data-testid="switch-auto-connect"
            />
          </div>
          <Separator />
          <div className="space-y-2">
            <Label htmlFor="ssh-timeout">SSH Timeout (seconds)</Label>
            <Input
              id="ssh-timeout"
              type="number"
              value={sshTimeout}
              onChange={(e) => setSshTimeout(e.target.value)}
              data-testid="input-ssh-timeout"
            />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Appearance</CardTitle>
          <CardDescription>Customize the look and feel</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label htmlFor="dark-mode">Dark Mode</Label>
              <p className="text-xs text-muted-foreground">
                Enable dark theme for the interface
              </p>
            </div>
            <div className="flex items-center gap-2">
              {darkMode ? <Moon className="h-4 w-4" /> : <Sun className="h-4 w-4" />}
              <Switch
                id="dark-mode"
                checked={darkMode}
                onCheckedChange={setDarkMode}
                data-testid="switch-dark-mode"
              />
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="flex justify-end">
        <Button 
          onClick={handleSave} 
          data-testid="button-save-settings"
          disabled={saveSettingsMutation.isPending}
        >
          <Save className="mr-2 h-4 w-4" />
          {saveSettingsMutation.isPending ? "Saving..." : "Save Settings"}
        </Button>
      </div>

      <Card className="border-destructive">
        <CardHeader>
          <CardTitle className="text-destructive flex items-center gap-2">
            <AlertTriangle className="h-5 w-5" />
            Danger Zone
          </CardTitle>
          <CardDescription>Irreversible system operations</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <h4 className="font-medium">Factory Reset</h4>
            <p className="text-sm text-muted-foreground">
              This will permanently delete all data including:
            </p>
            <ul className="text-sm text-muted-foreground list-disc list-inside space-y-1 ml-2">
              <li>All provisioning history and logs</li>
              <li>All PoP profiles and configuration templates</li>
              <li>All saved favorite devices</li>
              <li>All default credentials</li>
              <li>All system settings</li>
            </ul>
            <p className="text-sm text-muted-foreground mt-2">
              The admin account will be reset to <span className="font-mono font-semibold">admin / admin</span>
            </p>
          </div>
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button 
                variant="destructive" 
                data-testid="button-factory-reset"
                disabled={factoryResetMutation.isPending}
              >
                <AlertTriangle className="mr-2 h-4 w-4" />
                {factoryResetMutation.isPending ? "Resetting..." : "Factory Reset"}
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
                <AlertDialogDescription>
                  This action cannot be undone. This will permanently delete all data from the system and reset the admin credentials to admin/admin.
                  <br /><br />
                  You will be logged out and need to log in again with the default credentials.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel data-testid="button-cancel-factory-reset">Cancel</AlertDialogCancel>
                <AlertDialogAction
                  onClick={() => factoryResetMutation.mutate()}
                  className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                  data-testid="button-confirm-factory-reset"
                >
                  Yes, Reset Everything
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </CardContent>
      </Card>

      <DonationLink />
    </div>
  );
}
