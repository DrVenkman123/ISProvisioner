import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Heart, Plus, Trash2, Edit, Activity, CheckCircle2, XCircle, Loader2 } from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

type FavoriteDevice = {
  id: string;
  name: string;
  ip: string;
  mac?: string;
  hostname?: string;
  deviceType?: string;
  username: string;
  password: string;
  lastPingStatus?: string;
  lastPingTime?: string;
  createdAt: string;
};

export default function Favorites() {
  const { toast } = useToast();
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [editingDevice, setEditingDevice] = useState<FavoriteDevice | null>(null);
  const [formData, setFormData] = useState({
    name: "", ip: "", mac: "", hostname: "", deviceType: "", username: "ubnt", password: "ubnt"
  });

  const { data: favorites = [], isLoading } = useQuery<FavoriteDevice[]>({ queryKey: ["/api/favorites"] });

  const createMutation = useMutation({
    mutationFn: async (data: typeof formData) => {
      const res = await apiRequest('POST', '/api/favorites', data);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/favorites"] });
      setIsAddDialogOpen(false);
      setFormData({ name: "", ip: "", mac: "", hostname: "", deviceType: "", username: "ubnt", password: "ubnt" });
      toast({ title: "Success", description: "Favorite device added" });
    },
  });

  const updateMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: Partial<typeof formData> }) => {
      const res = await apiRequest('PATCH', `/api/favorites/${id}`, data);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/favorites"] });
      setIsEditDialogOpen(false);
      setEditingDevice(null);
      toast({ title: "Success", description: "Favorite device updated" });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      await apiRequest('DELETE', `/api/favorites/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/favorites"] });
      toast({ title: "Success", description: "Favorite device deleted" });
    },
  });

  const pingMutation = useMutation({
    mutationFn: async (id: string) => {
      const res = await apiRequest('POST', `/api/favorites/${id}/ping`);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/favorites"] });
    },
  });

  const handleEdit = (device: FavoriteDevice) => {
    setEditingDevice(device);
    setFormData({
      name: device.name,
      ip: device.ip,
      mac: device.mac || "",
      hostname: device.hostname || "",
      deviceType: device.deviceType || "",
      username: device.username,
      password: device.password,
    });
    setIsEditDialogOpen(true);
  };

  const handleDelete = (id: string, name: string) => {
    if (window.confirm(`Delete favorite device "${name}"?`)) {
      deleteMutation.mutate(id);
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-full">
        <Activity className="w-8 h-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold mb-2" data-testid="text-page-title">Favorite Devices</h1>
          <p className="text-muted-foreground">Monitor and manage your frequently used devices</p>
        </div>
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button data-testid="button-add-favorite">
              <Plus className="h-4 w-4 mr-2" />
              Add Favorite
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Add Favorite Device</DialogTitle>
              <DialogDescription>Add a device to your favorites for quick access and monitoring</DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="name">Name *</Label>
                  <Input id="name" value={formData.name} onChange={(e) => setFormData({...formData, name: e.target.value})} data-testid="input-name" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="ip">IP Address *</Label>
                  <Input id="ip" value={formData.ip} onChange={(e) => setFormData({...formData, ip: e.target.value})} data-testid="input-ip" />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="username">Username</Label>
                  <Input id="username" value={formData.username} onChange={(e) => setFormData({...formData, username: e.target.value})} data-testid="input-username" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="password">Password</Label>
                  <Input id="password" type="password" value={formData.password} onChange={(e) => setFormData({...formData, password: e.target.value})} data-testid="input-password" />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="mac">MAC Address</Label>
                  <Input id="mac" value={formData.mac} onChange={(e) => setFormData({...formData, mac: e.target.value})} data-testid="input-mac" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="hostname">Hostname</Label>
                  <Input id="hostname" value={formData.hostname} onChange={(e) => setFormData({...formData, hostname: e.target.value})} data-testid="input-hostname" />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="deviceType">Device Type</Label>
                <Input id="deviceType" value={formData.deviceType} onChange={(e) => setFormData({...formData, deviceType: e.target.value})} placeholder="e.g., NanoStation, EdgeRouter" data-testid="input-devicetype" />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>Cancel</Button>
              <Button onClick={() => createMutation.mutate(formData)} disabled={!formData.name || !formData.ip || createMutation.isPending} data-testid="button-save-favorite">
                {createMutation.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : "Add Favorite"}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      {favorites.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <Heart className="w-16 h-16 text-muted-foreground mb-4" />
            <p className="text-lg font-medium mb-2">No Favorite Devices</p>
            <p className="text-sm text-muted-foreground mb-4">Add your frequently used devices for quick access</p>
            <Button onClick={() => setIsAddDialogOpen(true)} data-testid="button-add-first">
              <Plus className="h-4 w-4 mr-2" />
              Add Your First Favorite
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {favorites.map((device) => (
            <Card key={device.id} data-testid={`card-favorite-${device.id}`} className="hover-elevate">
              <CardHeader>
                <div className="flex items-start justify-between gap-2">
                  <div className="flex-1 min-w-0">
                    <CardTitle className="text-lg truncate" data-testid={`text-device-name-${device.id}`}>{device.name}</CardTitle>
                    <CardDescription className="font-mono text-xs">{device.ip}</CardDescription>
                  </div>
                  {device.lastPingStatus && (
                    <Badge variant={device.lastPingStatus === 'online' ? 'default' : 'destructive'} className="shrink-0">
                      {device.lastPingStatus === 'online' ? <CheckCircle2 className="h-3 w-3 mr-1" /> : <XCircle className="h-3 w-3 mr-1" />}
                      {device.lastPingStatus}
                    </Badge>
                  )}
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                {device.deviceType && <p className="text-sm text-muted-foreground">Type: {device.deviceType}</p>}
                {device.hostname && <p className="text-sm text-muted-foreground">Hostname: {device.hostname}</p>}
                {device.lastPingTime && (
                  <p className="text-xs text-muted-foreground">
                    Last checked: {new Date(device.lastPingTime).toLocaleString()}
                  </p>
                )}
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" className="flex-1" onClick={() => pingMutation.mutate(device.id)} disabled={pingMutation.isPending} data-testid={`button-ping-${device.id}`}>
                    {pingMutation.isPending ? <Loader2 className="h-3 w-3 animate-spin mr-1" /> : <Activity className="h-3 w-3 mr-1" />}
                    Ping
                  </Button>
                  <Button variant="outline" size="sm" onClick={() => handleEdit(device)} data-testid={`button-edit-${device.id}`}>
                    <Edit className="h-3 w-3" />
                  </Button>
                  <Button variant="outline" size="sm" onClick={() => handleDelete(device.id, device.name)} data-testid={`button-delete-${device.id}`}>
                    <Trash2 className="h-3 w-3" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Favorite Device</DialogTitle>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="edit-name">Name</Label>
                <Input id="edit-name" value={formData.name} onChange={(e) => setFormData({...formData, name: e.target.value})} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-ip">IP Address</Label>
                <Input id="edit-ip" value={formData.ip} onChange={(e) => setFormData({...formData, ip: e.target.value})} />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="edit-username">Username</Label>
                <Input id="edit-username" value={formData.username} onChange={(e) => setFormData({...formData, username: e.target.value})} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-password">Password</Label>
                <Input id="edit-password" type="password" value={formData.password} onChange={(e) => setFormData({...formData, password: e.target.value})} />
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>Cancel</Button>
            <Button onClick={() => editingDevice && updateMutation.mutate({ id: editingDevice.id, data: formData })} disabled={updateMutation.isPending}>
              {updateMutation.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : "Save Changes"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
