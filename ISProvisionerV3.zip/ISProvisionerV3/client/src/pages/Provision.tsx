import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import DeviceSelector, { DeviceType } from "@/components/DeviceSelector";
import DeviceDiscovery, { DiscoveredDevice } from "@/components/DeviceDiscovery";
import DeviceModeSelector, { DeviceMode } from "@/components/DeviceModeSelector";
import ConfigTemplateSelector, { ConfigTemplate } from "@/components/ConfigTemplateSelector";
import DeviceConfigForm from "@/components/DeviceConfigForm";
import AdvancedNetworkConfig, { NetworkConfig } from "@/components/AdvancedNetworkConfig";
import PortGrid, { PortConfig } from "@/components/PortGrid";
import InterfaceConfig, { InterfaceSettings } from "@/components/InterfaceConfig";
import SSHTerminal, { SSHLog } from "@/components/SSHTerminal";
import DeviceStatsCard from "@/components/DeviceStatsCard";
import BulkOperationsPanel from "@/components/BulkOperationsPanel";
import ManualSSHForm, { ManualSSHConnection } from "@/components/ManualSSHForm";
import RadioConfig, { RadioSettings } from "@/components/RadioConfig";
import AirCubeConfig, { AirCubeSettings } from "@/components/AirCubeConfig";
import DonationLink from "@/components/DonationLink";
import { PopProfile } from "@/components/PopProfileManager";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Play, RotateCcw, Server, Users, Activity, CheckCircle2, XCircle } from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

// Device family mapping
const getDeviceFamily = (deviceType: DeviceType | null): string => {
  if (!deviceType) return "airmax";
  if (deviceType.includes("aircube")) return "aircube";
  if (deviceType.includes("edgerouter") || deviceType.includes("edgeswitch")) return "edgemax";
  if (deviceType.includes("uisp-switch")) return "uisp-switch";
  if (deviceType.includes("wave")) return "wave";
  return "airmax"; // NanoStation, NanoBeam, LiteAP
};

export default function Provision() {
  const { toast } = useToast();
  const [mode, setMode] = useState<"single" | "bulk">("single");
  const [isConnected, setIsConnected] = useState(false);
  const [connectedDeviceInfo, setConnectedDeviceInfo] = useState<DiscoveredDevice | null>(null);
  const [selectedDevicesForBulk, setSelectedDevicesForBulk] = useState<DiscoveredDevice[]>([]);
  
  const [selectedDevice, setSelectedDevice] = useState<DeviceType | null>(null);
  const [deviceMode, setDeviceMode] = useState<DeviceMode>(null);
  const [useTemplate, setUseTemplate] = useState(false);
  const [selectedTemplate, setSelectedTemplate] = useState<string | null>(null);
  const [sshStatus, setSshStatus] = useState<"idle" | "connecting" | "executing" | "success" | "error">("idle");
  const [sshLogs, setSshLogs] = useState<SSHLog[]>([]);
  const [provisionJobId, setProvisionJobId] = useState<string | null>(null);
  const [pingStatus, setPingStatus] = useState<"online" | "offline" | null>(null);
  const [pingTime, setPingTime] = useState<Date | null>(null);

  // Fetch templates from backend
  const { data: templates = [] } = useQuery<ConfigTemplate[]>({
    queryKey: ['/api/templates'],
  });

  // Fetch PoP profiles from backend
  const { data: popProfiles = [] } = useQuery<PopProfile[]>({
    queryKey: ['/api/pop-profiles'],
  });

  // Fetch settings for default credentials
  const { data: settings } = useQuery<Record<string, any>>({
    queryKey: ['/api/settings'],
  });

  // Basic config
  const [basicConfig, setBasicConfig] = useState({
    deviceName: "",
    managementIp: "",
    gateway: "",
    dns: "",
    username: "ubnt",
    password: "ubnt",
  });

  // Advanced network config
  const [networkConfig, setNetworkConfig] = useState<NetworkConfig>({
    ipMode: "manual",
    ipVersion: "ipv4",
    staticIp: "",
    netmask: "255.255.255.0",
    gateway: "",
    dns: "8.8.8.8",
    managementVlan: "",
    dataVlans: [],
    mtu: "1500",
    ethernetSpeed: "auto",
    installDate: new Date().toISOString().split('T')[0],
  });

  // Port config for switches
  const [ports, setPorts] = useState<PortConfig[]>(
    Array.from({ length: 8 }, (_, i) => ({
      portNumber: i + 1,
      vlan: "",
      poe: "none" as const,
      active: false,
    }))
  );

  // Interface config for NanoStations
  const [interfaceSettings, setInterfaceSettings] = useState<InterfaceSettings>({
    wlan0: { ssid: "", channel: "36", mode: "ap", enabled: true },
    lan0: { ipAddress: "", subnet: "255.255.255.0", dhcp: false },
    bridge: { enabled: false, interfaces: ["wlan0", "lan0"] },
  });

  // Radio settings for all wireless devices
  const [radioSettings, setRadioSettings] = useState<RadioSettings>({
    ssid: "",
    wpaKey: "",
    frequency: "5180",
    channelWidth: "20",
    txPower: "24",
    eirpLimit: "36",
    beamwidth: "360",
    country: "US",
  });

  // AirCube-specific settings
  const [airCubeSettings, setAirCubeSettings] = useState<AirCubeSettings>({
    poePassthrough: false,
    poeVoltage: "24v",
    wanMode: "dhcp",
    wanStaticIp: "",
    wanGateway: "",
    wanDns: "",
    managementVlan: "",
  });

  // Poll for provision job status
  useEffect(() => {
    if (!provisionJobId) return;

    const interval = setInterval(async () => {
      try {
        const res = await apiRequest('GET', `/api/provision/${provisionJobId}`, undefined);
        const job = await res.json();
        
        if (job.output) {
          const logLines = job.output.split('\n').filter((l: string) => l.trim());
          const parsedLogs: SSHLog[] = logLines.map((line: string) => {
            const timestampMatch = line.match(/\[(.*?)\]/);
            const timestamp = timestampMatch ? timestampMatch[1] : new Date().toLocaleTimeString();
            const message = line.replace(/\[.*?\]\s*/, '');
            
            const type = line.includes('ERROR') ? 'error' 
              : line.includes('SUCCESS') || line.includes('completed') ? 'success' 
              : 'info';
            
            return { timestamp, message, type };
          });
          setSshLogs(parsedLogs);
        }

        if (job.status === "completed") {
          setSshStatus('success');
          clearInterval(interval);
          toast({
            title: "Provision Complete",
            description: "Device has been provisioned successfully",
          });
        } else if (job.status === "failed") {
          setSshStatus('error');
          clearInterval(interval);
          toast({
            title: "Provision Failed",
            description: "An error occurred during provisioning",
            variant: "destructive",
          });
        }
      } catch (error) {
        console.error('Failed to poll job status:', error);
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [provisionJobId, toast]);

  // Provision mutation
  const provisionMutation = useMutation({
    mutationFn: async (config: any) => {
      const res = await apiRequest('POST', '/api/provision', config);
      return await res.json();
    },
    onSuccess: (job: any) => {
      setProvisionJobId(job.id);
      queryClient.invalidateQueries({ queryKey: ['/api/provision'] });
    },
    onError: (error: any) => {
      setSshStatus('error');
      toast({
        title: "Provision Failed",
        description: error.message || "Failed to start provisioning",
        variant: "destructive",
      });
    },
  });

  // Ping mutation
  const pingMutation = useMutation({
    mutationFn: async () => {
      const deviceIp = basicConfig.managementIp || networkConfig.staticIp;
      const res = await apiRequest('POST', '/api/tools/ping', {
        ip: deviceIp,
        port: 22,
        username: basicConfig.username,
        password: basicConfig.password,
      });
      return await res.json();
    },
    onSuccess: (result: { success: boolean }) => {
      const status = result.success ? "online" : "offline";
      setPingStatus(status);
      setPingTime(new Date());
      toast({
        title: result.success ? "Ping Successful" : "Ping Failed",
        description: result.success ? "Device is reachable" : "Device is not reachable",
        variant: result.success ? "default" : "destructive",
      });
    },
    onError: (error: any) => {
      setPingStatus("offline");
      setPingTime(new Date());
      toast({
        title: "Ping Failed",
        description: error.message || "Failed to ping device",
        variant: "destructive",
      });
    },
  });

  const handleProvision = () => {
    const isSwitch = selectedDevice && (selectedDevice.startsWith("uisp-switch") || selectedDevice.startsWith("edgeswitch"));
    
    setSshStatus("connecting");
    setSshLogs([
      { timestamp: new Date().toLocaleTimeString(), message: `Connecting to ${basicConfig.managementIp || networkConfig.staticIp}...`, type: "info" },
    ]);

    const deviceFamily = getDeviceFamily(selectedDevice);
    const sshPort = settings?.provisioningPort ? parseInt(settings.provisioningPort) : 22;

    const config = {
      deviceName: basicConfig.deviceName,
      managementIp: basicConfig.managementIp || networkConfig.staticIp,
      username: basicConfig.username,
      password: basicConfig.password,
      ipMode: networkConfig.ipMode,
      ipVersion: networkConfig.ipVersion || "ipv4",
      staticIp: networkConfig.staticIp,
      netmask: networkConfig.netmask,
      gateway: networkConfig.gateway || basicConfig.gateway,
      dns: networkConfig.dns || basicConfig.dns,
      managementVlan: networkConfig.managementVlan,
      dataVlans: networkConfig.dataVlans,
      mtu: networkConfig.mtu,
      ethernetSpeed: networkConfig.ethernetSpeed,
      installDate: networkConfig.installDate,
      mode: deviceMode,
      ssid: interfaceSettings.wlan0?.ssid || "",
      wpaKey: "", // TODO: Get from PoP profile if needed
      ports: isSwitch ? ports : undefined,
      wlan0: selectedDevice === "nanostation" ? interfaceSettings.wlan0 : undefined,
      lan0: selectedDevice === "nanostation" ? interfaceSettings.lan0 : undefined,
      bridge: selectedDevice === "nanostation" ? interfaceSettings.bridge : undefined,
    };

    provisionMutation.mutate({
      deviceFamily,
      deviceType: selectedDevice,
      deviceIp: basicConfig.managementIp || networkConfig.staticIp,
      sshPort,
      sshUsername: basicConfig.username,
      sshPassword: basicConfig.password,
      useTemplate,
      templateId: useTemplate ? selectedTemplate : undefined,
      config,
    });
  };

  const handleConnect = (device: DiscoveredDevice) => {
    setConnectedDeviceInfo(device);
    setIsConnected(true);
    setPingStatus(null);
    setPingTime(null);
    setBasicConfig(prev => ({
      ...prev,
      managementIp: device.ip,
    }));
    setNetworkConfig(prev => ({
      ...prev,
      staticIp: device.ip,
    }));
  };

  const handleManualConnect = (connection: ManualSSHConnection) => {
    setPingStatus(null);
    setPingTime(null);
    const manualDevice: DiscoveredDevice = {
      ip: connection.ip,
      mac: "00:00:00:00:00:00",
      hostname: connection.ip,
    };
    setConnectedDeviceInfo(manualDevice);
    setIsConnected(true);
    setBasicConfig({
      ...basicConfig,
      managementIp: connection.ip,
      username: connection.username,
      password: connection.password,
    });
    setNetworkConfig(prev => ({
      ...prev,
      staticIp: connection.ip,
    }));
  };

  const handleReset = () => {
    setIsConnected(false);
    setConnectedDeviceInfo(null);
    setSelectedDevice(null);
    setDeviceMode(null);
    setUseTemplate(false);
    setSelectedTemplate(null);
    setSshStatus("idle");
    setSshLogs([]);
    setProvisionJobId(null);
    setPingStatus(null);
    setPingTime(null);
    setBasicConfig({
      deviceName: "",
      managementIp: "",
      gateway: "",
      dns: "",
      username: "ubnt",
      password: "ubnt",
    });
    setNetworkConfig({
      ipMode: "manual",
      ipVersion: "ipv4",
      staticIp: "",
      netmask: "255.255.255.0",
      gateway: "",
      dns: "8.8.8.8",
      managementVlan: "",
      dataVlans: [],
      mtu: "1500",
      ethernetSpeed: "auto",
      installDate: new Date().toISOString().split('T')[0],
    });
  };

  const isRadioDevice = selectedDevice && (
    selectedDevice.includes("nanostation") || 
    selectedDevice.includes("nanobeam") || 
    selectedDevice.includes("liteap") || 
    selectedDevice.includes("litebeam") ||
    selectedDevice.includes("powerbeam") ||
    selectedDevice.includes("wave")
  );
  const isAirCube = selectedDevice && selectedDevice.includes("aircube");
  const isSwitch = selectedDevice && (selectedDevice.startsWith("uisp-switch") || selectedDevice.startsWith("edgeswitch"));
  const showPopSelector = !!(isRadioDevice && deviceMode === "station");
  
  // Determine port count based on switch model
  const getPortCount = (deviceType: DeviceType | null): number => {
    if (!deviceType) return 8;
    if (deviceType.includes("8")) return 8;
    if (deviceType.includes("16")) return 16;
    if (deviceType.includes("24")) return 24;
    if (deviceType.includes("48")) return 48;
    return 8;
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Provision Device</h1>
          <p className="text-muted-foreground mt-1">Connect, configure, and deploy network devices via SSH</p>
        </div>
        <div className="flex items-center gap-3">
          {!isConnected && mode === "single" && (
            <Tabs value={mode} onValueChange={(v) => setMode(v as "single" | "bulk")}>
              <TabsList>
                <TabsTrigger value="single" data-testid="tab-single-mode">
                  <Server className="h-4 w-4 mr-2" />
                  Single Device
                </TabsTrigger>
                <TabsTrigger value="bulk" data-testid="tab-bulk-mode">
                  <Users className="h-4 w-4 mr-2" />
                  Bulk Operations
                </TabsTrigger>
              </TabsList>
            </Tabs>
          )}
          {(isConnected || mode === "bulk") && (
            <Button variant="outline" onClick={handleReset} data-testid="button-reset">
              <RotateCcw className="h-4 w-4 mr-2" />
              {mode === "bulk" ? "Clear & Start Over" : "Start Over"}
            </Button>
          )}
        </div>
      </div>

      {mode === "bulk" ? (
        <>
          <DeviceDiscovery 
            onConnect={() => {}} 
            mode="bulk"
            selectedDevices={selectedDevicesForBulk}
            onSelectionChange={setSelectedDevicesForBulk}
          />
          {selectedDevicesForBulk.length > 0 && (
            <>
              <Separator />
              <BulkOperationsPanel 
                selectedDevices={selectedDevicesForBulk}
                onClearSelection={() => setSelectedDevicesForBulk([])}
              />
            </>
          )}
          <DonationLink />
        </>
      ) : !isConnected ? (
        <>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <ManualSSHForm 
              onConnect={handleManualConnect}
              isConnecting={false}
            />
            <div>
              <DeviceDiscovery onConnect={handleConnect} />
            </div>
          </div>
          <DonationLink />
        </>
      ) : (
        <>
          {connectedDeviceInfo && (
            <>
              <DeviceStatsCard
                deviceIp={connectedDeviceInfo.ip}
                deviceFamily={getDeviceFamily(selectedDevice)}
                sshUsername={basicConfig.username}
                sshPassword={basicConfig.password}
              />
              <Separator />
              
              <div className="flex items-center justify-between p-4 border rounded-lg">
                <div className="flex items-center gap-4">
                  <div>
                    <h3 className="text-sm font-medium">Device Connectivity</h3>
                    <p className="text-xs text-muted-foreground font-mono">
                      {basicConfig.managementIp || networkConfig.staticIp}
                    </p>
                  </div>
                  {pingStatus && (
                    <Badge 
                      variant={pingStatus === 'online' ? 'default' : 'destructive'} 
                      className="shrink-0"
                      data-testid="badge-ping-status"
                    >
                      {pingStatus === 'online' ? <CheckCircle2 className="h-3 w-3 mr-1" /> : <XCircle className="h-3 w-3 mr-1" />}
                      {pingStatus}
                    </Badge>
                  )}
                  {pingTime && (
                    <p className="text-xs text-muted-foreground">
                      Checked: {pingTime.toLocaleTimeString()}
                    </p>
                  )}
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => pingMutation.mutate()}
                  disabled={pingMutation.isPending || !basicConfig.managementIp && !networkConfig.staticIp}
                  data-testid="button-ping-device"
                >
                  {pingMutation.isPending ? (
                    <>
                      <Activity className="h-3 w-3 mr-2 animate-spin" />
                      Testing...
                    </>
                  ) : (
                    <>
                      <Activity className="h-3 w-3 mr-2" />
                      Test Connection
                    </>
                  )}
                </Button>
              </div>
              <Separator />
            </>
          )}
          
          <DeviceSelector
            selectedDevice={selectedDevice}
            onSelectDevice={(device) => {
              setSelectedDevice(device);
              setDeviceMode(null);
            }}
          />

          {selectedDevice && isRadioDevice && !deviceMode && (
        <>
          <Separator />
          <DeviceModeSelector
            selectedMode={deviceMode}
            onSelectMode={setDeviceMode}
          />
        </>
          )}

          {selectedDevice && ((isRadioDevice && deviceMode) || !isRadioDevice) && (
        <>
          <Separator />

          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-lg font-semibold">Configuration Mode</h3>
              <p className="text-sm text-muted-foreground">Use a template or configure manually</p>
            </div>
            <div className="flex items-center gap-2">
              <Label htmlFor="use-template">Use Template</Label>
              <Switch
                id="use-template"
                checked={useTemplate}
                onCheckedChange={setUseTemplate}
                data-testid="switch-use-template"
              />
            </div>
          </div>

          {useTemplate ? (
            <ConfigTemplateSelector
              templates={templates}
              selectedTemplate={selectedTemplate}
              onSelectTemplate={setSelectedTemplate}
              onUploadTemplate={(file) => console.log("Upload:", file)}
              onDeleteTemplate={(id) => console.log("Delete:", id)}
            />
          ) : (
            <div className="space-y-6">
              <DeviceConfigForm
                deviceType={selectedDevice}
                deviceFamily={getDeviceFamily(selectedDevice)}
                config={basicConfig}
                onConfigChange={(key, value) => 
                  setBasicConfig(prev => ({ ...prev, [key]: value }))
                }
              />

              <AdvancedNetworkConfig
                config={networkConfig}
                onChange={setNetworkConfig}
                deviceType={selectedDevice}
                popProfiles={popProfiles}
                showPopSelector={showPopSelector}
              />

              {isRadioDevice && (
                <RadioConfig
                  settings={radioSettings}
                  onChange={setRadioSettings}
                  deviceType={selectedDevice}
                />
              )}

              {isAirCube && (
                <AirCubeConfig
                  settings={airCubeSettings}
                  onChange={setAirCubeSettings}
                />
              )}

              {isSwitch && (
                <PortGrid
                  portCount={getPortCount(selectedDevice)}
                  ports={ports}
                  onConfigurePort={(portNumber, config) => {
                    setPorts(prev => prev.map(p => 
                      p.portNumber === portNumber ? { ...p, ...config } : p
                    ));
                  }}
                />
              )}

              {selectedDevice === "nanostation" && (
                <InterfaceConfig
                  settings={interfaceSettings}
                  onUpdateSettings={setInterfaceSettings}
                />
              )}
            </div>
          )}

          <Separator />

          <SSHTerminal
            logs={sshLogs}
            status={sshStatus}
            deviceIp={basicConfig.managementIp || networkConfig.staticIp}
          />

          <div className="flex justify-end gap-3">
            <Button
              size="lg"
              onClick={handleProvision}
              disabled={sshStatus === "connecting" || sshStatus === "executing" || provisionMutation.isPending}
              data-testid="button-provision"
            >
              <Play className="h-4 w-4 mr-2" />
              {sshStatus === "connecting" || sshStatus === "executing" || provisionMutation.isPending ? "Provisioning..." : "Start Provision"}
            </Button>
          </div>

          <DonationLink />
          </>
        )}
        </>
      )}
    </div>
  );
}
