import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import ConfigTemplateSelector from "@/components/ConfigTemplateSelector";
import type { ConfigTemplate, InsertConfigTemplate } from "@shared/schema";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

const deviceTypes = [
  "NanoStation",
  "NanoBeam",
  "LiteAP",
  "LiteBeam",
  "PowerBeam",
  "AirCube ISP",
  "AirCube AC",
  "UISP Switch",
  "EdgeRouter",
  "Wave AP",
  "Wave Nano",
] as const;

const deviceFamilies = [
  { value: "airmax", label: "airMAX" },
  { value: "aircube", label: "AirCube" },
  { value: "uisp-switch", label: "UISP Switch" },
  { value: "edgemax", label: "EdgeMAX" },
  { value: "wave", label: "Wave" },
] as const;

const editTemplateSchema = z.object({
  name: z.string().min(1, "Name is required"),
  deviceType: z.string().min(1, "Device type is required"),
  deviceFamily: z.string().min(1, "Device family is required"),
});

type EditTemplateForm = z.infer<typeof editTemplateSchema>;

export default function Templates() {
  const { toast } = useToast();
  const [selectedTemplate, setSelectedTemplate] = useState<string | null>(null);
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [editingTemplate, setEditingTemplate] = useState<ConfigTemplate | null>(null);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [deletingTemplate, setDeletingTemplate] = useState<ConfigTemplate | null>(null);

  const handleDeleteDialogChange = (open: boolean) => {
    setDeleteDialogOpen(open);
    if (!open) {
      setDeletingTemplate(null);
    }
  };

  const { data: templates = [], isLoading } = useQuery<ConfigTemplate[]>({
    queryKey: ["/api/templates"],
  });

  const editForm = useForm<EditTemplateForm>({
    resolver: zodResolver(editTemplateSchema),
    defaultValues: {
      name: "",
      deviceType: "",
      deviceFamily: "",
    },
  });

  const uploadMutation = useMutation({
    mutationFn: async (file: File) => {
      const content = await file.text();
      const data: InsertConfigTemplate = {
        name: file.name.replace(/\.(conf|cfg|txt|json)$/, ""),
        deviceType: "Unknown",
        deviceFamily: "airmax",
        content,
      };
      return apiRequest("POST", "/api/templates", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/templates"] });
      toast({
        title: "Success",
        description: "Template uploaded successfully",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to upload template",
        variant: "destructive",
      });
    },
  });

  const editMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: Partial<InsertConfigTemplate> }) => {
      return apiRequest("PUT", `/api/templates/${id}`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/templates"] });
      toast({
        title: "Success",
        description: "Template updated successfully",
      });
      setEditDialogOpen(false);
      setEditingTemplate(null);
      editForm.reset();
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to update template",
        variant: "destructive",
      });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      return apiRequest("DELETE", `/api/templates/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/templates"] });
      toast({
        title: "Success",
        description: "Template deleted successfully",
      });
      if (selectedTemplate) {
        setSelectedTemplate(null);
      }
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to delete template",
        variant: "destructive",
      });
    },
  });

  const handleEditClick = (id: string) => {
    const template = templates.find((t) => t.id === id);
    if (template) {
      setEditingTemplate(template);
      editForm.reset({
        name: template.name,
        deviceType: template.deviceType,
        deviceFamily: template.deviceFamily,
      });
      setEditDialogOpen(true);
    }
  };

  const handleEditSubmit = (data: EditTemplateForm) => {
    if (!editingTemplate) return;
    editMutation.mutate({
      id: editingTemplate.id,
      data: {
        name: data.name,
        deviceType: data.deviceType,
        deviceFamily: data.deviceFamily,
      },
    });
  };

  const handleDeleteClick = (id: string) => {
    const template = templates.find((t) => t.id === id);
    if (template) {
      setDeletingTemplate(template);
      setDeleteDialogOpen(true);
    }
  };

  const handleDeleteConfirm = () => {
    if (!deletingTemplate) return;
    deleteMutation.mutate(deletingTemplate.id);
    setDeleteDialogOpen(false);
    setDeletingTemplate(null);
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Configuration Templates</h1>
        <p className="text-muted-foreground mt-1">
          Manage and organize your device configuration templates
        </p>
      </div>

      <ConfigTemplateSelector
        templates={templates.map((t) => ({
          id: t.id,
          name: t.name,
          deviceType: t.deviceType,
          uploadedAt: t.createdAt instanceof Date 
            ? t.createdAt.toISOString() 
            : new Date(t.createdAt).toISOString(),
        }))}
        selectedTemplate={selectedTemplate}
        onSelectTemplate={setSelectedTemplate}
        onUploadTemplate={(file) => uploadMutation.mutate(file)}
        onEditTemplate={handleEditClick}
        onDeleteTemplate={handleDeleteClick}
      />

      <Dialog open={editDialogOpen} onOpenChange={setEditDialogOpen}>
        <DialogContent data-testid="dialog-edit-template">
          <DialogHeader>
            <DialogTitle>Edit Template</DialogTitle>
            <DialogDescription>
              Update the template metadata. The configuration content cannot be edited.
            </DialogDescription>
          </DialogHeader>
          <Form {...editForm}>
            <form onSubmit={editForm.handleSubmit(handleEditSubmit)} className="space-y-4" data-testid="form-edit-template">
              <FormField
                control={editForm.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Name</FormLabel>
                    <FormControl>
                      <Input {...field} placeholder="Template name" data-testid="input-edit-name" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={editForm.control}
                name="deviceType"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Device Type</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl>
                        <SelectTrigger data-testid="select-edit-device-type">
                          <SelectValue placeholder="Select device type" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {deviceTypes.map((type) => (
                          <SelectItem key={type} value={type} data-testid={`option-device-type-${type}`}>
                            {type}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={editForm.control}
                name="deviceFamily"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Device Family</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl>
                        <SelectTrigger data-testid="select-edit-device-family">
                          <SelectValue placeholder="Select device family" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {deviceFamilies.map((family) => (
                          <SelectItem key={family.value} value={family.value} data-testid={`option-device-family-${family.value}`}>
                            {family.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <DialogFooter>
                <Button
                  type="submit"
                  disabled={editMutation.isPending}
                  data-testid="button-save-edit"
                >
                  {editMutation.isPending ? "Saving..." : "Save Changes"}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      <AlertDialog open={deleteDialogOpen} onOpenChange={handleDeleteDialogChange}>
        <AlertDialogContent data-testid="dialog-delete-template">
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Template</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete "{deletingTemplate?.name}"? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel data-testid="button-cancel-delete">Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDeleteConfirm}
              disabled={deleteMutation.isPending}
              data-testid="button-confirm-delete"
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              {deleteMutation.isPending ? "Deleting..." : "Delete"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
