import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Wifi, Radio, Key, Activity } from "lucide-react";

type PopProfile = {
  id: string;
  name: string;
  ssid: string;
  wpaKey: string;
  beamwidth: number;
  frequency?: string;
  createdAt: string;
};

export default function PopOverview() {
  const { data: popProfiles = [], isLoading, isError, error } = useQuery<PopProfile[]>({
    queryKey: ["/api/pop-profiles"],
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="text-center">
          <Activity className="w-8 h-8 animate-spin mx-auto mb-4 text-muted-foreground" />
          <p className="text-muted-foreground">Loading PoP profiles...</p>
        </div>
      </div>
    );
  }

  if (isError) {
    return (
      <div className="container mx-auto p-6">
        <Card className="border-destructive">
          <CardContent className="flex flex-col items-center justify-center py-12">
            <Activity className="w-16 h-16 text-destructive mb-4" />
            <p className="text-lg font-medium mb-2 text-destructive">Failed to Load PoP Profiles</p>
            <p className="text-sm text-muted-foreground">
              {error instanceof Error ? error.message : "An error occurred while fetching PoP profiles"}
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div>
        <h1 className="text-3xl font-bold mb-2" data-testid="text-page-title">
          PoP Overview
        </h1>
        <p className="text-muted-foreground">
          Point of Presence profiles for network configuration
        </p>
      </div>

      {popProfiles.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <Wifi className="w-16 h-16 text-muted-foreground mb-4" />
            <p className="text-lg font-medium mb-2">No PoP Profiles Found</p>
            <p className="text-sm text-muted-foreground">
              Create PoP profiles to configure network points of presence
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {popProfiles.map((profile) => (
            <Card key={profile.id} data-testid={`card-pop-${profile.id}`} className="hover-elevate">
              <CardHeader>
                <CardTitle className="text-xl mb-2" data-testid={`text-pop-name-${profile.id}`}>
                  {profile.name}
                </CardTitle>
                <CardDescription>
                  Created {new Date(profile.createdAt).toLocaleDateString()}
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <div className="flex items-start gap-3">
                    <Wifi className="w-5 h-5 text-muted-foreground mt-0.5" />
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-muted-foreground">SSID</p>
                      <p className="text-sm font-mono truncate" data-testid={`text-ssid-${profile.id}`}>
                        {profile.ssid}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <Key className="w-5 h-5 text-muted-foreground mt-0.5" />
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-muted-foreground">WPA Key</p>
                      <p className="text-sm font-mono truncate" data-testid={`text-wpakey-${profile.id}`}>
                        {"•".repeat(Math.min(profile.wpaKey.length, 20))}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <Radio className="w-5 h-5 text-muted-foreground mt-0.5" />
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-muted-foreground">Beamwidth</p>
                      <p className="text-sm" data-testid={`text-beamwidth-${profile.id}`}>
                        {profile.beamwidth}°
                      </p>
                    </div>
                  </div>

                  {profile.frequency && (
                    <div className="flex items-start gap-3">
                      <Activity className="w-5 h-5 text-muted-foreground mt-0.5" />
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-muted-foreground">Frequency</p>
                        <p className="text-sm" data-testid={`text-frequency-${profile.id}`}>
                          {profile.frequency}
                        </p>
                      </div>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <Card className="bg-muted/50">
        <CardHeader>
          <CardTitle className="text-lg">Summary</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <p className="text-sm text-muted-foreground">Total PoPs</p>
              <p className="text-2xl font-bold" data-testid="text-total-pops">
                {popProfiles.length}
              </p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Average Beamwidth</p>
              <p className="text-2xl font-bold" data-testid="text-avg-beamwidth">
                {popProfiles.length > 0
                  ? Math.round(popProfiles.reduce((sum, p) => sum + p.beamwidth, 0) / popProfiles.length)
                  : 0}°
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
