import { useState, useEffect } from "react";
import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { ThemeProvider } from "@/components/theme-provider";
import { ThemeToggle } from "@/components/ThemeToggle";
import AppSidebar from "@/components/AppSidebar";
import ConnectionStatus from "@/components/ConnectionStatus";
import LoginForm from "@/components/LoginForm";
import Dashboard from "@/pages/Dashboard";
import Provision from "@/pages/Provision";
import Templates from "@/pages/Templates";
import Settings from "@/pages/Settings";
import Users from "@/pages/Users";
import PopOverview from "@/pages/PopOverview";
import Favorites from "@/pages/Favorites";
import NotFound from "@/pages/not-found";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Dashboard} />
      <Route path="/provision" component={Provision} />
      <Route path="/favorites" component={Favorites} />
      <Route path="/pop-overview" component={PopOverview} />
      <Route path="/templates" component={Templates} />
      <Route path="/settings" component={Settings} />
      <Route path="/users" component={Users} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  // TODO: remove mock functionality - implement real authentication
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [userEmail, setUserEmail] = useState("");
  const [userRole, setUserRole] = useState<"admin" | "tech" | "viewer">("tech");
  
  const [connectionStatus, setConnectionStatus] = useState<"disconnected" | "connecting" | "connected">("disconnected");
  const [connectedDevice, setConnectedDevice] = useState<{ ip?: string; model?: string }>({});

  // Check authentication status on mount
  useEffect(() => {
    const checkAuth = async () => {
      try {
        const response = await fetch('/api/auth/me');
        if (response.ok) {
          const user = await response.json();
          setIsAuthenticated(true);
          setUserEmail(user.username);
          setUserRole(user.role);
        }
      } catch (error) {
        // Not authenticated
        setIsAuthenticated(false);
      }
    };
    checkAuth();
  }, []);

  const handleLogin = async (username: string, password: string) => {
    try {
      const response = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password }),
      });
      
      if (response.ok) {
        const user = await response.json();
        setIsAuthenticated(true);
        setUserEmail(user.username);
        setUserRole(user.role);
      } else {
        const error = await response.json();
        alert(error.error || 'Login failed');
      }
    } catch (error) {
      alert('Login failed');
    }
  };

  const handleRegister = async (username: string, password: string) => {
    try {
      const response = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password }),
      });
      
      if (response.ok) {
        const user = await response.json();
        setIsAuthenticated(true);
        setUserEmail(user.username);
        setUserRole(user.role);
      } else {
        const error = await response.json();
        alert(error.error || 'Registration failed');
      }
    } catch (error) {
      alert('Registration failed');
    }
  };

  const handleLogout = async () => {
    try {
      await fetch('/api/auth/logout', { method: 'POST' });
      setIsAuthenticated(false);
      setUserEmail("");
      setUserRole("tech");
    } catch (error) {
      console.error('Logout error:', error);
    }
  };

  if (!isAuthenticated) {
    return (
      <ThemeProvider defaultTheme="system">
        <QueryClientProvider client={queryClient}>
          <TooltipProvider>
            <LoginForm onLogin={handleLogin} onRegister={handleRegister} />
            <Toaster />
          </TooltipProvider>
        </QueryClientProvider>
      </ThemeProvider>
    );
  }

  const style = {
    "--sidebar-width": "280px",
    "--sidebar-width-icon": "4rem",
  };

  return (
    <ThemeProvider defaultTheme="system">
      <QueryClientProvider client={queryClient}>
        <TooltipProvider>
          <SidebarProvider style={style as React.CSSProperties}>
            <div className="flex h-screen w-full">
              <AppSidebar
                userRole={userRole}
                userEmail={userEmail}
                onLogout={handleLogout}
              />
              <div className="flex flex-col flex-1 overflow-hidden">
                <header className="flex items-center justify-between px-6 py-3 border-b bg-background">
                  <SidebarTrigger data-testid="button-sidebar-toggle" />
                  <div className="flex items-center gap-4">
                    <ConnectionStatus
                      status={connectionStatus}
                      deviceIp={connectedDevice.ip}
                      deviceModel={connectedDevice.model}
                    />
                    <ThemeToggle />
                  </div>
                </header>
                <main className="flex-1 overflow-auto p-6">
                  <Router />
                </main>
                <footer className="flex items-center justify-center px-6 py-3 border-t bg-background text-sm text-muted-foreground">
                  <span>ISProvisioner v3.0</span>
                  <span className="mx-2">•</span>
                  <span>Support this project: <a href="https://cash.app/$EricElston123" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline" data-testid="link-donation">CashApp $EricElston123</a></span>
                </footer>
              </div>
            </div>
          </SidebarProvider>
          <Toaster />
        </TooltipProvider>
      </QueryClientProvider>
    </ThemeProvider>
  );
}

export default App;
