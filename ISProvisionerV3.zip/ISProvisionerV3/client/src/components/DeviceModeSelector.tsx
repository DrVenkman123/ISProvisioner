import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Radio, Wifi } from "lucide-react";

export type DeviceMode = "ap" | "station" | null;

interface DeviceModeSelectorProps {
  selectedMode: DeviceMode;
  onSelectMode: (mode: DeviceMode) => void;
}

export default function DeviceModeSelector({ selectedMode, onSelectMode }: DeviceModeSelectorProps) {
  return (
    <div className="space-y-4">
      <div>
        <h3 className="text-xl font-semibold mb-2">Device Mode</h3>
        <p className="text-sm text-muted-foreground">Select whether this device will be an Access Point or Station</p>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card
          className={`cursor-pointer transition-all hover-elevate ${
            selectedMode === "ap" ? "ring-2 ring-primary" : ""
          }`}
          onClick={() => onSelectMode("ap")}
          data-testid="card-mode-ap"
        >
          <CardHeader>
            <div className="flex items-center justify-between">
              <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center">
                <Radio className="h-6 w-6 text-primary" />
              </div>
              {selectedMode === "ap" && (
                <div className="h-2 w-2 rounded-full bg-primary" data-testid="indicator-ap" />
              )}
            </div>
          </CardHeader>
          <CardContent>
            <CardTitle className="text-lg mb-2">Access Point (AP)</CardTitle>
            <CardDescription>
              Broadcasts wireless network for clients to connect to
            </CardDescription>
          </CardContent>
        </Card>

        <Card
          className={`cursor-pointer transition-all hover-elevate ${
            selectedMode === "station" ? "ring-2 ring-primary" : ""
          }`}
          onClick={() => onSelectMode("station")}
          data-testid="card-mode-station"
        >
          <CardHeader>
            <div className="flex items-center justify-between">
              <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center">
                <Wifi className="h-6 w-6 text-primary" />
              </div>
              {selectedMode === "station" && (
                <div className="h-2 w-2 rounded-full bg-primary" data-testid="indicator-station" />
              )}
            </div>
          </CardHeader>
          <CardContent>
            <CardTitle className="text-lg mb-2">Station (STA)</CardTitle>
            <CardDescription>
              Connects to an existing wireless network as a client
            </CardDescription>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
