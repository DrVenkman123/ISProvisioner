import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";

export interface PortConfig {
  portNumber: number;
  vlan: string;
  poe: "24v-2pair" | "24v-4pair" | "none";
  active: boolean;
}

interface PortGridProps {
  portCount: number;
  ports: PortConfig[];
  onConfigurePort: (portNumber: number, config: Partial<PortConfig>) => void;
}

export default function PortGrid({ portCount, ports, onConfigurePort }: PortGridProps) {
  const [selectedPort, setSelectedPort] = useState<number | null>(null);
  const [editVlan, setEditVlan] = useState("");
  const [editPoe, setEditPoe] = useState<"24v-2pair" | "24v-4pair" | "none">("none");

  const openPortConfig = (portNumber: number) => {
    const port = ports.find(p => p.portNumber === portNumber);
    if (port) {
      setEditVlan(port.vlan);
      setEditPoe(port.poe);
    }
    setSelectedPort(portNumber);
  };

  const savePortConfig = () => {
    if (selectedPort !== null) {
      onConfigurePort(selectedPort, { vlan: editVlan, poe: editPoe });
      setSelectedPort(null);
    }
  };

  const cols = portCount <= 8 ? portCount : portCount <= 24 ? 12 : 16;

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-xl font-semibold mb-2">Switch Port Configuration</h3>
        <p className="text-sm text-muted-foreground">Click on a port to configure VLAN and PoE settings</p>
      </div>

      <div
        className="grid gap-2"
        style={{ gridTemplateColumns: `repeat(${cols}, minmax(0, 1fr))` }}
      >
        {Array.from({ length: portCount }, (_, i) => {
          const portNumber = i + 1;
          const port = ports.find(p => p.portNumber === portNumber);
          const isActive = port?.active || false;
          
          return (
            <button
              key={portNumber}
              onClick={() => openPortConfig(portNumber)}
              className="aspect-square rounded-lg border-2 bg-card hover-elevate active-elevate-2 relative flex flex-col items-center justify-center gap-1 p-2"
              data-testid={`button-port-${portNumber}`}
            >
              <span className="absolute top-1 left-1 text-xs font-mono text-muted-foreground">
                {portNumber}
              </span>
              {isActive && (
                <div className="absolute top-1 right-1 h-2 w-2 rounded-full bg-green-500" />
              )}
              <div className="text-xs font-medium text-center">
                {port?.vlan ? `V${port.vlan}` : "—"}
              </div>
              {port?.poe && port.poe !== "none" && (
                <Badge variant="secondary" className="text-[10px] px-1 py-0 h-4">
                  PoE
                </Badge>
              )}
            </button>
          );
        })}
      </div>

      <Dialog open={selectedPort !== null} onOpenChange={(open) => !open && setSelectedPort(null)}>
        <DialogContent data-testid="dialog-port-config">
          <DialogHeader>
            <DialogTitle>Configure Port {selectedPort}</DialogTitle>
            <DialogDescription>Set VLAN and PoE settings for this port</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="vlan">VLAN ID</Label>
              <Input
                id="vlan"
                placeholder="e.g., 10"
                value={editVlan}
                onChange={(e) => setEditVlan(e.target.value)}
                data-testid="input-vlan"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="poe">PoE Power</Label>
              <Select value={editPoe} onValueChange={(val) => setEditPoe(val as any)}>
                <SelectTrigger id="poe" data-testid="select-poe">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">None</SelectItem>
                  <SelectItem value="24v-2pair">24V 2-Pair</SelectItem>
                  <SelectItem value="24v-4pair">24V 4-Pair</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setSelectedPort(null)} data-testid="button-cancel">
              Cancel
            </Button>
            <Button onClick={savePortConfig} data-testid="button-save">
              Apply
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
