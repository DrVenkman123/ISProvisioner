import { useState } from "react";
import InterfaceConfig, { InterfaceSettings } from "../InterfaceConfig";

export default function InterfaceConfigExample() {
  const [settings, setSettings] = useState<InterfaceSettings>({
    wlan0: {
      ssid: "ISP-Network",
      channel: "36",
      mode: "ap",
      enabled: true,
    },
    lan0: {
      ipAddress: "192.168.1.1",
      subnet: "255.255.255.0",
      dhcp: true,
    },
    bridge: {
      enabled: false,
      interfaces: ["wlan0", "lan0"],
    },
  });

  return (
    <div className="p-6">
      <InterfaceConfig
        settings={settings}
        onUpdateSettings={(newSettings) => {
          setSettings(newSettings);
          console.log("Settings updated:", newSettings);
        }}
      />
    </div>
  );
}
