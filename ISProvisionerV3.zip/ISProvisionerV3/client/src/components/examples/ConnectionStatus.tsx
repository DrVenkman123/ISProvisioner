import ConnectionStatus from "../ConnectionStatus";

export default function ConnectionStatusExample() {
  return (
    <div className="p-6 space-y-4">
      <div className="p-4 bg-card rounded-lg border">
        <p className="text-sm text-muted-foreground mb-3">Connecting State:</p>
        <ConnectionStatus status="connecting" deviceIp="192.168.1.20" />
      </div>
      <div className="p-4 bg-card rounded-lg border">
        <p className="text-sm text-muted-foreground mb-3">Connected State:</p>
        <ConnectionStatus status="connected" deviceIp="192.168.1.20" deviceModel="NanoStation 5AC" />
      </div>
      <div className="p-4 bg-card rounded-lg border">
        <p className="text-sm text-muted-foreground mb-3">Disconnected State (nothing shown):</p>
        <ConnectionStatus status="disconnected" />
      </div>
    </div>
  );
}
