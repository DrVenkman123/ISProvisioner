import LoginForm from "../LoginForm";

export default function LoginFormExample() {
  return (
    <LoginForm
      onLogin={(email, password) => console.log("Login:", email, password)}
      onRegister={(email, password) => console.log("Register:", email, password)}
    />
  );
}
