import { useState } from "react";
import DeviceSelector, { DeviceType } from "../DeviceSelector";

export default function DeviceSelectorExample() {
  const [selected, setSelected] = useState<DeviceType | null>(null);
  
  return (
    <div className="p-6">
      <DeviceSelector
        selectedDevice={selected}
        onSelectDevice={(device) => {
          setSelected(device);
          console.log("Selected device:", device);
        }}
      />
    </div>
  );
}
