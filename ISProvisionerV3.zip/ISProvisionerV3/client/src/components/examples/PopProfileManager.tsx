import { useState } from "react";
import PopProfileManager, { PopProfile } from "../PopProfileManager";

export default function PopProfileManagerExample() {
  const [profiles, setProfiles] = useState<PopProfile[]>([
    { id: "1", name: "Tower 95", ssid: "WISPerNet-95", wpaKey: "secret123", beamwidth: 90, frequency: "5GHz" },
    { id: "2", name: "EE Row", ssid: "WISPerNet-EE", wpaKey: "secret456", beamwidth: 60, frequency: "5GHz" },
  ]);

  return (
    <div className="p-6 max-w-4xl">
      <PopProfileManager
        profiles={profiles}
        onAdd={(profile) => {
          const newProfile = { ...profile, id: String(profiles.length + 1) };
          setProfiles([...profiles, newProfile]);
          console.log("Added PoP:", newProfile);
        }}
        onEdit={(id, updates) => {
          setProfiles(profiles.map(p => p.id === id ? { ...p, ...updates } : p));
          console.log("Edited PoP:", id, updates);
        }}
        onDelete={(id) => {
          setProfiles(profiles.filter(p => p.id !== id));
          console.log("Deleted PoP:", id);
        }}
      />
    </div>
  );
}
