import { useState } from "react";
import ConfigTemplateSelector, { ConfigTemplate } from "../ConfigTemplateSelector";

export default function ConfigTemplateSelectorExample() {
  const [templates, setTemplates] = useState<ConfigTemplate[]>([
    {
      id: "1",
      name: "NanoStation Default",
      deviceType: "NanoStation",
      uploadedAt: "2025-01-15T10:30:00Z",
    },
    {
      id: "2",
      name: "AirCube ISP Config",
      deviceType: "AirCube ISP",
      uploadedAt: "2025-01-20T14:22:00Z",
    },
    {
      id: "3",
      name: "Switch VLAN Setup",
      deviceType: "UISP Switch",
      uploadedAt: "2025-01-25T09:15:00Z",
    },
  ]);
  const [selected, setSelected] = useState<string | null>(null);

  return (
    <div className="p-6">
      <ConfigTemplateSelector
        templates={templates}
        selectedTemplate={selected}
        onSelectTemplate={setSelected}
        onUploadTemplate={(file) => {
          console.log("Upload file:", file.name);
          const newTemplate: ConfigTemplate = {
            id: String(templates.length + 1),
            name: file.name,
            deviceType: "Unknown",
            uploadedAt: new Date().toISOString(),
          };
          setTemplates([...templates, newTemplate]);
        }}
        onDeleteTemplate={(id) => {
          setTemplates(templates.filter((t) => t.id !== id));
          if (selected === id) setSelected(null);
          console.log("Delete template:", id);
        }}
      />
    </div>
  );
}
