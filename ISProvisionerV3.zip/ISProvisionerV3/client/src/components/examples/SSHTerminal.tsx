import SSHTerminal, { SSHLog } from "../SSHTerminal";

export default function SSHTerminalExample() {
  const logs: SSHLog[] = [
    { timestamp: "14:32:01", message: "Connecting to 192.168.1.20...", type: "info" },
    { timestamp: "14:32:02", message: "SSH connection established", type: "success" },
    { timestamp: "14:32:03", message: "Authenticating...", type: "info" },
    { timestamp: "14:32:04", message: "Authentication successful", type: "success" },
    { timestamp: "14:32:05", message: "Executing configuration commands...", type: "info" },
    { timestamp: "14:32:06", message: "Setting SSID to 'ISP-Network'", type: "info" },
    { timestamp: "14:32:07", message: "Configuring IP address", type: "info" },
    { timestamp: "14:32:08", message: "Applying changes...", type: "info" },
    { timestamp: "14:32:10", message: "Configuration applied successfully", type: "success" },
    { timestamp: "14:32:11", message: "Device ready for deployment", type: "success" },
  ];

  return (
    <div className="p-6">
      <SSHTerminal
        logs={logs}
        status="success"
        deviceIp="192.168.1.20"
      />
    </div>
  );
}
