import { useState } from "react";
import PortGrid, { PortConfig } from "../PortGrid";

export default function PortGridExample() {
  const [ports, setPorts] = useState<PortConfig[]>([
    { portNumber: 1, vlan: "10", poe: "24v-2pair", active: true },
    { portNumber: 2, vlan: "10", poe: "none", active: false },
    { portNumber: 3, vlan: "20", poe: "24v-4pair", active: true },
    { portNumber: 4, vlan: "", poe: "none", active: false },
    { portNumber: 5, vlan: "", poe: "none", active: false },
    { portNumber: 6, vlan: "", poe: "none", active: false },
    { portNumber: 7, vlan: "", poe: "none", active: false },
    { portNumber: 8, vlan: "", poe: "none", active: false },
  ]);

  const handleConfigurePort = (portNumber: number, config: Partial<PortConfig>) => {
    setPorts(prev => prev.map(p => 
      p.portNumber === portNumber ? { ...p, ...config } : p
    ));
    console.log(`Port ${portNumber} configured:`, config);
  };

  return (
    <div className="p-6">
      <PortGrid
        portCount={8}
        ports={ports}
        onConfigurePort={handleConfigurePort}
      />
    </div>
  );
}
