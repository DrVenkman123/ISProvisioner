import { useState } from "react";
import DeviceConfigForm from "../DeviceConfigForm";

export default function DeviceConfigFormExample() {
  const [config, setConfig] = useState({
    deviceName: "ap-office-1",
    managementIp: "192.168.1.20",
    gateway: "192.168.1.1",
    dns: "8.8.8.8",
    username: "admin",
    password: "",
  });

  return (
    <div className="p-6">
      <DeviceConfigForm
        deviceType="NanoStation"
        config={config}
        onConfigChange={(key, value) => {
          setConfig({ ...config, [key]: value });
          console.log(`Config updated: ${key} = ${value}`);
        }}
      />
    </div>
  );
}
