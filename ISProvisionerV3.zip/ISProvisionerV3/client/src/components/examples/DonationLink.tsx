import DonationLink from "../DonationLink";

export default function DonationLinkExample() {
  return (
    <div className="p-6 max-w-2xl">
      <DonationLink />
    </div>
  );
}
