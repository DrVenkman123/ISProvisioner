import { useState } from "react";
import DeviceModeSelector, { DeviceMode } from "../DeviceModeSelector";

export default function DeviceModeSelectorExample() {
  const [mode, setMode] = useState<DeviceMode>(null);

  return (
    <div className="p-6">
      <DeviceModeSelector
        selectedMode={mode}
        onSelectMode={(newMode) => {
          setMode(newMode);
          console.log("Selected mode:", newMode);
        }}
      />
    </div>
  );
}
