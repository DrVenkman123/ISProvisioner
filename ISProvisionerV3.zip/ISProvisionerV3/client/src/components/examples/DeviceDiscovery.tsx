import { useState } from "react";
import DeviceDiscovery, { DiscoveredDevice } from "../DeviceDiscovery";

export default function DeviceDiscoveryExample() {
  const [isScanning, setIsScanning] = useState(false);
  const [devices] = useState<DiscoveredDevice[]>([
    { ip: "192.168.1.20", mac: "F0:9F:C2:AA:BB:CC", hostname: "nanostation-5ac", model: "NanoStation 5AC", method: "lan" },
    { ip: "192.168.1.30", mac: "F0:9F:C2:DD:EE:FF", hostname: "aircube-ac", model: "AirCube AC", method: "lan" },
    { ip: "192.168.1.40", mac: "F0:9F:C2:11:22:33", model: "Wave AP", method: "bluetooth" },
  ]);

  return (
    <div className="p-6 max-w-4xl">
      <DeviceDiscovery
        isScanning={isScanning}
        discoveredDevices={devices}
        onConnect={(device) => {
          console.log("Connect to device:", device);
          alert(`Connecting to ${device.ip}...`);
        }}
      />
    </div>
  );
}
