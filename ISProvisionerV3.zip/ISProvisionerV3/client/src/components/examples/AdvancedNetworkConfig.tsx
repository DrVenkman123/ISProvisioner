import { useState } from "react";
import AdvancedNetworkConfig, { NetworkConfig } from "../AdvancedNetworkConfig";
import { PopProfile } from "../PopProfileManager";

export default function AdvancedNetworkConfigExample() {
  const [config, setConfig] = useState<NetworkConfig>({
    ipMode: "manual",
    staticIp: "192.168.1.20",
    netmask: "255.255.255.0",
    gateway: "192.168.1.1",
    dns: "8.8.8.8",
    managementVlan: "100",
    dataVlans: ["10", "20"],
    mtu: "1500",
    ethernetSpeed: "auto",
    installDate: new Date().toISOString().split('T')[0],
  });

  const popProfiles: PopProfile[] = [
    { id: "1", name: "Tower 95", ssid: "WISPerNet-95", wpaKey: "secret", beamwidth: 90 },
    { id: "2", name: "EE Row", ssid: "WISPerNet-EE", wpaKey: "secret", beamwidth: 60 },
  ];

  return (
    <div className="p-6 max-w-4xl">
      <AdvancedNetworkConfig
        config={config}
        onChange={(newConfig) => {
          setConfig(newConfig);
          console.log("Config updated:", newConfig);
        }}
        deviceType="NanoStation"
        popProfiles={popProfiles}
      />
    </div>
  );
}
