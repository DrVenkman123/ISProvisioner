import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { FileText, Upload, Download, Trash2, Edit } from "lucide-react";

export interface ConfigTemplate {
  id: string;
  name: string;
  deviceType: string;
  uploadedAt: string;
}

interface ConfigTemplateSelectorProps {
  templates: ConfigTemplate[];
  selectedTemplate: string | null;
  onSelectTemplate: (templateId: string | null) => void;
  onUploadTemplate: (file: File) => void;
  onDeleteTemplate: (templateId: string) => void;
  onEditTemplate?: (templateId: string) => void;
}

export default function ConfigTemplateSelector({
  templates,
  selectedTemplate,
  onSelectTemplate,
  onUploadTemplate,
  onDeleteTemplate,
  onEditTemplate,
}: ConfigTemplateSelectorProps) {
  const [uploadMode, setUploadMode] = useState(false);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      onUploadTemplate(file);
      setUploadMode(false);
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-xl font-semibold">Configuration Templates</h3>
          <p className="text-sm text-muted-foreground">Use a saved template or upload a new one</p>
        </div>
        <Button
          variant="outline"
          onClick={() => setUploadMode(!uploadMode)}
          data-testid="button-upload-toggle"
        >
          <Upload className="h-4 w-4 mr-2" />
          Upload
        </Button>
      </div>

      {uploadMode && (
        <Card>
          <CardContent className="pt-6">
            <div className="space-y-2">
              <Label htmlFor="file-upload">Upload Configuration File</Label>
              <Input
                id="file-upload"
                type="file"
                accept=".conf,.cfg,.txt,.json"
                onChange={handleFileUpload}
                data-testid="input-file"
              />
            </div>
          </CardContent>
        </Card>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {templates.length === 0 ? (
          <Card className="col-span-full">
            <CardContent className="flex flex-col items-center justify-center py-12 text-center">
              <FileText className="h-12 w-12 text-muted-foreground mb-4" />
              <p className="text-muted-foreground">No templates uploaded yet</p>
              <p className="text-sm text-muted-foreground mt-1">Upload a configuration file to get started</p>
            </CardContent>
          </Card>
        ) : (
          templates.map((template) => {
            const isSelected = selectedTemplate === template.id;
            return (
              <Card
                key={template.id}
                className={`cursor-pointer transition-all hover-elevate ${
                  isSelected ? "ring-2 ring-primary" : ""
                }`}
                onClick={() => onSelectTemplate(isSelected ? null : template.id)}
                data-testid={`card-template-${template.id}`}
              >
                <CardHeader>
                  <div className="flex items-start justify-between gap-2">
                    <FileText className="h-5 w-5 text-primary flex-shrink-0 mt-1" />
                    <div className="flex-1 min-w-0">
                      <CardTitle className="text-base truncate">{template.name}</CardTitle>
                      <CardDescription className="text-xs mt-1">
                        Uploaded {new Date(template.uploadedAt).toLocaleDateString()}
                      </CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center justify-between">
                    <Badge variant="secondary">{template.deviceType}</Badge>
                    <div className="flex gap-1">
                      {onEditTemplate && (
                        <Button
                          size="icon"
                          variant="ghost"
                          className="h-8 w-8"
                          onClick={(e) => {
                            e.stopPropagation();
                            onEditTemplate(template.id);
                          }}
                          data-testid={`button-edit-${template.id}`}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                      )}
                      <Button
                        size="icon"
                        variant="ghost"
                        className="h-8 w-8"
                        onClick={(e) => {
                          e.stopPropagation();
                          console.log("Download template:", template.id);
                        }}
                        data-testid={`button-download-${template.id}`}
                      >
                        <Download className="h-4 w-4" />
                      </Button>
                      <Button
                        size="icon"
                        variant="ghost"
                        className="h-8 w-8 text-destructive hover:text-destructive"
                        onClick={(e) => {
                          e.stopPropagation();
                          onDeleteTemplate(template.id);
                        }}
                        data-testid={`button-delete-${template.id}`}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })
        )}
      </div>
    </div>
  );
}
