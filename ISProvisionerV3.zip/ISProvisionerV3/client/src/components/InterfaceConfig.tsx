import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";

export interface InterfaceSettings {
  wlan0: {
    ssid: string;
    channel: string;
    mode: "ap" | "station";
    enabled: boolean;
  };
  lan0: {
    ipAddress: string;
    subnet: string;
    dhcp: boolean;
  };
  bridge: {
    enabled: boolean;
    interfaces: string[];
  };
}

interface InterfaceConfigProps {
  settings: InterfaceSettings;
  onUpdateSettings: (settings: InterfaceSettings) => void;
}

export default function InterfaceConfig({ settings, onUpdateSettings }: InterfaceConfigProps) {
  const [config, setConfig] = useState(settings);

  const updateWlan0 = (updates: Partial<typeof config.wlan0>) => {
    const newConfig = { ...config, wlan0: { ...config.wlan0, ...updates } };
    setConfig(newConfig);
    onUpdateSettings(newConfig);
  };

  const updateLan0 = (updates: Partial<typeof config.lan0>) => {
    const newConfig = { ...config, lan0: { ...config.lan0, ...updates } };
    setConfig(newConfig);
    onUpdateSettings(newConfig);
  };

  const updateBridge = (updates: Partial<typeof config.bridge>) => {
    const newConfig = { ...config, bridge: { ...config.bridge, ...updates } };
    setConfig(newConfig);
    onUpdateSettings(newConfig);
  };

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-xl font-semibold mb-2">Advanced Routing Configuration</h3>
        <p className="text-sm text-muted-foreground">Configure WLAN0, LAN0, and Bridge mode for NanoStation</p>
      </div>

      <Tabs defaultValue="wlan0" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="wlan0" data-testid="tab-wlan0">WLAN0</TabsTrigger>
          <TabsTrigger value="lan0" data-testid="tab-lan0">LAN0</TabsTrigger>
          <TabsTrigger value="bridge" data-testid="tab-bridge">Bridge</TabsTrigger>
        </TabsList>

        <TabsContent value="wlan0" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Wireless Interface (WLAN0)</CardTitle>
              <CardDescription>Configure wireless settings</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <Label htmlFor="wlan-enabled">Enable Interface</Label>
                <Switch
                  id="wlan-enabled"
                  checked={config.wlan0.enabled}
                  onCheckedChange={(enabled) => updateWlan0({ enabled })}
                  data-testid="switch-wlan-enabled"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="ssid">SSID</Label>
                <Input
                  id="ssid"
                  value={config.wlan0.ssid}
                  onChange={(e) => updateWlan0({ ssid: e.target.value })}
                  placeholder="Network name"
                  data-testid="input-ssid"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="mode">Mode</Label>
                <Select value={config.wlan0.mode} onValueChange={(mode: any) => updateWlan0({ mode })}>
                  <SelectTrigger id="mode" data-testid="select-mode">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="ap">Access Point</SelectItem>
                    <SelectItem value="station">Station</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="channel">Channel</Label>
                <Input
                  id="channel"
                  value={config.wlan0.channel}
                  onChange={(e) => updateWlan0({ channel: e.target.value })}
                  placeholder="e.g., 36"
                  data-testid="input-channel"
                />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="lan0" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Ethernet Interface (LAN0)</CardTitle>
              <CardDescription>Configure wired network settings</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="ip">IP Address</Label>
                <Input
                  id="ip"
                  value={config.lan0.ipAddress}
                  onChange={(e) => updateLan0({ ipAddress: e.target.value })}
                  placeholder="192.168.1.1"
                  data-testid="input-ip"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="subnet">Subnet Mask</Label>
                <Input
                  id="subnet"
                  value={config.lan0.subnet}
                  onChange={(e) => updateLan0({ subnet: e.target.value })}
                  placeholder="255.255.255.0"
                  data-testid="input-subnet"
                />
              </div>
              <div className="flex items-center justify-between">
                <Label htmlFor="dhcp">DHCP Server</Label>
                <Switch
                  id="dhcp"
                  checked={config.lan0.dhcp}
                  onCheckedChange={(dhcp) => updateLan0({ dhcp })}
                  data-testid="switch-dhcp"
                />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="bridge" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Bridge Mode</CardTitle>
              <CardDescription>Combine interfaces into a bridge</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <Label htmlFor="bridge-enabled">Enable Bridge</Label>
                <Switch
                  id="bridge-enabled"
                  checked={config.bridge.enabled}
                  onCheckedChange={(enabled) => updateBridge({ enabled })}
                  data-testid="switch-bridge-enabled"
                />
              </div>
              {config.bridge.enabled && (
                <div className="space-y-2">
                  <Label>Bridged Interfaces</Label>
                  <div className="text-sm text-muted-foreground font-mono">
                    {config.bridge.interfaces.join(", ") || "None"}
                  </div>
                  <p className="text-xs text-muted-foreground">
                    WLAN0 and LAN0 will be bridged together
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
