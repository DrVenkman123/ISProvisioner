import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Trash2, Plus, Edit2, Radio } from "lucide-react";

export interface PopProfile {
  id: string;
  name: string;
  ssid: string;
  wpaKey: string;
  beamwidth: number;
  frequency?: string;
}

interface PopProfileManagerProps {
  profiles: PopProfile[];
  onAdd: (profile: Omit<PopProfile, 'id'>) => void;
  onEdit: (id: string, profile: Partial<PopProfile>) => void;
  onDelete: (id: string) => void;
}

export default function PopProfileManager({ profiles, onAdd, onEdit, onDelete }: PopProfileManagerProps) {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    name: "",
    ssid: "",
    wpaKey: "",
    beamwidth: "60",
    frequency: "5GHz",
  });

  const openDialog = (profile?: PopProfile) => {
    if (profile) {
      setEditingId(profile.id);
      setFormData({
        name: profile.name,
        ssid: profile.ssid,
        wpaKey: profile.wpaKey,
        beamwidth: String(profile.beamwidth),
        frequency: profile.frequency || "5GHz",
      });
    } else {
      setEditingId(null);
      setFormData({ name: "", ssid: "", wpaKey: "", beamwidth: "60", frequency: "5GHz" });
    }
    setIsDialogOpen(true);
  };

  const handleSave = () => {
    if (editingId) {
      onEdit(editingId, {
        ...formData,
        beamwidth: parseInt(formData.beamwidth),
      });
    } else {
      onAdd({
        ...formData,
        beamwidth: parseInt(formData.beamwidth),
      });
    }
    setIsDialogOpen(false);
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle>PoP Profiles</CardTitle>
            <CardDescription>Point of Presence connection configurations</CardDescription>
          </div>
          <Button onClick={() => openDialog()} data-testid="button-add-pop">
            <Plus className="h-4 w-4 mr-2" />
            Add PoP
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        {profiles.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            <Radio className="h-12 w-12 mx-auto mb-3 opacity-50" />
            <p>No PoP profiles configured</p>
            <p className="text-sm mt-1">Add a Point of Presence to get started</p>
          </div>
        ) : (
          <div className="space-y-3">
            {profiles.map((profile) => (
              <div
                key={profile.id}
                className="flex items-center justify-between p-4 rounded-lg border bg-card hover-elevate"
                data-testid={`pop-${profile.id}`}
              >
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <h4 className="font-semibold">{profile.name}</h4>
                    <Badge variant="secondary">{profile.frequency || "5GHz"}</Badge>
                    <Badge variant="outline">{profile.beamwidth}° beam</Badge>
                  </div>
                  <div className="text-sm text-muted-foreground font-mono">
                    SSID: {profile.ssid}
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button
                    size="icon"
                    variant="ghost"
                    onClick={() => openDialog(profile)}
                    data-testid={`button-edit-${profile.id}`}
                  >
                    <Edit2 className="h-4 w-4" />
                  </Button>
                  <Button
                    size="icon"
                    variant="ghost"
                    className="text-destructive hover:text-destructive"
                    onClick={() => onDelete(profile.id)}
                    data-testid={`button-delete-${profile.id}`}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent data-testid="dialog-pop-form">
          <DialogHeader>
            <DialogTitle>{editingId ? "Edit" : "Add"} PoP Profile</DialogTitle>
            <DialogDescription>
              Configure connection settings for this Point of Presence
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="pop-name">PoP Name</Label>
              <Input
                id="pop-name"
                placeholder="e.g., Tower 95, EE Row"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                data-testid="input-pop-name"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="ssid">SSID</Label>
              <Input
                id="ssid"
                placeholder="WISPerNet-Tower95"
                value={formData.ssid}
                onChange={(e) => setFormData({ ...formData, ssid: e.target.value })}
                data-testid="input-pop-ssid"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="wpa-key">WPA Key</Label>
              <Input
                id="wpa-key"
                type="password"
                value={formData.wpaKey}
                onChange={(e) => setFormData({ ...formData, wpaKey: e.target.value })}
                data-testid="input-pop-wpa"
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="beamwidth">Beamwidth (degrees)</Label>
                <Input
                  id="beamwidth"
                  type="number"
                  value={formData.beamwidth}
                  onChange={(e) => setFormData({ ...formData, beamwidth: e.target.value })}
                  data-testid="input-pop-beamwidth"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="frequency">Frequency</Label>
                <Input
                  id="frequency"
                  placeholder="5GHz"
                  value={formData.frequency}
                  onChange={(e) => setFormData({ ...formData, frequency: e.target.value })}
                  data-testid="input-pop-frequency"
                />
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDialogOpen(false)} data-testid="button-cancel">
              Cancel
            </Button>
            <Button onClick={handleSave} data-testid="button-save-pop">
              {editingId ? "Update" : "Add"} PoP
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Card>
  );
}
