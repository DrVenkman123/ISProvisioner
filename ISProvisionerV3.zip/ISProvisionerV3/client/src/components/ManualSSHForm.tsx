import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Cable } from "lucide-react";

export interface ManualSSHConnection {
  ip: string;
  username: string;
  password: string;
}

interface ManualSSHFormProps {
  onConnect: (connection: ManualSSHConnection) => void;
  isConnecting?: boolean;
}

export default function ManualSSHForm({ onConnect, isConnecting = false }: ManualSSHFormProps) {
  const [ip, setIp] = useState("");
  const [username, setUsername] = useState("ubnt");
  const [password, setPassword] = useState("ubnt");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (ip && username && password) {
      onConnect({ ip, username, password });
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Manual SSH Connection</CardTitle>
        <CardDescription>Connect directly to a device using its IP address</CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="manual-ip">Device IP Address</Label>
            <Input
              id="manual-ip"
              type="text"
              placeholder="192.168.1.20"
              value={ip}
              onChange={(e) => setIp(e.target.value)}
              disabled={isConnecting}
              data-testid="input-manual-ip"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="manual-username">SSH Username</Label>
            <Input
              id="manual-username"
              type="text"
              placeholder="ubnt"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              disabled={isConnecting}
              data-testid="input-manual-username"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="manual-password">SSH Password</Label>
            <Input
              id="manual-password"
              type="password"
              placeholder="ubnt"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              disabled={isConnecting}
              data-testid="input-manual-password"
            />
          </div>
          <Button 
            type="submit" 
            className="w-full"
            disabled={!ip || !username || !password || isConnecting}
            data-testid="button-manual-connect"
          >
            <Cable className="h-4 w-4 mr-2" />
            {isConnecting ? "Connecting..." : "Connect via SSH"}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}
