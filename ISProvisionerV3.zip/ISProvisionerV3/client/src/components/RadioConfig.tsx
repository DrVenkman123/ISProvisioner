import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";

export interface RadioSettings {
  ssid: string;
  wpaKey: string;
  frequency: string;
  channelWidth: string;
  txPower: string;
  eirpLimit: string;
  beamwidth: string;
  country: string;
}

interface RadioConfigProps {
  settings: RadioSettings;
  onChange: (settings: RadioSettings) => void;
  deviceType: string;
}

export default function RadioConfig({ settings, onChange, deviceType }: RadioConfigProps) {
  const updateSetting = (key: keyof RadioSettings, value: string) => {
    onChange({ ...settings, [key]: value });
  };

  // Determine max EIRP based on country
  const maxEIRP = settings.country === "US" ? "36" : settings.country === "EU" ? "27" : "30";

  return (
    <Card>
      <CardHeader>
        <CardTitle>Radio Configuration</CardTitle>
        <CardDescription>Wireless power, frequency, and regulatory settings for {deviceType}</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Wireless Security */}
        <div className="space-y-4">
          <h4 className="font-semibold">Wireless Security</h4>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="ssid">SSID</Label>
              <Input
                id="ssid"
                value={settings.ssid}
                onChange={(e) => updateSetting("ssid", e.target.value)}
                placeholder="Network name"
                data-testid="input-radio-ssid"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="wpa-key">WPA Key</Label>
              <Input
                id="wpa-key"
                type="password"
                value={settings.wpaKey}
                onChange={(e) => updateSetting("wpaKey", e.target.value)}
                placeholder="WPA2 password"
                data-testid="input-wpa-key"
              />
            </div>
          </div>
        </div>

        <Separator />

        {/* Frequency Settings */}
        <div className="space-y-4">
          <h4 className="font-semibold">Frequency & Channel</h4>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="frequency">Frequency (MHz)</Label>
              <Select value={settings.frequency} onValueChange={(val) => updateSetting("frequency", val)}>
                <SelectTrigger id="frequency" data-testid="select-frequency">
                  <SelectValue placeholder="Select frequency" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="2412">2.4 GHz - Channel 1</SelectItem>
                  <SelectItem value="2437">2.4 GHz - Channel 6</SelectItem>
                  <SelectItem value="2462">2.4 GHz - Channel 11</SelectItem>
                  <SelectItem value="5180">5 GHz - Channel 36</SelectItem>
                  <SelectItem value="5220">5 GHz - Channel 44</SelectItem>
                  <SelectItem value="5260">5 GHz - Channel 52</SelectItem>
                  <SelectItem value="5300">5 GHz - Channel 60</SelectItem>
                  <SelectItem value="5500">5 GHz - Channel 100</SelectItem>
                  <SelectItem value="5700">5 GHz - Channel 140</SelectItem>
                  <SelectItem value="5745">5 GHz - Channel 149</SelectItem>
                  <SelectItem value="5805">5 GHz - Channel 161</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="channel-width">Channel Width</Label>
              <Select value={settings.channelWidth} onValueChange={(val) => updateSetting("channelWidth", val)}>
                <SelectTrigger id="channel-width" data-testid="select-channel-width">
                  <SelectValue placeholder="Select width" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="10">10 MHz</SelectItem>
                  <SelectItem value="20">20 MHz</SelectItem>
                  <SelectItem value="40">40 MHz</SelectItem>
                  <SelectItem value="80">80 MHz</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>

        <Separator />

        {/* Power & Regulatory */}
        <div className="space-y-4">
          <h4 className="font-semibold">Power & Regulatory</h4>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="country">Country Code</Label>
              <Select value={settings.country} onValueChange={(val) => updateSetting("country", val)}>
                <SelectTrigger id="country" data-testid="select-country">
                  <SelectValue placeholder="Select country" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="US">United States (US)</SelectItem>
                  <SelectItem value="CA">Canada (CA)</SelectItem>
                  <SelectItem value="EU">European Union (EU)</SelectItem>
                  <SelectItem value="GB">United Kingdom (GB)</SelectItem>
                  <SelectItem value="AU">Australia (AU)</SelectItem>
                  <SelectItem value="MX">Mexico (MX)</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="tx-power">TX Power (dBm)</Label>
              <Input
                id="tx-power"
                type="number"
                min="0"
                max="30"
                value={settings.txPower}
                onChange={(e) => updateSetting("txPower", e.target.value)}
                placeholder="e.g., 24"
                data-testid="input-tx-power"
              />
              <p className="text-xs text-muted-foreground">
                Transmit power (0-30 dBm)
              </p>
            </div>
          </div>
        </div>

        <Separator />

        {/* Antenna Settings */}
        <div className="space-y-4">
          <h4 className="font-semibold">Antenna Configuration</h4>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="eirp-limit">EIRP Limit (dBm)</Label>
              <Input
                id="eirp-limit"
                type="number"
                min="0"
                max={maxEIRP}
                value={settings.eirpLimit}
                onChange={(e) => updateSetting("eirpLimit", e.target.value)}
                placeholder={`Max: ${maxEIRP} dBm for ${settings.country || "US"}`}
                data-testid="input-eirp-limit"
              />
              <p className="text-xs text-muted-foreground">
                Effective Isotropic Radiated Power limit for {settings.country || "US"}
              </p>
            </div>
            <div className="space-y-2">
              <Label htmlFor="beamwidth">Antenna Beamwidth (degrees)</Label>
              <Select value={settings.beamwidth} onValueChange={(val) => updateSetting("beamwidth", val)}>
                <SelectTrigger id="beamwidth" data-testid="select-beamwidth">
                  <SelectValue placeholder="Select beamwidth" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="360">Omni (360°)</SelectItem>
                  <SelectItem value="120">Sector (120°)</SelectItem>
                  <SelectItem value="90">Sector (90°)</SelectItem>
                  <SelectItem value="60">Sector (60°)</SelectItem>
                  <SelectItem value="45">Directional (45°)</SelectItem>
                  <SelectItem value="30">High-Gain (30°)</SelectItem>
                  <SelectItem value="20">High-Gain (20°)</SelectItem>
                  <SelectItem value="10">Point-to-Point (10°)</SelectItem>
                </SelectContent>
              </Select>
              <p className="text-xs text-muted-foreground">
                Antenna radiation pattern
              </p>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
