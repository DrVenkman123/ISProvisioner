import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Server, Wifi, Activity, HardDrive, Cpu, Clock, Network } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";

interface DeviceStats {
  firmware?: string;
  model?: string;
  hostname?: string;
  ipAddress?: string;
  netmask?: string;
  gateway?: string;
  uptime?: string;
  signalStrength?: number;
  signalQuality?: number;
  wirelessMode?: 'ap' | 'station';
  ssid?: string;
  frequency?: string;
  txPower?: number;
  cpuLoad?: string;
  memoryUsage?: string;
  temperature?: string;
}

interface DeviceStatsCardProps {
  deviceIp: string;
  deviceFamily: string;
  sshUsername?: string;
  sshPassword?: string;
  sshPort?: number;
}

export default function DeviceStatsCard({
  deviceIp,
  deviceFamily,
  sshUsername = "ubnt",
  sshPassword = "ubnt",
  sshPort = 22,
}: DeviceStatsCardProps) {
  const { data: stats, isLoading, error } = useQuery<DeviceStats>({
    queryKey: ['/api/device/stats', deviceIp],
    queryFn: async () => {
      const res = await apiRequest('POST', '/api/device/stats', {
        ip: deviceIp,
        port: sshPort,
        username: sshUsername,
        password: sshPassword,
        deviceFamily,
      });
      return await res.json();
    },
    retry: 1,
    staleTime: 30000,
  });

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Server className="h-5 w-5" />
            Device Information
          </CardTitle>
          <CardDescription>Retrieving device stats via SSH...</CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          <Skeleton className="h-4 w-full" />
          <Skeleton className="h-4 w-3/4" />
          <Skeleton className="h-4 w-2/3" />
        </CardContent>
      </Card>
    );
  }

  if (error) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Server className="h-5 w-5" />
            Device Information
          </CardTitle>
          <CardDescription className="text-destructive">
            Failed to retrieve device stats. Check SSH credentials.
          </CardDescription>
        </CardHeader>
      </Card>
    );
  }

  if (!stats) return null;

  const getSignalColor = (signal: number | undefined): "default" | "secondary" | "destructive" => {
    if (!signal) return "secondary";
    if (signal >= -60) return "default";
    if (signal >= -70) return "secondary";
    return "destructive";
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Server className="h-5 w-5" />
          Device Information
        </CardTitle>
        <CardDescription>Real-time stats retrieved via SSH</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* System Info */}
          <div className="space-y-3">
            <div className="flex items-start gap-2">
              <Server className="h-4 w-4 mt-0.5 text-muted-foreground" />
              <div className="flex-1">
                <div className="text-sm font-medium">Model</div>
                <div className="text-sm text-muted-foreground">{stats.model || "Unknown"}</div>
              </div>
            </div>

            {stats.firmware && (
              <div className="flex items-start gap-2">
                <Activity className="h-4 w-4 mt-0.5 text-muted-foreground" />
                <div className="flex-1">
                  <div className="text-sm font-medium">Firmware</div>
                  <div className="text-sm text-muted-foreground font-mono">{stats.firmware}</div>
                </div>
              </div>
            )}

            {stats.hostname && (
              <div className="flex items-start gap-2">
                <Network className="h-4 w-4 mt-0.5 text-muted-foreground" />
                <div className="flex-1">
                  <div className="text-sm font-medium">Hostname</div>
                  <div className="text-sm text-muted-foreground">{stats.hostname}</div>
                </div>
              </div>
            )}

            {stats.uptime && (
              <div className="flex items-start gap-2">
                <Clock className="h-4 w-4 mt-0.5 text-muted-foreground" />
                <div className="flex-1">
                  <div className="text-sm font-medium">Uptime</div>
                  <div className="text-sm text-muted-foreground">{stats.uptime}</div>
                </div>
              </div>
            )}
          </div>

          {/* Network & Performance */}
          <div className="space-y-3">
            {stats.ipAddress && (
              <div className="flex items-start gap-2">
                <Network className="h-4 w-4 mt-0.5 text-muted-foreground" />
                <div className="flex-1">
                  <div className="text-sm font-medium">IP Configuration</div>
                  <div className="text-sm text-muted-foreground font-mono">
                    {stats.ipAddress}
                    {stats.netmask && ` / ${stats.netmask}`}
                  </div>
                  {stats.gateway && (
                    <div className="text-xs text-muted-foreground">Gateway: {stats.gateway}</div>
                  )}
                </div>
              </div>
            )}

            {stats.wirelessMode && (
              <div className="flex items-start gap-2">
                <Wifi className="h-4 w-4 mt-0.5 text-muted-foreground" />
                <div className="flex-1">
                  <div className="text-sm font-medium">Wireless</div>
                  <div className="flex items-center gap-2 mt-1">
                    <Badge variant={stats.wirelessMode === 'ap' ? 'default' : 'secondary'} className="text-xs">
                      {stats.wirelessMode === 'ap' ? 'Access Point' : 'Station'}
                    </Badge>
                    {stats.signalStrength && (
                      <Badge variant={getSignalColor(stats.signalStrength)} className="text-xs">
                        {stats.signalStrength} dBm
                      </Badge>
                    )}
                  </div>
                  {stats.ssid && (
                    <div className="text-xs text-muted-foreground mt-1">SSID: {stats.ssid}</div>
                  )}
                </div>
              </div>
            )}

            {(stats.cpuLoad || stats.memoryUsage) && (
              <div className="flex items-start gap-2">
                <Cpu className="h-4 w-4 mt-0.5 text-muted-foreground" />
                <div className="flex-1">
                  <div className="text-sm font-medium">Performance</div>
                  <div className="space-y-1 mt-1">
                    {stats.cpuLoad && (
                      <div className="text-xs text-muted-foreground">CPU Load: {stats.cpuLoad}</div>
                    )}
                    {stats.memoryUsage && (
                      <div className="text-xs text-muted-foreground">Memory: {stats.memoryUsage}</div>
                    )}
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
