import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Search, Wifi, Bluetooth, Network, Loader2, CheckCircle2, Users } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export interface DiscoveredDevice {
  ip: string;
  mac: string;
  hostname?: string;
  model?: string;
  manufacturer?: string;
  method: "lan" | "bluetooth" | "wifi";
}

interface DeviceDiscoveryProps {
  onConnect: (device: DiscoveredDevice) => void;
  mode?: "single" | "bulk";
  selectedDevices?: DiscoveredDevice[];
  onSelectionChange?: (devices: DiscoveredDevice[]) => void;
}

interface NetworkInterface {
  name: string;
  addresses: Array<{
    address: string;
    family: string;
  }>;
}

interface BluetoothAdapter {
  name: string;
  address: string;
}

export default function DeviceDiscovery({ 
  onConnect, 
  mode = "single",
  selectedDevices = [],
  onSelectionChange,
}: DeviceDiscoveryProps) {
  const { toast } = useToast();
  const [scanMethod, setScanMethod] = useState<"lan" | "bluetooth" | "wifi">("lan");
  const [lanNetworks, setLanNetworks] = useState("192.168.1.0/24");
  const [selectedNIC, setSelectedNIC] = useState("");
  const [wifiAdapter, setWifiAdapter] = useState("");
  const [bluetoothAdapter, setBluetoothAdapter] = useState("");
  const [discoveredDevices, setDiscoveredDevices] = useState<DiscoveredDevice[]>([]);
  const [isScanning, setIsScanning] = useState(false);

  // Fetch available network interfaces (NICs)
  const { data: networkInterfaces = [] } = useQuery<NetworkInterface[]>({
    queryKey: ['/api/discovery/network-interfaces'],
    staleTime: 60000, // Cache for 1 minute
  });

  // Fetch available Bluetooth adapters
  const { data: bluetoothAdapters = [] } = useQuery<BluetoothAdapter[]>({
    queryKey: ['/api/discovery/bluetooth-adapters'],
    staleTime: 60000, // Cache for 1 minute
  });

  // Fetch available WiFi adapters
  const { data: availableAdapters = [] } = useQuery<string[]>({
    queryKey: ['/api/discovery/wifi-adapters'],
    staleTime: 60000, // Cache for 1 minute
  });

  // Set default NIC when available
  useEffect(() => {
    if (networkInterfaces.length > 0 && !selectedNIC) {
      setSelectedNIC(networkInterfaces[0].name);
    }
  }, [networkInterfaces, selectedNIC]);

  // Set default bluetooth adapter when available
  useEffect(() => {
    if (bluetoothAdapters.length > 0 && !bluetoothAdapter) {
      setBluetoothAdapter(bluetoothAdapters[0].name);
    }
  }, [bluetoothAdapters, bluetoothAdapter]);

  // Set default WiFi adapter when available
  useEffect(() => {
    if (availableAdapters.length > 0 && !wifiAdapter) {
      setWifiAdapter(availableAdapters[0]);
    }
  }, [availableAdapters, wifiAdapter]);

  // LAN scan mutation
  const lanScanMutation = useMutation({
    mutationFn: async ({ cidr, iface }: { cidr: string; iface: string }) => {
      const res = await apiRequest('POST', '/api/discovery/lan', { cidr, timeout: 30, interface: iface });
      return await res.json();
    },
    onSuccess: (devices: Array<{ ip: string; mac: string; hostname?: string; manufacturer?: string }>) => {
      const mappedDevices: DiscoveredDevice[] = devices.map(d => ({
        ...d,
        method: 'lan' as const,
      }));
      setDiscoveredDevices(mappedDevices);
      toast({
        title: "Scan Complete",
        description: `Found ${devices.length} device(s)`,
      });
    },
    onError: (error: any) => {
      toast({
        title: "Scan Failed",
        description: error.message || "Failed to scan LAN",
        variant: "destructive",
      });
    },
    onSettled: () => setIsScanning(false),
  });

  // Bluetooth scan mutation
  const bluetoothScanMutation = useMutation({
    mutationFn: async (duration: number) => {
      const res = await apiRequest('POST', '/api/discovery/bluetooth', { duration });
      return await res.json();
    },
    onSuccess: (devices: Array<{ ip: string; mac: string; hostname?: string; manufacturer?: string }>) => {
      const mappedDevices: DiscoveredDevice[] = devices.map(d => ({
        ...d,
        method: 'bluetooth' as const,
      }));
      setDiscoveredDevices(mappedDevices);
      toast({
        title: "Scan Complete",
        description: `Found ${devices.length} Bluetooth device(s)`,
      });
    },
    onError: (error: any) => {
      toast({
        title: "Scan Failed",
        description: error.message || "Failed to scan Bluetooth",
        variant: "destructive",
      });
    },
    onSettled: () => setIsScanning(false),
  });

  // WiFi scan mutation
  const wifiScanMutation = useMutation({
    mutationFn: async (adapter: string) => {
      const res = await apiRequest('POST', '/api/discovery/wifi', { adapter });
      return await res.json();
    },
    onSuccess: (networks: Array<{ ssid: string; bssid: string; signal: number; security: string; channel: number }>) => {
      // Map WiFi networks to discovered devices
      const mappedDevices: DiscoveredDevice[] = networks.map(n => ({
        ip: n.bssid, // Use BSSID as IP for WiFi devices
        mac: n.bssid,
        hostname: n.ssid,
        manufacturer: `WiFi (Ch${n.channel}, ${n.security})`,
        method: 'wifi' as const,
      }));
      setDiscoveredDevices(mappedDevices);
      toast({
        title: "Scan Complete",
        description: `Found ${networks.length} WiFi network(s)`,
      });
    },
    onError: (error: any) => {
      toast({
        title: "Scan Failed",
        description: error.message || "Failed to scan WiFi",
        variant: "destructive",
      });
    },
    onSettled: () => setIsScanning(false),
  });

  const handleScanLAN = () => {
    if (!selectedNIC) {
      toast({
        title: "No NIC Selected",
        description: "Please select a network interface",
        variant: "destructive",
      });
      return;
    }
    setIsScanning(true);
    setDiscoveredDevices([]);
    // Parse comma-separated CIDRs and scan first one
    const cidrs = lanNetworks.split(',').map(c => c.trim());
    lanScanMutation.mutate({ cidr: cidrs[0], iface: selectedNIC });
  };

  const handleScanBluetooth = () => {
    setIsScanning(true);
    setDiscoveredDevices([]);
    bluetoothScanMutation.mutate(10); // 10 second scan
  };

  const handleScanWiFi = () => {
    setIsScanning(true);
    setDiscoveredDevices([]);
    wifiScanMutation.mutate(wifiAdapter);
  };

  const isDeviceSelected = (device: DiscoveredDevice) => {
    return selectedDevices.some(d => d.ip === device.ip);
  };

  const handleToggleDevice = (device: DiscoveredDevice) => {
    if (!onSelectionChange) return;
    
    if (isDeviceSelected(device)) {
      onSelectionChange(selectedDevices.filter(d => d.ip !== device.ip));
    } else {
      onSelectionChange([...selectedDevices, device]);
    }
  };

  const handleSelectAll = () => {
    if (!onSelectionChange) return;
    
    if (selectedDevices.length === discoveredDevices.length) {
      onSelectionChange([]);
    } else {
      onSelectionChange([...discoveredDevices]);
    }
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle>Device Discovery</CardTitle>
            <CardDescription>
              {mode === "bulk" 
                ? "Select multiple devices for bulk operations" 
                : "Find and connect to Ubiquiti devices on your network"}
            </CardDescription>
          </div>
          {mode === "bulk" && selectedDevices.length > 0 && (
            <Badge variant="secondary" data-testid="badge-selected-count">
              <Users className="h-3 w-3 mr-1" />
              {selectedDevices.length} selected
            </Badge>
          )}
        </div>
      </CardHeader>
      <CardContent>
        <Tabs value={scanMethod} onValueChange={(val) => setScanMethod(val as any)}>
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="lan" data-testid="tab-lan">
              <Network className="h-4 w-4 mr-2" />
              LAN
            </TabsTrigger>
            <TabsTrigger value="bluetooth" data-testid="tab-bluetooth">
              <Bluetooth className="h-4 w-4 mr-2" />
              Bluetooth
            </TabsTrigger>
            <TabsTrigger value="wifi" data-testid="tab-wifi">
              <Wifi className="h-4 w-4 mr-2" />
              WiFi
            </TabsTrigger>
          </TabsList>

          <TabsContent value="lan" className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="nic-select">Network Interface (NIC)</Label>
              <Select value={selectedNIC} onValueChange={setSelectedNIC}>
                <SelectTrigger id="nic-select" data-testid="select-nic">
                  <SelectValue placeholder="Select network interface" />
                </SelectTrigger>
                <SelectContent>
                  {networkInterfaces.length === 0 ? (
                    <SelectItem value="none" disabled>No interfaces found</SelectItem>
                  ) : (
                    networkInterfaces.map((nic) => (
                      <SelectItem key={nic.name} value={nic.name}>
                        {nic.name} - {nic.addresses.find(a => a.family === 'IPv4')?.address || 'No IP'}
                      </SelectItem>
                    ))
                  )}
                </SelectContent>
              </Select>
              <p className="text-xs text-muted-foreground">
                Select which ethernet port/NIC to use for scanning (eth0, ens1, etc.)
              </p>
            </div>
            <div className="space-y-2">
              <Label htmlFor="lan-networks">Network Ranges</Label>
              <Input
                id="lan-networks"
                placeholder="192.168.1.0/24, 10.0.0.0/24"
                value={lanNetworks}
                onChange={(e) => setLanNetworks(e.target.value)}
                data-testid="input-lan-networks"
              />
              <p className="text-xs text-muted-foreground">
                Comma-separated CIDR networks to scan (e.g., 192.168.1.0/24)
              </p>
            </div>
            <Button
              className="w-full"
              onClick={handleScanLAN}
              disabled={isScanning}
              data-testid="button-scan-lan"
            >
              {isScanning ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Scanning...
                </>
              ) : (
                <>
                  <Search className="h-4 w-4 mr-2" />
                  Scan LAN Networks
                </>
              )}
            </Button>
          </TabsContent>

          <TabsContent value="bluetooth" className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="bluetooth-adapter">Bluetooth Adapter</Label>
              <Select value={bluetoothAdapter} onValueChange={setBluetoothAdapter}>
                <SelectTrigger id="bluetooth-adapter" data-testid="select-bluetooth-adapter">
                  <SelectValue placeholder="Select bluetooth adapter" />
                </SelectTrigger>
                <SelectContent>
                  {bluetoothAdapters.length === 0 ? (
                    <SelectItem value="none" disabled>No adapters found</SelectItem>
                  ) : (
                    bluetoothAdapters.map((adapter) => (
                      <SelectItem key={adapter.name} value={adapter.name}>
                        {adapter.name} - {adapter.address}
                      </SelectItem>
                    ))
                  )}
                </SelectContent>
              </Select>
              <p className="text-xs text-muted-foreground">
                Select which bluetooth adapter to use (hci0, hci1, etc.)
              </p>
            </div>
            <div className="rounded-lg bg-muted/30 p-4">
              <p className="text-sm mb-2">
                Bluetooth discovery is used for UISP switches and Wave AP devices.
              </p>
              <p className="text-xs text-muted-foreground">
                Make sure Bluetooth is enabled on your system and the device is in pairing mode.
              </p>
            </div>
            <Button
              className="w-full"
              onClick={handleScanBluetooth}
              disabled={isScanning}
              data-testid="button-scan-bluetooth"
            >
              {isScanning ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Scanning...
                </>
              ) : (
                <>
                  <Search className="h-4 w-4 mr-2" />
                  Scan for Bluetooth Devices
                </>
              )}
            </Button>
          </TabsContent>

          <TabsContent value="wifi" className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="wifi-adapter">WiFi Adapter</Label>
              <Select value={wifiAdapter} onValueChange={setWifiAdapter}>
                <SelectTrigger id="wifi-adapter" data-testid="select-wifi-adapter">
                  <SelectValue placeholder="Select a WiFi adapter" />
                </SelectTrigger>
                <SelectContent>
                  {availableAdapters.map((adapter) => (
                    <SelectItem key={adapter} value={adapter}>
                      {adapter}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <p className="text-xs text-muted-foreground">
                Scan for Ubiquiti APs without disconnecting from your main network
              </p>
            </div>
            <Button
              className="w-full"
              onClick={handleScanWiFi}
              disabled={isScanning || !wifiAdapter}
              data-testid="button-scan-wifi"
            >
              {isScanning ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Scanning...
                </>
              ) : (
                <>
                  <Search className="h-4 w-4 mr-2" />
                  Scan WiFi Networks
                </>
              )}
            </Button>
          </TabsContent>
        </Tabs>

        {discoveredDevices.length > 0 && (
          <div className="mt-6 space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="font-semibold text-sm">Discovered Devices</h4>
              {mode === "bulk" && discoveredDevices.length > 0 && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleSelectAll}
                  data-testid="button-select-all"
                >
                  {selectedDevices.length === discoveredDevices.length ? "Deselect All" : "Select All"}
                </Button>
              )}
            </div>
            <div className="space-y-2">
              {discoveredDevices.map((device, idx) => (
                <div
                  key={`${device.ip}-${idx}`}
                  className="flex items-center gap-3 p-3 rounded-lg border bg-card hover-elevate"
                  data-testid={`device-${device.ip}`}
                >
                  {mode === "bulk" && (
                    <Checkbox
                      checked={isDeviceSelected(device)}
                      onCheckedChange={() => handleToggleDevice(device)}
                      data-testid={`checkbox-${device.ip}`}
                    />
                  )}
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="font-mono font-semibold">{device.ip}</span>
                      <Badge variant="outline" className="text-xs">
                        {device.method}
                      </Badge>
                      {device.model && (
                        <Badge variant="secondary" className="text-xs">
                          {device.model}
                        </Badge>
                      )}
                    </div>
                    <div className="text-xs text-muted-foreground space-y-0.5">
                      {device.hostname && <div>Hostname: {device.hostname}</div>}
                      {device.mac && <div className="font-mono">MAC: {device.mac}</div>}
                      {device.manufacturer && <div>{device.manufacturer}</div>}
                    </div>
                  </div>
                  {mode === "single" && (
                    <Button
                      size="sm"
                      onClick={() => onConnect(device)}
                      data-testid={`button-connect-${device.ip}`}
                    >
                      <CheckCircle2 className="h-4 w-4 mr-1" />
                      Connect
                    </Button>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
