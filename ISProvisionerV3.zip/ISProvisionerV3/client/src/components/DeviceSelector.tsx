import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Radio, Wifi, Box, Router, Activity } from "lucide-react";

export type DeviceType = 
  | "nanostation-m2"
  | "nanostation-m5"
  | "nanostation-5ac-loco"
  | "nanostation-5ac"
  | "nanobeam-m5"
  | "nanobeam-5ac-gen1"
  | "nanobeam-5ac-gen2"
  | "airfiber-5"
  | "airfiber-5x"
  | "airfiber-5xhd"
  | "airfiber-24"
  | "airfiber-60"
  | "litebeam-5ac"
  | "liteap-120"
  | "liteap-gps"
  | "powerbeam-m5"
  | "powerbeam-5ac"
  | "aircube-ac"
  | "aircube-isp"
  | "wave-ap"
  | "wave-station"
  | "wave-nano"
  | "wave-micro"
  | "uisp-switch-8"
  | "uisp-switch-16"
  | "uisp-switch-24"
  | "uisp-switch-48"
  | "uisp-switch-pro-24"
  | "uisp-switch-pro-48"
  | "edgerouter-x"
  | "edgerouter-x-sfp"
  | "edgerouter-4"
  | "edgerouter-6p"
  | "edgerouter-12"
  | "edgerouter-12p"
  | "edgeswitch-8-150w"
  | "edgeswitch-10x"
  | "edgeswitch-16-150w"
  | "edgeswitch-24-250w"
  | "edgeswitch-24-500w"
  | "edgeswitch-48-500w"
  | "edgeswitch-48-750w";

interface DeviceSelectorProps {
  selectedDevice: DeviceType | null;
  onSelectDevice: (device: DeviceType) => void;
}

const devices = [
  // airMAX NanoStations
  { type: "nanostation-m2" as DeviceType, name: "NanoStation M2", icon: Radio, description: "2.4GHz airMAX CPE", family: "airmax" },
  { type: "nanostation-m5" as DeviceType, name: "NanoStation M5", icon: Radio, description: "5GHz airMAX CPE", family: "airmax" },
  { type: "nanostation-5ac-loco" as DeviceType, name: "NanoStation 5AC Loco", icon: Radio, description: "Compact 5GHz AC CPE", family: "airmax" },
  { type: "nanostation-5ac" as DeviceType, name: "NanoStation 5AC", icon: Radio, description: "5GHz AC airMAX CPE", family: "airmax" },
  
  // NanoBeams
  { type: "nanobeam-m5" as DeviceType, name: "NanoBeam M5", icon: Wifi, description: "5GHz airMAX PtP", family: "airmax" },
  { type: "nanobeam-5ac-gen1" as DeviceType, name: "NanoBeam 5AC Gen1", icon: Wifi, description: "5GHz AC Gen1 PtP", family: "airmax" },
  { type: "nanobeam-5ac-gen2" as DeviceType, name: "NanoBeam 5AC Gen2", icon: Wifi, description: "5GHz AC Gen2 PtP", family: "airmax" },
  
  // AirFiber
  { type: "airfiber-5" as DeviceType, name: "AirFiber 5", icon: Wifi, description: "500Mbps+ 5GHz backhaul", family: "airmax" },
  { type: "airfiber-5x" as DeviceType, name: "AirFiber 5X", icon: Wifi, description: "1Gbps+ 5GHz backhaul", family: "airmax" },
  { type: "airfiber-5xhd" as DeviceType, name: "AirFiber 5XHD", icon: Wifi, description: "1Gbps+ 5GHz HD backhaul", family: "airmax" },
  { type: "airfiber-24" as DeviceType, name: "AirFiber 24", icon: Wifi, description: "1.4Gbps+ 24GHz backhaul", family: "airmax" },
  { type: "airfiber-60" as DeviceType, name: "AirFiber 60", icon: Wifi, description: "1Gbps+ 60GHz backhaul", family: "airmax" },
  
  // LiteBeam & PowerBeam
  { type: "litebeam-5ac" as DeviceType, name: "LiteBeam 5AC", icon: Wifi, description: "Lightweight 5GHz AC CPE", family: "airmax" },
  { type: "powerbeam-m5" as DeviceType, name: "PowerBeam M5", icon: Radio, description: "Long-range 5GHz CPE", family: "airmax" },
  { type: "powerbeam-5ac" as DeviceType, name: "PowerBeam 5AC", icon: Radio, description: "Long-range 5GHz AC CPE", family: "airmax" },
  
  // LiteAP
  { type: "liteap-120" as DeviceType, name: "LiteAP AC LAP-120", icon: Radio, description: "120° sector antenna", family: "airmax" },
  { type: "liteap-gps" as DeviceType, name: "LiteAP GPS", icon: Radio, description: "GPS-enabled access point", family: "airmax" },
  
  // AirCube
  { type: "aircube-ac" as DeviceType, name: "AirCube AC", icon: Box, description: "Access point AC", family: "aircube" },
  { type: "aircube-isp" as DeviceType, name: "AirCube ISP", icon: Box, description: "ISP edition", family: "aircube" },
  
  // Wave
  { type: "wave-ap" as DeviceType, name: "Wave AP", icon: Activity, description: "Wave access point", family: "wave" },
  { type: "wave-station" as DeviceType, name: "Wave Station", icon: Activity, description: "Wave station", family: "wave" },
  { type: "wave-nano" as DeviceType, name: "Wave Nano", icon: Activity, description: "Compact Wave CPE", family: "wave" },
  { type: "wave-micro" as DeviceType, name: "Wave Micro", icon: Activity, description: "Ultra-compact Wave CPE", family: "wave" },
  
  // UISP Switches
  { type: "uisp-switch-8" as DeviceType, name: "UISP Switch 8", icon: Router, description: "8-port PoE switch", family: "uisp-switch" },
  { type: "uisp-switch-16" as DeviceType, name: "UISP Switch 16", icon: Router, description: "16-port PoE switch", family: "uisp-switch" },
  { type: "uisp-switch-24" as DeviceType, name: "UISP Switch 24", icon: Router, description: "24-port PoE switch", family: "uisp-switch" },
  { type: "uisp-switch-48" as DeviceType, name: "UISP Switch 48", icon: Router, description: "48-port PoE switch", family: "uisp-switch" },
  { type: "uisp-switch-pro-24" as DeviceType, name: "UISP Switch Pro 24", icon: Router, description: "24-port Pro PoE switch", family: "uisp-switch" },
  { type: "uisp-switch-pro-48" as DeviceType, name: "UISP Switch Pro 48", icon: Router, description: "48-port Pro PoE switch", family: "uisp-switch" },
  
  // EdgeRouters
  { type: "edgerouter-x" as DeviceType, name: "EdgeRouter X", icon: Router, description: "5-port router", family: "edgemax" },
  { type: "edgerouter-x-sfp" as DeviceType, name: "EdgeRouter X SFP", icon: Router, description: "5-port + SFP router", family: "edgemax" },
  { type: "edgerouter-4" as DeviceType, name: "EdgeRouter 4", icon: Router, description: "4-port router", family: "edgemax" },
  { type: "edgerouter-6p" as DeviceType, name: "EdgeRouter 6P", icon: Router, description: "6-port PoE router (50W)", family: "edgemax" },
  { type: "edgerouter-12" as DeviceType, name: "EdgeRouter 12", icon: Router, description: "12-port router", family: "edgemax" },
  { type: "edgerouter-12p" as DeviceType, name: "EdgeRouter 12P", icon: Router, description: "12-port PoE router (150W)", family: "edgemax" },
  
  // EdgeSwitches
  { type: "edgeswitch-8-150w" as DeviceType, name: "EdgeSwitch 8 150W", icon: Router, description: "8-port PoE switch (150W)", family: "edgemax" },
  { type: "edgeswitch-10x" as DeviceType, name: "EdgeSwitch 10X", icon: Router, description: "10-port SFP+ switch", family: "edgemax" },
  { type: "edgeswitch-16-150w" as DeviceType, name: "EdgeSwitch 16 150W", icon: Router, description: "16-port PoE switch (150W)", family: "edgemax" },
  { type: "edgeswitch-24-250w" as DeviceType, name: "EdgeSwitch 24 250W", icon: Router, description: "24-port PoE switch (250W)", family: "edgemax" },
  { type: "edgeswitch-24-500w" as DeviceType, name: "EdgeSwitch 24 500W", icon: Router, description: "24-port PoE switch (500W)", family: "edgemax" },
  { type: "edgeswitch-48-500w" as DeviceType, name: "EdgeSwitch 48 500W", icon: Router, description: "48-port PoE switch (500W)", family: "edgemax" },
  { type: "edgeswitch-48-750w" as DeviceType, name: "EdgeSwitch 48 750W", icon: Router, description: "48-port PoE switch (750W)", family: "edgemax" },
];

export default function DeviceSelector({ selectedDevice, onSelectDevice }: DeviceSelectorProps) {
  return (
    <div className="space-y-4">
      <div>
        <h2 className="text-2xl font-semibold mb-2">Select Device Type</h2>
        <p className="text-muted-foreground">Choose the device you want to configure</p>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {devices.map((device) => {
          const Icon = device.icon;
          const isSelected = selectedDevice === device.type;
          return (
            <Card
              key={device.type}
              className={`cursor-pointer transition-all hover-elevate ${
                isSelected ? "ring-2 ring-primary" : ""
              }`}
              onClick={() => onSelectDevice(device.type)}
              data-testid={`card-device-${device.type}`}
            >
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center">
                    <Icon className="h-6 w-6 text-primary" />
                  </div>
                  {isSelected && (
                    <div className="h-2 w-2 rounded-full bg-primary" data-testid={`indicator-selected-${device.type}`} />
                  )}
                </div>
              </CardHeader>
              <CardContent className="space-y-2">
                <CardTitle className="text-lg">{device.name}</CardTitle>
                <CardDescription>{device.description}</CardDescription>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
}
