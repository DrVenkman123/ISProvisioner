import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { PopProfile } from "./PopProfileManager";

export interface NetworkConfig {
  ipMode: "dhcp" | "manual";
  ipVersion?: "ipv4" | "ipv6";
  staticIp?: string;
  netmask?: string;
  gateway?: string;
  dns?: string;
  managementVlan?: string;
  dataVlans: string[];
  mtu?: string;
  ethernetSpeed: "auto" | "100" | "1000";
  popProfileId?: string;
  installDate: string;
}

interface AdvancedNetworkConfigProps {
  config: NetworkConfig;
  onChange: (config: NetworkConfig) => void;
  deviceType: string;
  popProfiles: PopProfile[];
  showPopSelector?: boolean;
}

export default function AdvancedNetworkConfig({
  config,
  onChange,
  deviceType,
  popProfiles,
  showPopSelector = true,
}: AdvancedNetworkConfigProps) {
  const updateConfig = (updates: Partial<NetworkConfig>) => {
    onChange({ ...config, ...updates });
  };

  const isSwitch = deviceType.toLowerCase().includes("switch");
  const supportsGigabit = !deviceType.toLowerCase().includes("aircube");

  return (
    <Card>
      <CardHeader>
        <CardTitle>Advanced Network Configuration</CardTitle>
        <CardDescription>IP settings, VLANs, and interface parameters</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* PoP Profile Selection */}
        {showPopSelector && popProfiles.length > 0 && (
          <>
            <div className="space-y-2">
              <Label htmlFor="pop-profile">PoP Profile</Label>
              <Select value={config.popProfileId || ""} onValueChange={(val) => updateConfig({ popProfileId: val })}>
                <SelectTrigger id="pop-profile" data-testid="select-pop-profile">
                  <SelectValue placeholder="Select a Point of Presence" />
                </SelectTrigger>
                <SelectContent>
                  {popProfiles.map((pop) => (
                    <SelectItem key={pop.id} value={pop.id}>
                      {pop.name} - {pop.ssid}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <p className="text-xs text-muted-foreground">
                Auto-fills SSID, WPA key, and beamwidth from selected PoP
              </p>
            </div>
            <Separator />
          </>
        )}

        {/* IP Configuration Mode */}
        <div className="space-y-4">
          <h4 className="font-semibold">IP Configuration</h4>
          
          {/* IP Version Selector */}
          <div className="space-y-2">
            <Label>IP Version</Label>
            <RadioGroup
              value={config.ipVersion || "ipv4"}
              onValueChange={(val: "ipv4" | "ipv6") => updateConfig({ ipVersion: val })}
              className="flex gap-4"
              data-testid="radio-ip-version"
            >
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="ipv4" id="ipv4" data-testid="radio-ipv4" />
                <Label htmlFor="ipv4" className="font-normal cursor-pointer">IPv4</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="ipv6" id="ipv6" data-testid="radio-ipv6" />
                <Label htmlFor="ipv6" className="font-normal cursor-pointer">IPv6</Label>
              </div>
            </RadioGroup>
          </div>

          <div className="flex items-center justify-between">
            <div className="space-y-1">
              <Label htmlFor="ip-mode">DHCP</Label>
              <p className="text-xs text-muted-foreground">
                {config.ipMode === "dhcp" ? "Auto-assign IP address" : "Use manual IP configuration"}
              </p>
            </div>
            <Switch
              id="ip-mode"
              checked={config.ipMode === "dhcp"}
              onCheckedChange={(checked) => updateConfig({ ipMode: checked ? "dhcp" : "manual" })}
              data-testid="switch-ip-mode"
            />
          </div>

          {config.ipMode === "manual" && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="static-ip">Static IP</Label>
                <Input
                  id="static-ip"
                  placeholder={config.ipVersion === "ipv6" ? "2001:db8::1" : "192.168.1.20"}
                  value={config.staticIp || ""}
                  onChange={(e) => updateConfig({ staticIp: e.target.value })}
                  data-testid="input-static-ip"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="netmask">{config.ipVersion === "ipv6" ? "Prefix Length" : "Netmask"}</Label>
                <Input
                  id="netmask"
                  placeholder={config.ipVersion === "ipv6" ? "64" : "255.255.255.0"}
                  value={config.netmask || ""}
                  onChange={(e) => updateConfig({ netmask: e.target.value })}
                  data-testid="input-netmask"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="gateway">Gateway</Label>
                <Input
                  id="gateway"
                  placeholder={config.ipVersion === "ipv6" ? "2001:db8::1" : "192.168.1.1"}
                  value={config.gateway || ""}
                  onChange={(e) => updateConfig({ gateway: e.target.value })}
                  data-testid="input-gateway"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="dns">DNS Server</Label>
                <Input
                  id="dns"
                  placeholder={config.ipVersion === "ipv6" ? "2001:4860:4860::8888" : "8.8.8.8"}
                  value={config.dns || ""}
                  onChange={(e) => updateConfig({ dns: e.target.value })}
                  data-testid="input-dns"
                />
              </div>
            </div>
          )}
        </div>

        <Separator />

        {/* VLAN Configuration */}
        <div className="space-y-4">
          <h4 className="font-semibold">VLAN Configuration</h4>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="mgmt-vlan">Management VLAN</Label>
              <Input
                id="mgmt-vlan"
                placeholder="e.g., 100 (blank for untagged)"
                value={config.managementVlan || ""}
                onChange={(e) => updateConfig({ managementVlan: e.target.value })}
                data-testid="input-mgmt-vlan"
              />
              <p className="text-xs text-muted-foreground">
                VLAN for device management access
              </p>
            </div>
            <div className="space-y-2">
              <Label htmlFor="data-vlans">Data VLANs</Label>
              <Input
                id="data-vlans"
                placeholder="e.g., 10,20,30"
                value={config.dataVlans.join(",")}
                onChange={(e) => updateConfig({ dataVlans: e.target.value.split(",").map(v => v.trim()).filter(Boolean) })}
                data-testid="input-data-vlans"
              />
              <p className="text-xs text-muted-foreground">
                {isSwitch ? "VLANs for port tagging" : "VLANs to bridge between WLAN0/LAN0"}
              </p>
            </div>
          </div>
        </div>

        <Separator />

        {/* Interface Settings */}
        <div className="space-y-4">
          <h4 className="font-semibold">Interface Settings</h4>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="mtu">MTU</Label>
              <Input
                id="mtu"
                type="number"
                placeholder="1500 (default)"
                value={config.mtu || ""}
                onChange={(e) => updateConfig({ mtu: e.target.value })}
                data-testid="input-mtu"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="eth-speed">Ethernet Speed</Label>
              <Select value={config.ethernetSpeed} onValueChange={(val: any) => updateConfig({ ethernetSpeed: val })}>
                <SelectTrigger id="eth-speed" data-testid="select-eth-speed">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="auto">Auto-Negotiate</SelectItem>
                  <SelectItem value="100">100 Mbps</SelectItem>
                  {supportsGigabit && <SelectItem value="1000">1 Gbps</SelectItem>}
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>

        <Separator />

        {/* Install Date */}
        <div className="space-y-2">
          <Label htmlFor="install-date">Install Date</Label>
          <Input
            id="install-date"
            type="date"
            value={config.installDate}
            onChange={(e) => updateConfig({ installDate: e.target.value })}
            data-testid="input-install-date"
          />
          <p className="text-xs text-muted-foreground">
            Auto-set to today when provisioning runs
          </p>
        </div>
      </CardContent>
    </Card>
  );
}
