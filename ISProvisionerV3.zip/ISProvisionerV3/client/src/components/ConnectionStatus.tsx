import { Badge } from "@/components/ui/badge";
import { CheckCircle2, XCircle, Loader2 } from "lucide-react";

interface ConnectionStatusProps {
  status: "disconnected" | "connecting" | "connected";
  deviceIp?: string;
  deviceModel?: string;
}

export default function ConnectionStatus({ status, deviceIp, deviceModel }: ConnectionStatusProps) {
  if (status === "disconnected") {
    return null;
  }

  const config = {
    connecting: {
      icon: Loader2,
      label: "Connecting...",
      className: "bg-blue-500/10 text-blue-500 border-blue-500/20",
      iconClass: "animate-spin",
    },
    connected: {
      icon: CheckCircle2,
      label: "Connected",
      className: "bg-green-500/10 text-green-500 border-green-500/20",
      iconClass: "",
    },
  };

  const currentConfig = config[status];
  const Icon = currentConfig.icon;

  return (
    <div className={`flex items-center gap-2 px-3 py-1.5 rounded-lg border ${currentConfig.className}`} data-testid="connection-status">
      <Icon className={`h-4 w-4 ${currentConfig.iconClass}`} />
      <div className="flex items-center gap-2">
        <span className="font-semibold text-sm">{currentConfig.label}</span>
        {deviceIp && (
          <>
            <span className="text-muted-foreground">•</span>
            <span className="font-mono text-sm">{deviceIp}</span>
          </>
        )}
        {deviceModel && (
          <>
            <span className="text-muted-foreground">•</span>
            <Badge variant="outline" className="text-xs">
              {deviceModel}
            </Badge>
          </>
        )}
      </div>
    </div>
  );
}
