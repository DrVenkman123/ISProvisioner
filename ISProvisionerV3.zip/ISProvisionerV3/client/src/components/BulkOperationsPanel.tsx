import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Users, Key, Loader2, CheckCircle2, XCircle, RotateCcw, Download, RefreshCw, AlertTriangle } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export interface BulkDevice {
  ip: string;
  mac: string;
  hostname?: string;
}

interface BulkOperationsPanelProps {
  selectedDevices: BulkDevice[];
  onClearSelection: () => void;
}

interface BulkOperationResult {
  ip: string;
  success: boolean;
  message: string;
  device?: BulkDevice; // Store original device metadata for retry
}

type OperationType = "credentials" | "factory-reset" | "stats";

export default function BulkOperationsPanel({
  selectedDevices,
  onClearSelection,
}: BulkOperationsPanelProps) {
  const { toast } = useToast();
  const [currentUsername, setCurrentUsername] = useState("ubnt");
  const [currentPassword, setCurrentPassword] = useState("ubnt");
  const [newUsername, setNewUsername] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [results, setResults] = useState<BulkOperationResult[]>([]);
  const [currentOperation, setCurrentOperation] = useState<OperationType>("credentials");
  const [operationProgress, setOperationProgress] = useState({ current: 0, total: 0 });

  const bulkChangeMutation = useMutation({
    mutationFn: async (params: {
      devices: BulkDevice[];
      currentUsername: string;
      currentPassword: string;
      newUsername: string;
      newPassword: string;
    }) => {
      const total = params.devices.length;
      setOperationProgress({ current: 0, total });
      
      const results: BulkOperationResult[] = [];
      for (let i = 0; i < params.devices.length; i++) {
        const device = params.devices[i];
        try {
          const res = await apiRequest('POST', '/api/bulk-operations/change-credentials', {
            devices: [device],
            currentUsername: params.currentUsername,
            currentPassword: params.currentPassword,
            newUsername: params.newUsername,
            newPassword: params.newPassword,
          });
          
          if (!res.ok) {
            const errorData = await res.json().catch(() => ({ error: 'Unknown error' }));
            results.push({
              ip: device.ip,
              success: false,
              message: errorData.error || `HTTP ${res.status}`,
              device,
            });
          } else {
            const data = await res.json();
            // API returns array, get first result
            const deviceResult = Array.isArray(data) ? data[0] : data;
            results.push({
              ip: device.ip,
              success: deviceResult?.success ?? true,
              message: deviceResult?.message || "Credentials updated successfully",
              device,
            });
          }
        } catch (error: any) {
          results.push({
            ip: device.ip,
            success: false,
            message: error.message || "Failed to update credentials",
            device,
          });
        }
        setOperationProgress({ current: i + 1, total });
      }
      return results;
    },
    onSuccess: (data: BulkOperationResult[]) => {
      setResults(data);
      setOperationProgress({ current: 0, total: 0 });
      const successCount = data.filter((r: BulkOperationResult) => r.success).length;
      toast({
        title: "Bulk Operation Complete",
        description: `Successfully updated ${successCount} of ${data.length} devices`,
      });
    },
    onError: (error: any) => {
      setOperationProgress({ current: 0, total: 0 });
      toast({
        title: "Bulk Operation Failed",
        description: error.message || "Failed to update devices",
        variant: "destructive",
      });
    },
  });

  const bulkFactoryResetMutation = useMutation({
    mutationFn: async (params: {
      devices: BulkDevice[];
      username: string;
      password: string;
    }) => {
      const total = params.devices.length;
      setOperationProgress({ current: 0, total });
      
      const results: BulkOperationResult[] = [];
      for (let i = 0; i < params.devices.length; i++) {
        const device = params.devices[i];
        try {
          const res = await apiRequest('POST', '/api/devices/factory-reset', {
            host: device.ip,
            username: params.username,
            password: params.password,
            deviceFamily: 'airmax', // Default, ideally should be detected
          });
          
          if (!res.ok) {
            const errorData = await res.json().catch(() => ({ error: 'Unknown error' }));
            results.push({
              ip: device.ip,
              success: false,
              message: errorData.error || `HTTP ${res.status}`,
              device,
            });
          } else {
            const data = await res.json().catch(() => null);
            if (!data || !data.message) {
              results.push({
                ip: device.ip,
                success: false,
                message: "No response from device",
                device,
              });
            } else {
              // Check backend's success flag, default to false if not present
              results.push({
                ip: device.ip,
                success: data.success ?? false,
                message: data.message,
                device,
              });
            }
          }
        } catch (error: any) {
          results.push({
            ip: device.ip,
            success: false,
            message: error.message || "Factory reset failed",
            device,
          });
        }
        setOperationProgress({ current: i + 1, total });
      }
      return results;
    },
    onSuccess: (data: BulkOperationResult[]) => {
      setResults(data);
      setOperationProgress({ current: 0, total: 0 });
      const successCount = data.filter((r: BulkOperationResult) => r.success).length;
      toast({
        title: "Bulk Factory Reset Complete",
        description: `Successfully reset ${successCount} of ${data.length} devices`,
      });
    },
    onError: (error: any) => {
      setOperationProgress({ current: 0, total: 0 });
      toast({
        title: "Bulk Factory Reset Failed",
        description: error.message || "Failed to reset devices",
        variant: "destructive",
      });
    },
  });

  const handleChangeCredentials = () => {
    if (!newUsername && !newPassword) {
      toast({
        title: "No Changes",
        description: "Please enter a new username or password",
        variant: "destructive",
      });
      return;
    }

    setResults([]);
    setCurrentOperation("credentials");
    
    bulkChangeMutation.mutate({
      devices: selectedDevices,
      currentUsername,
      currentPassword,
      newUsername: newUsername || currentUsername,
      newPassword: newPassword || currentPassword,
    });
  };

  const handleFactoryReset = () => {
    if (!window.confirm(`⚠️ WARNING: This will factory reset ${selectedDevices.length} device(s).\n\nAll configurations will be lost and devices will reboot.\n\nContinue?`)) {
      return;
    }

    setResults([]);
    setCurrentOperation("factory-reset");
    bulkFactoryResetMutation.mutate({
      devices: selectedDevices,
      username: currentUsername,
      password: currentPassword,
    });
  };

  const handleRetryFailed = () => {
    // Build failed devices list directly from results (includes device metadata)
    const failedDevices = results
      .filter(r => !r.success && r.device)
      .map(r => r.device!);

    if (failedDevices.length === 0) {
      toast({
        title: "No Failed Devices",
        description: "All devices succeeded in the previous operation",
      });
      return;
    }

    // Clear old results to avoid confusion
    setResults([]);

    if (currentOperation === "credentials") {
      bulkChangeMutation.mutate({
        devices: failedDevices,
        currentUsername,
        currentPassword,
        newUsername: newUsername || currentUsername,
        newPassword: newPassword || currentPassword,
      });
    } else if (currentOperation === "factory-reset") {
      bulkFactoryResetMutation.mutate({
        devices: failedDevices,
        username: currentUsername,
        password: currentPassword,
      });
    }
  };

  const handleExportResults = () => {
    if (results.length === 0) {
      toast({
        title: "No Results",
        description: "Run an operation first to export results",
        variant: "destructive",
      });
      return;
    }

    const csv = [
      ["IP Address", "Status", "Message"].join(","),
      ...results.map((r) => [
        r.ip,
        r.success ? "Success" : "Failed",
        `"${r.message.replace(/"/g, '""')}"`,
      ].join(",")),
    ].join("\n");

    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `bulk-operation-results-${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    URL.revokeObjectURL(url);

    toast({
      title: "Results Exported",
      description: "CSV file downloaded successfully",
    });
  };

  if (selectedDevices.length === 0) {
    return null;
  }

  const successCount = results.filter(r => r.success).length;
  const failureCount = results.filter(r => !r.success).length;
  const isProcessing = bulkChangeMutation.isPending || bulkFactoryResetMutation.isPending;
  const progressPercentage = operationProgress.total > 0 
    ? (operationProgress.current / operationProgress.total) * 100 
    : 0;

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between gap-4">
          <div className="flex-1">
            <CardTitle className="flex items-center gap-2">
              <Users className="h-5 w-5" />
              Bulk Operations
            </CardTitle>
            <CardDescription>
              Perform operations on {selectedDevices.length} selected device{selectedDevices.length > 1 ? 's' : ''}
            </CardDescription>
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={onClearSelection}
            data-testid="button-clear-selection"
          >
            Clear Selection
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Selected Devices */}
        <div className="space-y-2">
          <Label>Selected Devices ({selectedDevices.length})</Label>
          <div className="flex flex-wrap gap-2 max-h-32 overflow-y-auto p-2 border rounded-lg bg-muted/30">
            {selectedDevices.map((device) => (
              <Badge key={device.ip} variant="secondary" className="text-xs" data-testid={`badge-device-${device.ip}`}>
                {device.ip} {device.hostname && `(${device.hostname})`}
              </Badge>
            ))}
          </div>
        </div>

        {/* Operation Tabs */}
        <Tabs defaultValue="credentials" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="credentials" data-testid="tab-credentials">
              <Key className="h-4 w-4 mr-2" />
              Change Credentials
            </TabsTrigger>
            <TabsTrigger value="factory-reset" data-testid="tab-factory-reset">
              <RotateCcw className="h-4 w-4 mr-2" />
              Factory Reset
            </TabsTrigger>
          </TabsList>

          {/* Credentials Tab */}
          <TabsContent value="credentials" className="space-y-4 mt-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="current-username">Current Username</Label>
                <Input
                  id="current-username"
                  value={currentUsername}
                  onChange={(e) => setCurrentUsername(e.target.value)}
                  placeholder="ubnt"
                  data-testid="input-current-username"
                  disabled={isProcessing}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="current-password">Current Password</Label>
                <Input
                  id="current-password"
                  type="password"
                  value={currentPassword}
                  onChange={(e) => setCurrentPassword(e.target.value)}
                  placeholder="ubnt"
                  data-testid="input-current-password"
                  disabled={isProcessing}
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="new-username">New Username</Label>
                <Input
                  id="new-username"
                  value={newUsername}
                  onChange={(e) => setNewUsername(e.target.value)}
                  placeholder="Leave blank to keep current"
                  data-testid="input-new-username"
                  disabled={isProcessing}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="new-password">New Password</Label>
                <Input
                  id="new-password"
                  type="password"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  placeholder="Leave blank to keep current"
                  data-testid="input-new-password"
                  disabled={isProcessing}
                />
              </div>
            </div>

            <Button
              className="w-full"
              onClick={handleChangeCredentials}
              disabled={isProcessing}
              data-testid="button-apply-bulk-changes"
            >
              {bulkChangeMutation.isPending ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Updating {operationProgress.current} of {operationProgress.total}...
                </>
              ) : (
                <>
                  <Key className="h-4 w-4 mr-2" />
                  Change Credentials on All Devices
                </>
              )}
            </Button>
          </TabsContent>

          {/* Factory Reset Tab */}
          <TabsContent value="factory-reset" className="space-y-4 mt-4">
            <div className="p-4 border rounded-lg bg-amber-500/10 border-amber-500/20">
              <div className="flex items-start gap-3">
                <AlertTriangle className="h-5 w-5 text-amber-500 flex-shrink-0 mt-0.5" />
                <div className="space-y-1">
                  <p className="text-sm font-medium text-amber-900 dark:text-amber-100">
                    Warning: Destructive Operation
                  </p>
                  <p className="text-sm text-amber-800 dark:text-amber-200">
                    Factory reset will erase all configurations and reboot all selected devices. This action cannot be undone.
                  </p>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="reset-username">Username</Label>
                <Input
                  id="reset-username"
                  value={currentUsername}
                  onChange={(e) => setCurrentUsername(e.target.value)}
                  placeholder="ubnt"
                  data-testid="input-reset-username"
                  disabled={isProcessing}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="reset-password">Password</Label>
                <Input
                  id="reset-password"
                  type="password"
                  value={currentPassword}
                  onChange={(e) => setCurrentPassword(e.target.value)}
                  placeholder="ubnt"
                  data-testid="input-reset-password"
                  disabled={isProcessing}
                />
              </div>
            </div>

            <Button
              className="w-full"
              variant="destructive"
              onClick={handleFactoryReset}
              disabled={isProcessing}
              data-testid="button-bulk-factory-reset"
            >
              {bulkFactoryResetMutation.isPending ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Resetting {operationProgress.current} of {operationProgress.total}...
                </>
              ) : (
                <>
                  <RotateCcw className="h-4 w-4 mr-2" />
                  Factory Reset All Devices
                </>
              )}
            </Button>
          </TabsContent>
        </Tabs>

        {/* Progress */}
        {isProcessing && (
          <div className="space-y-2">
            <div className="flex items-center justify-between text-sm">
              <span>Processing devices...</span>
              <span>{Math.round(progressPercentage)}%</span>
            </div>
            <Progress value={progressPercentage} data-testid="progress-bulk-operation" />
          </div>
        )}

        {/* Results */}
        {results.length > 0 && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="h-4 w-4 text-green-600 dark:text-green-400" />
                  <span className="text-sm font-medium">{successCount} succeeded</span>
                </div>
                {failureCount > 0 && (
                  <div className="flex items-center gap-2">
                    <XCircle className="h-4 w-4 text-destructive" />
                    <span className="text-sm font-medium">{failureCount} failed</span>
                  </div>
                )}
              </div>
              <div className="flex items-center gap-2">
                {failureCount > 0 && (
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleRetryFailed}
                    disabled={isProcessing}
                    data-testid="button-retry-failed"
                  >
                    <RefreshCw className="h-3 w-3 mr-1" />
                    Retry Failed ({failureCount})
                  </Button>
                )}
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleExportResults}
                  data-testid="button-export-results"
                >
                  <Download className="h-3 w-3 mr-1" />
                  Export CSV
                </Button>
              </div>
            </div>

            <div className="space-y-2 max-h-64 overflow-y-auto border rounded-lg p-3 bg-muted/30">
              {results.map((result) => (
                <div
                  key={result.ip}
                  className={`p-3 rounded-md border text-sm ${
                    result.success 
                      ? 'bg-green-500/10 border-green-500/30 dark:bg-green-500/20' 
                      : 'bg-destructive/10 border-destructive/30'
                  }`}
                  data-testid={`result-${result.ip}`}
                >
                  <div className="flex items-center gap-3">
                    {result.success ? (
                      <CheckCircle2 className="h-4 w-4 text-green-600 dark:text-green-400 flex-shrink-0" />
                    ) : (
                      <XCircle className="h-4 w-4 text-destructive flex-shrink-0" />
                    )}
                    <span className="font-mono font-medium">{result.ip}</span>
                    <span className="text-muted-foreground flex-1">— {result.message}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
