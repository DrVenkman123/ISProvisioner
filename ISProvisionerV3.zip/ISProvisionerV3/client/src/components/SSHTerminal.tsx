import { useEffect, useRef } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Terminal, CheckCircle2, AlertCircle, Loader2 } from "lucide-react";

export interface SSHLog {
  timestamp: string;
  message: string;
  type: "info" | "success" | "error";
}

interface SSHTerminalProps {
  logs: SSHLog[];
  status: "idle" | "connecting" | "executing" | "success" | "error";
  deviceIp?: string;
}

export default function SSHTerminal({ logs, status, deviceIp }: SSHTerminalProps) {
  const logContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (logContainerRef.current) {
      logContainerRef.current.scrollTop = logContainerRef.current.scrollHeight;
    }
  }, [logs]);

  const statusConfig = {
    idle: { icon: Terminal, color: "text-muted-foreground", label: "Ready" },
    connecting: { icon: Loader2, color: "text-blue-500", label: "Connecting" },
    executing: { icon: Loader2, color: "text-blue-500", label: "Executing" },
    success: { icon: CheckCircle2, color: "text-green-500", label: "Success" },
    error: { icon: AlertCircle, color: "text-red-500", label: "Error" },
  };

  const StatusIcon = statusConfig[status].icon;

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <Terminal className="h-5 w-5" />
            SSH Output
          </CardTitle>
          <div className="flex items-center gap-3">
            {deviceIp && (
              <span className="text-sm font-mono text-muted-foreground">{deviceIp}</span>
            )}
            <Badge variant={status === "success" ? "default" : status === "error" ? "destructive" : "secondary"}>
              <StatusIcon className={`h-3 w-3 mr-1 ${status === "connecting" || status === "executing" ? "animate-spin" : ""} ${statusConfig[status].color}`} />
              {statusConfig[status].label}
            </Badge>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div
          ref={logContainerRef}
          className="bg-muted/30 rounded-lg p-4 font-mono text-sm max-h-96 overflow-y-auto space-y-1"
          data-testid="terminal-output"
        >
          {logs.length === 0 ? (
            <div className="text-muted-foreground">Waiting for SSH connection...</div>
          ) : (
            logs.map((log, index) => (
              <div
                key={index}
                className={`${
                  log.type === "error"
                    ? "text-red-500"
                    : log.type === "success"
                    ? "text-green-500"
                    : "text-foreground"
                }`}
                data-testid={`log-${index}`}
              >
                <span className="text-muted-foreground mr-2">[{log.timestamp}]</span>
                {log.message}
              </div>
            ))
          )}
        </div>
      </CardContent>
    </Card>
  );
}
