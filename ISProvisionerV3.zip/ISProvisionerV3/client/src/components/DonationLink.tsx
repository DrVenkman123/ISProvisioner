import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Coffee, Beer, UtensilsCrossed } from "lucide-react";

export default function DonationLink() {
  return (
    <Card className="bg-gradient-to-br from-primary/5 to-primary/10 border-primary/20">
      <CardContent className="py-4">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="flex gap-1">
              <Coffee className="h-5 w-5 text-primary" />
              <Beer className="h-5 w-5 text-primary" />
              <UtensilsCrossed className="h-5 w-5 text-primary" />
            </div>
            <div>
              <p className="font-semibold text-sm">Enjoying ISProvisioner?</p>
              <p className="text-xs text-muted-foreground">Buy me a coffee, beer, or taco!</p>
            </div>
          </div>
          <Button
            variant="default"
            size="sm"
            onClick={() => window.open("https://cash.app/$EricElston123", "_blank")}
            data-testid="button-donate"
          >
            <span className="font-mono">$EricElston123</span>
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
