import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Badge } from "@/components/ui/badge";
import { Plus, Pencil, Trash2 } from "lucide-react";
import { insertDefaultCredentialSchema, type InsertDefaultCredential, type DefaultCredential } from "@shared/schema";

interface DefaultCredentialsManagerProps {
  credentials: DefaultCredential[];
  onAdd: (credential: InsertDefaultCredential) => Promise<void> | void;
  onEdit: (id: string, updates: Partial<InsertDefaultCredential>) => Promise<void> | void;
  onDelete: (id: string) => Promise<void> | void;
  isAddPending?: boolean;
  isEditPending?: boolean;
  isDeletePending?: boolean;
}

const deviceFamilies = [
  { value: "airmax", label: "airMAX" },
  { value: "aircube", label: "airCube" },
  { value: "wave", label: "Wave" },
  { value: "edgemax", label: "EdgeMAX" },
  { value: "uisp-switch", label: "UISP Switch" },
];

export default function DefaultCredentialsManager({
  credentials,
  onAdd,
  onEdit,
  onDelete,
  isAddPending,
  isEditPending,
  isDeletePending,
}: DefaultCredentialsManagerProps) {
  const [addDialogOpen, setAddDialogOpen] = useState(false);
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [selectedCredential, setSelectedCredential] = useState<DefaultCredential | null>(null);

  // Add form
  const addForm = useForm<InsertDefaultCredential>({
    resolver: zodResolver(insertDefaultCredentialSchema),
    defaultValues: {
      label: "",
      deviceFamily: null,
      username: "",
      password: "",
      notes: null,
    },
  });

  // Edit form
  const editForm = useForm<InsertDefaultCredential>({
    resolver: zodResolver(insertDefaultCredentialSchema),
    defaultValues: {
      label: "",
      deviceFamily: null,
      username: "",
      password: "",
      notes: null,
    },
  });

  const handleAdd = async (data: InsertDefaultCredential) => {
    try {
      await onAdd(data);
      setAddDialogOpen(false);
      addForm.reset();
    } catch (error) {
      // Error is handled by mutation's onError, dialog stays open
    }
  };

  const handleEdit = async (data: InsertDefaultCredential) => {
    if (!selectedCredential) return;
    try {
      await onEdit(selectedCredential.id.toString(), data);
      setEditDialogOpen(false);
      setSelectedCredential(null);
      editForm.reset();
    } catch (error) {
      // Error is handled by mutation's onError, dialog stays open
    }
  };

  const handleDelete = async () => {
    if (!selectedCredential) return;
    try {
      await onDelete(selectedCredential.id.toString());
      setDeleteDialogOpen(false);
      setSelectedCredential(null);
    } catch (error) {
      // Error is handled by mutation's onError
    }
  };

  const openEditDialog = (credential: DefaultCredential) => {
    setSelectedCredential(credential);
    editForm.reset({
      label: credential.label,
      deviceFamily: credential.deviceFamily,
      username: credential.username,
      password: credential.password,
      notes: credential.notes,
    });
    setEditDialogOpen(true);
  };

  const openDeleteDialog = (credential: DefaultCredential) => {
    setSelectedCredential(credential);
    setDeleteDialogOpen(true);
  };

  const getFamilyLabel = (deviceFamily: string | null) => {
    if (!deviceFamily) return "Universal";
    return deviceFamilies.find(f => f.value === deviceFamily)?.label || deviceFamily;
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between gap-2">
          <div>
            <CardTitle>Default Credentials</CardTitle>
            <CardDescription>Manage saved SSH credentials by device family</CardDescription>
          </div>
          <Dialog open={addDialogOpen} onOpenChange={setAddDialogOpen}>
            <DialogTrigger asChild>
              <Button
                size="sm"
                onClick={() => addForm.reset()}
                data-testid="button-add-credential"
              >
                <Plus className="h-4 w-4 mr-1" />
                Add Credential
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Add Default Credential</DialogTitle>
                <DialogDescription>
                  Add a saved credential set for connecting to devices
                </DialogDescription>
              </DialogHeader>
              <Form {...addForm}>
                <form onSubmit={addForm.handleSubmit(handleAdd)} className="space-y-4">
                  <FormField
                    control={addForm.control}
                    name="label"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Label</FormLabel>
                        <FormControl>
                          <Input
                            {...field}
                            placeholder="e.g., Default AirMAX"
                            data-testid="input-add-label"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={addForm.control}
                    name="deviceFamily"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Device Family</FormLabel>
                        <Select
                          value={field.value || ""}
                          onValueChange={(value) => field.onChange(value || null)}
                        >
                          <FormControl>
                            <SelectTrigger data-testid="select-add-family">
                              <SelectValue placeholder="Universal (all families)" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="">Universal (all families)</SelectItem>
                            {deviceFamilies.map((family) => (
                              <SelectItem key={family.value} value={family.value}>
                                {family.label}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormDescription>
                          Leave empty for credentials that work across all device families
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={addForm.control}
                    name="username"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Username</FormLabel>
                        <FormControl>
                          <Input
                            {...field}
                            placeholder="e.g., ubnt"
                            data-testid="input-add-username"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={addForm.control}
                    name="password"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Password</FormLabel>
                        <FormControl>
                          <Input
                            {...field}
                            type="password"
                            placeholder="Enter password"
                            data-testid="input-add-password"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={addForm.control}
                    name="notes"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Notes</FormLabel>
                        <FormControl>
                          <Textarea
                            {...field}
                            value={field.value || ""}
                            placeholder="Add any notes about this credential set"
                            rows={2}
                            data-testid="input-add-notes"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <DialogFooter>
                    <Button
                      type="submit"
                      disabled={isAddPending}
                      data-testid="button-save-credential"
                    >
                      {isAddPending ? "Adding..." : "Add Credential"}
                    </Button>
                  </DialogFooter>
                </form>
              </Form>
            </DialogContent>
          </Dialog>
        </div>
      </CardHeader>
      <CardContent>
        {credentials.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            <p>No saved credentials. Click "Add Credential" to create one.</p>
          </div>
        ) : (
          <div className="space-y-2">
            {credentials.map((credential) => (
              <div
                key={credential.id}
                className="flex items-center justify-between p-3 rounded-md border gap-3"
                data-testid={`credential-${credential.id}`}
              >
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <p className="font-medium">{credential.label}</p>
                    <Badge variant="secondary" className="text-xs">
                      {getFamilyLabel(credential.deviceFamily)}
                    </Badge>
                  </div>
                  <p className="text-sm text-muted-foreground font-mono">
                    {credential.username} / {"•".repeat(credential.password.length || 8)}
                  </p>
                  {credential.notes && (
                    <p className="text-xs text-muted-foreground mt-1">{credential.notes}</p>
                  )}
                </div>
                <div className="flex gap-1">
                  <Button
                    size="icon"
                    variant="ghost"
                    onClick={() => openEditDialog(credential)}
                    data-testid={`button-edit-credential-${credential.id.toString()}`}
                  >
                    <Pencil className="h-4 w-4" />
                  </Button>
                  <Button
                    size="icon"
                    variant="ghost"
                    onClick={() => openDeleteDialog(credential)}
                    data-testid={`button-delete-credential-${credential.id.toString()}`}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>

      {/* Edit Dialog */}
      <Dialog open={editDialogOpen} onOpenChange={setEditDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Credential</DialogTitle>
            <DialogDescription>Update the saved credential</DialogDescription>
          </DialogHeader>
          <Form {...editForm}>
            <form onSubmit={editForm.handleSubmit(handleEdit)} className="space-y-4">
              <FormField
                control={editForm.control}
                name="label"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Label</FormLabel>
                    <FormControl>
                      <Input {...field} data-testid="input-edit-label" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={editForm.control}
                name="deviceFamily"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Device Family</FormLabel>
                    <Select
                      value={field.value || ""}
                      onValueChange={(value) => field.onChange(value || null)}
                    >
                      <FormControl>
                        <SelectTrigger data-testid="select-edit-family">
                          <SelectValue placeholder="Universal (all families)" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="">Universal (all families)</SelectItem>
                        {deviceFamilies.map((family) => (
                          <SelectItem key={family.value} value={family.value}>
                            {family.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={editForm.control}
                name="username"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Username</FormLabel>
                    <FormControl>
                      <Input {...field} data-testid="input-edit-username" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={editForm.control}
                name="password"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Password</FormLabel>
                    <FormControl>
                      <Input
                        {...field}
                        type="password"
                        data-testid="input-edit-password"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={editForm.control}
                name="notes"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Notes</FormLabel>
                    <FormControl>
                      <Textarea
                        {...field}
                        value={field.value || ""}
                        rows={2}
                        data-testid="input-edit-notes"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <DialogFooter>
                <Button
                  type="submit"
                  disabled={isEditPending}
                  data-testid="button-update-credential"
                >
                  {isEditPending ? "Saving..." : "Save Changes"}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Credential</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete "{selectedCredential?.label}"? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel data-testid="button-cancel-delete" disabled={isDeletePending}>
              Cancel
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              data-testid="button-confirm-delete"
              disabled={isDeletePending}
            >
              {isDeletePending ? "Deleting..." : "Delete"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </Card>
  );
}

export type { DefaultCredential, InsertDefaultCredential };
