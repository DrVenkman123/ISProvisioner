import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import type { DefaultCredential } from "@shared/schema";

interface DeviceConfigFormProps {
  deviceType: string;
  deviceFamily?: string;
  config: Record<string, any>;
  onConfigChange: (key: string, value: any) => void;
}

export default function DeviceConfigForm({ deviceType, deviceFamily, config, onConfigChange }: DeviceConfigFormProps) {
  // Fetch saved credentials
  const { data: allCredentials = [] } = useQuery<DefaultCredential[]>({
    queryKey: ['/api/credentials'],
  });

  // Filter credentials by device family (include universal credentials too)
  const credentials = allCredentials.filter(cred => 
    !cred.deviceFamily || cred.deviceFamily === deviceFamily
  );

  const handleCredentialSelect = (value: string) => {
    if (value === "manual") {
      // User selected manual entry - leave current values as-is
      return;
    }
    
    // Find the selected credential and populate fields (convert string ID to number)
    const credentialId = parseInt(value, 10);
    const credential = credentials.find(c => c.id === credentialId);
    if (credential) {
      onConfigChange("username", credential.username);
      onConfigChange("password", credential.password);
    }
  };

  const getFamilyLabel = (family: string | null) => {
    if (!family) return "Universal";
    const familyLabels: Record<string, string> = {
      "airmax": "airMAX",
      "aircube": "airCube",
      "wave": "Wave",
      "edgemax": "EdgeMAX",
      "uisp-switch": "UISP Switch",
    };
    return familyLabels[family] || family;
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Basic Configuration</CardTitle>
        <CardDescription>Configure basic network settings for {deviceType}</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="space-y-4">
          <h4 className="font-semibold">Network Settings</h4>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="device-name">Device Name</Label>
              <Input
                id="device-name"
                value={config.deviceName || ""}
                onChange={(e) => onConfigChange("deviceName", e.target.value)}
                placeholder="e.g., ap-main-floor"
                data-testid="input-device-name"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="device-ip">Management IP</Label>
              <Input
                id="device-ip"
                value={config.managementIp || ""}
                onChange={(e) => onConfigChange("managementIp", e.target.value)}
                placeholder="192.168.1.20"
                data-testid="input-management-ip"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="gateway">Gateway</Label>
              <Input
                id="gateway"
                value={config.gateway || ""}
                onChange={(e) => onConfigChange("gateway", e.target.value)}
                placeholder="192.168.1.1"
                data-testid="input-gateway"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="dns">DNS Server</Label>
              <Input
                id="dns"
                value={config.dns || ""}
                onChange={(e) => onConfigChange("dns", e.target.value)}
                placeholder="8.8.8.8"
                data-testid="input-dns"
              />
            </div>
          </div>
        </div>

        <Separator />

        <div className="space-y-4">
          <h4 className="font-semibold">Credentials</h4>
          
          {credentials.length > 0 && (
            <div className="space-y-2">
              <Label htmlFor="credential-select">Use Saved Credentials</Label>
              <Select onValueChange={handleCredentialSelect} defaultValue="manual">
                <SelectTrigger id="credential-select" data-testid="select-credentials">
                  <SelectValue placeholder="Select saved credentials or enter manually" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="manual">
                    <div className="flex items-center gap-2">
                      <span>Manual Entry</span>
                      <Badge variant="outline" className="text-xs">Custom</Badge>
                    </div>
                  </SelectItem>
                  {credentials.map((cred) => (
                    <SelectItem key={cred.id} value={cred.id.toString()}>
                      <div className="flex items-center gap-2">
                        <span>{cred.label}</span>
                        <Badge variant="secondary" className="text-xs">
                          {getFamilyLabel(cred.deviceFamily)}
                        </Badge>
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <p className="text-xs text-muted-foreground">
                Choose a saved credential set or select "Manual Entry" to enter custom credentials
              </p>
            </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="username">Admin Username</Label>
              <Input
                id="username"
                value={config.username || ""}
                onChange={(e) => onConfigChange("username", e.target.value)}
                placeholder="admin"
                data-testid="input-username"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="password">Admin Password</Label>
              <Input
                id="password"
                type="password"
                value={config.password || ""}
                onChange={(e) => onConfigChange("password", e.target.value)}
                data-testid="input-password"
              />
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
