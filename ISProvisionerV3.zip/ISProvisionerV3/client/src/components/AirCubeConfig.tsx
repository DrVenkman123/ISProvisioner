import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Separator } from "@/components/ui/separator";

export interface AirCubeSettings {
  poePassthrough: boolean;
  poeVoltage: "24v" | "48v";
  wanMode: "dhcp" | "static" | "pppoe";
  wanStaticIp?: string;
  wanGateway?: string;
  wanDns?: string;
  managementVlan?: string;
}

interface AirCubeConfigProps {
  settings: AirCubeSettings;
  onChange: (settings: AirCubeSettings) => void;
}

export default function AirCubeConfig({ settings, onChange }: AirCubeConfigProps) {
  const updateSetting = <K extends keyof AirCubeSettings>(key: K, value: AirCubeSettings[K]) => {
    onChange({ ...settings, [key]: value });
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>AirCube Configuration</CardTitle>
        <CardDescription>AirCube-specific settings for WAN, PoE, and management</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* PoE Passthrough */}
        <div className="space-y-4">
          <h4 className="font-semibold">PoE Passthrough</h4>
          <div className="flex items-center justify-between p-4 border rounded-lg">
            <div className="space-y-1">
              <Label htmlFor="poe-passthrough">PoE Out</Label>
              <p className="text-sm text-muted-foreground">
                Enable power output on LAN port
              </p>
            </div>
            <Switch
              id="poe-passthrough"
              checked={settings.poePassthrough}
              onCheckedChange={(checked) => updateSetting("poePassthrough", checked)}
              data-testid="switch-poe-passthrough"
            />
          </div>
          
          {settings.poePassthrough && (
            <div className="space-y-2">
              <Label htmlFor="poe-voltage">PoE Output Voltage</Label>
              <Select 
                value={settings.poeVoltage} 
                onValueChange={(val: "24v" | "48v") => updateSetting("poeVoltage", val)}
              >
                <SelectTrigger id="poe-voltage" data-testid="select-poe-voltage">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="24v">24V Passive PoE (2-pair)</SelectItem>
                  <SelectItem value="48v">48V 802.3af (4-pair)</SelectItem>
                </SelectContent>
              </Select>
              <p className="text-xs text-muted-foreground">
                {settings.poeVoltage === "24v" 
                  ? "Standard for Ubiquiti airMAX devices" 
                  : "Standard 802.3af/at PoE"
                }
              </p>
            </div>
          )}
        </div>

        <Separator />

        {/* WAN Configuration */}
        <div className="space-y-4">
          <h4 className="font-semibold">WAN Configuration</h4>
          <div className="space-y-2">
            <Label htmlFor="wan-mode">WAN Mode</Label>
            <Select 
              value={settings.wanMode} 
              onValueChange={(val: typeof settings.wanMode) => updateSetting("wanMode", val)}
            >
              <SelectTrigger id="wan-mode" data-testid="select-wan-mode">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="dhcp">DHCP (Auto)</SelectItem>
                <SelectItem value="static">Static IP</SelectItem>
                <SelectItem value="pppoe">PPPoE</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {settings.wanMode === "static" && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="wan-ip">WAN IP Address</Label>
                <Input
                  id="wan-ip"
                  placeholder="e.g., 203.0.113.10"
                  value={settings.wanStaticIp || ""}
                  onChange={(e) => updateSetting("wanStaticIp", e.target.value)}
                  data-testid="input-wan-ip"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="wan-gateway">WAN Gateway</Label>
                <Input
                  id="wan-gateway"
                  placeholder="e.g., 203.0.113.1"
                  value={settings.wanGateway || ""}
                  onChange={(e) => updateSetting("wanGateway", e.target.value)}
                  data-testid="input-wan-gateway"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="wan-dns">WAN DNS</Label>
                <Input
                  id="wan-dns"
                  placeholder="8.8.8.8"
                  value={settings.wanDns || ""}
                  onChange={(e) => updateSetting("wanDns", e.target.value)}
                  data-testid="input-wan-dns"
                />
              </div>
            </div>
          )}
        </div>

        <Separator />

        {/* Management VLAN */}
        <div className="space-y-4">
          <h4 className="font-semibold">Management</h4>
          <div className="space-y-2">
            <Label htmlFor="mgmt-vlan">Management VLAN</Label>
            <Input
              id="mgmt-vlan"
              placeholder="e.g., 100 (blank for untagged)"
              value={settings.managementVlan || ""}
              onChange={(e) => updateSetting("managementVlan", e.target.value)}
              data-testid="input-aircube-mgmt-vlan"
            />
            <p className="text-xs text-muted-foreground">
              VLAN ID for device management access (optional)
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
