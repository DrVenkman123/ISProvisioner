import { drizzle as drizzleNeon } from "drizzle-orm/neon-http";
import { neon } from "@neondatabase/serverless";
import { drizzle as drizzlePostgres } from "drizzle-orm/postgres-js";
import postgres from "postgres";

if (!process.env.DATABASE_URL) {
  throw new Error("DATABASE_URL environment variable is required");
}

const databaseUrl = process.env.DATABASE_URL;

// Auto-detect database type based on URL
// Neon URLs contain "neon.tech" or use the neondb:// protocol
// Local PostgreSQL uses postgresql:// or postgres:// with localhost
const isNeonDatabase = databaseUrl.includes('neon.tech') || databaseUrl.startsWith('neondb://');

let db;

if (isNeonDatabase) {
  // Use Neon HTTP driver for cloud database
  const sql = neon(databaseUrl);
  db = drizzleNeon(sql);
} else {
  // Use regular postgres driver for local database
  const client = postgres(databaseUrl);
  db = drizzlePostgres(client);
}

export { db };
