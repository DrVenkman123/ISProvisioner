import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, boolean, jsonb, timestamp, serial } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Users table
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  role: text("role").notNull().default("tech"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  role: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// PoP Profiles
export const popProfiles = pgTable("pop_profiles", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  ssid: text("ssid").notNull(),
  wpaKey: text("wpa_key").notNull(),
  beamwidth: integer("beamwidth").notNull(),
  frequency: text("frequency"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertPopProfileSchema = createInsertSchema(popProfiles).omit({
  id: true,
  createdAt: true,
});

export type InsertPopProfile = z.infer<typeof insertPopProfileSchema>;
export type PopProfile = typeof popProfiles.$inferSelect;

// Configuration Templates
export const configTemplates = pgTable("config_templates", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  deviceType: text("device_type").notNull(),
  deviceFamily: text("device_family").notNull(),
  content: text("content").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const insertConfigTemplateSchema = createInsertSchema(configTemplates).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertConfigTemplate = z.infer<typeof insertConfigTemplateSchema>;
export type ConfigTemplate = typeof configTemplates.$inferSelect;

// Application Settings
export const settings = pgTable("settings", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  key: text("key").notNull().unique(),
  value: jsonb("value").notNull(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const insertSettingSchema = createInsertSchema(settings).omit({
  id: true,
  updatedAt: true,
});

export type InsertSetting = z.infer<typeof insertSettingSchema>;
export type Setting = typeof settings.$inferSelect;

// Provision Jobs (history)
export const provisionJobs = pgTable("provision_jobs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  deviceType: text("device_type").notNull(),
  deviceFamily: text("device_family").notNull(),
  deviceIp: text("device_ip").notNull(),
  deviceMode: text("device_mode"),
  config: jsonb("config").notNull(),
  status: text("status").notNull(),
  output: text("output"),
  startedAt: timestamp("started_at").notNull().defaultNow(),
  completedAt: timestamp("completed_at"),
});

export const insertProvisionJobSchema = createInsertSchema(provisionJobs).omit({
  id: true,
  startedAt: true,
  completedAt: true,
});

export type InsertProvisionJob = z.infer<typeof insertProvisionJobSchema>;
export type ProvisionJob = typeof provisionJobs.$inferSelect;

// Favorite Devices
export const favoriteDevices = pgTable("favorite_devices", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  ip: text("ip").notNull(),
  mac: text("mac"),
  hostname: text("hostname"),
  deviceType: text("device_type"),
  username: text("username").notNull().default("ubnt"),
  password: text("password").notNull().default("ubnt"),
  lastPingStatus: text("last_ping_status"), // 'online' | 'offline' | null
  lastPingTime: timestamp("last_ping_time"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertFavoriteDeviceSchema = createInsertSchema(favoriteDevices).omit({
  id: true,
  lastPingStatus: true,
  lastPingTime: true,
  createdAt: true,
});

export type InsertFavoriteDevice = z.infer<typeof insertFavoriteDeviceSchema>;
export type FavoriteDevice = typeof favoriteDevices.$inferSelect;

// Default Credentials
export const defaultCredentials = pgTable("default_credentials", {
  id: serial("id").primaryKey(),
  label: text("label").notNull(),
  deviceFamily: text("device_family"), // null means applies to all devices
  username: text("username").notNull(),
  password: text("password").notNull(),
  notes: text("notes"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const insertDefaultCredentialSchema = createInsertSchema(defaultCredentials).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertDefaultCredential = z.infer<typeof insertDefaultCredentialSchema>;
export type DefaultCredential = typeof defaultCredentials.$inferSelect;

// Activity Logs
export const activityLogs = pgTable("activity_logs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  eventType: text("event_type").notNull(), // 'provision', 'ping', 'pop_created', 'template_created', 'template_deleted', etc.
  deviceIp: text("device_ip"),
  deviceType: text("device_type"),
  status: text("status"), // 'success', 'error', 'in_progress', 'online', 'offline'
  metadata: jsonb("metadata"), // Additional event-specific data
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertActivityLogSchema = createInsertSchema(activityLogs).omit({
  id: true,
  createdAt: true,
});

export type InsertActivityLog = z.infer<typeof insertActivityLogSchema>;
export type ActivityLog = typeof activityLogs.$inferSelect;
