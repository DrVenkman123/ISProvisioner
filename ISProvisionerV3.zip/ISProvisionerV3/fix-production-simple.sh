#!/bin/bash
set -e

echo "=========================================="
echo "ISProvisioner Production Fix Script v2"
echo "=========================================="
echo ""

# Check if running as root
if [ "$EUID" -ne 0 ]; then 
    echo "Please run as root (use sudo)"
    exit 1
fi

APP_DIR="/opt/isp-provisioner"
APP_USER="isp_provisioner"
DB_USER="isp_provisioner"
DB_NAME="isp_provisioner"

cd $APP_DIR

echo "[1/8] Reading database password from .env..."
if [ ! -f .env ]; then
    echo "ERROR: .env file not found"
    exit 1
fi

DB_PASSWORD=$(grep "^PGPASSWORD=" .env | cut -d'=' -f2)
if [ -z "$DB_PASSWORD" ]; then
    echo "ERROR: PGPASSWORD not found in .env"
    exit 1
fi

echo "Found password: ${DB_PASSWORD}"

echo ""
echo "[2/8] Resetting PostgreSQL password to match .env..."
sudo -u postgres psql -c "ALTER USER ${DB_USER} WITH PASSWORD '${DB_PASSWORD}';"
echo "✓ Password updated"

echo ""
echo "[3/8] Creating application user if needed..."
if ! id -u $APP_USER &> /dev/null; then
    useradd -r -s /bin/bash -d $APP_DIR $APP_USER
    echo "✓ User created"
else
    echo "✓ User already exists"
fi

echo ""
echo "[4/8] Setting ownership of application files..."
chown -R $APP_USER:$APP_USER $APP_DIR
echo "✓ Ownership set"

echo ""
echo "[5/8] Updating seed-admin.ts to use postgres driver..."
cat > $APP_DIR/scripts/seed-admin.ts << 'EOF'
import postgres from 'postgres';
import bcrypt from 'bcryptjs';

async function seedAdmin() {
  const databaseUrl = process.env.DATABASE_URL;
  
  if (!databaseUrl) {
    console.error('ERROR: DATABASE_URL environment variable not set');
    process.exit(1);
  }

  const sql = postgres(databaseUrl);

  try {
    const tables = await sql`
      SELECT EXISTS (
        SELECT FROM information_schema.tables 
        WHERE table_name = 'users'
      ) as exists
    `;
    
    if (!tables[0].exists) {
      console.error('ERROR: users table does not exist. Run migrations first.');
      await sql.end();
      process.exit(1);
    }

    const existingUsers = await sql`SELECT COUNT(*) as count FROM users`;
    const userCount = parseInt(existingUsers[0].count);

    if (userCount > 0) {
      console.log(`Found ${userCount} existing user(s). Skipping admin creation.`);
      await sql.end();
      process.exit(0);
    }

    const hashedPassword = await bcrypt.hash('admin', 10);
    
    await sql`
      INSERT INTO users (username, password, role)
      VALUES ('admin', ${hashedPassword}, 'admin')
    `;

    console.log('✓ Default admin account created successfully');
    console.log('  Username: admin');
    console.log('  Password: admin');
    console.log('');
    console.log('⚠️  IMPORTANT: Change this password immediately after first login!');
    
    await sql.end();
  } catch (error) {
    console.error('ERROR creating admin user:', error);
    await sql.end();
    process.exit(1);
  }
}

seedAdmin();
EOF

chown $APP_USER:$APP_USER $APP_DIR/scripts/seed-admin.ts
echo "✓ seed-admin.ts updated"

echo ""
echo "[6/8] Running database migrations..."
sudo -u $APP_USER bash -c "cd $APP_DIR && export \$(cat .env | grep -v '^#' | xargs) && npm run db:push --force"

echo ""
echo "[7/8] Creating admin user..."
sudo -u $APP_USER bash -c "cd $APP_DIR && export \$(cat .env | grep -v '^#' | xargs) && npx tsx scripts/seed-admin.ts"

echo ""
echo "[8/8] Configuring sudo permissions..."
cat > /etc/sudoers.d/isp-provisioner << EOF
# Network scanning tools
$APP_USER ALL=(ALL) NOPASSWD: /usr/bin/arp-scan
$APP_USER ALL=(ALL) NOPASSWD: /usr/sbin/arp-scan
$APP_USER ALL=(ALL) NOPASSWD: /usr/bin/nmap
$APP_USER ALL=(ALL) NOPASSWD: /usr/local/bin/nmap
$APP_USER ALL=(ALL) NOPASSWD: /usr/bin/bluetoothctl
$APP_USER ALL=(ALL) NOPASSWD: /usr/bin/hciconfig
$APP_USER ALL=(ALL) NOPASSWD: /usr/bin/iwconfig
$APP_USER ALL=(ALL) NOPASSWD: /sbin/iwconfig
EOF
chmod 440 /etc/sudoers.d/isp-provisioner
echo "✓ Sudo permissions configured"

echo ""
echo "[9/9] Creating and starting systemd service..."
cat > /etc/systemd/system/isp-provisioner.service << EOF
[Unit]
Description=ISProvisioner v2.0 Network Device Provisioning System
After=network.target postgresql.service

[Service]
Type=simple
User=$APP_USER
WorkingDirectory=$APP_DIR
ExecStart=/usr/bin/node $APP_DIR/dist/index.js
Restart=on-failure
RestartSec=10
StandardOutput=journal
StandardError=journal
SyslogIdentifier=isp-provisioner

Environment=NODE_ENV=production
EnvironmentFile=$APP_DIR/.env

NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=strict
ProtectHome=true
ReadWritePaths=$APP_DIR

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable isp-provisioner
systemctl start isp-provisioner
sleep 2

echo ""
echo "=========================================="
echo "Service Status:"
echo "=========================================="
systemctl status isp-provisioner --no-pager -l || true

echo ""
echo "=========================================="
echo "✓ Fix Complete!"
echo "=========================================="
echo ""
echo "Application URL: http://$(hostname -I | awk '{print $1}'):5000"
echo ""
echo "Next steps:"
echo "  1. Clear browser cookies for the URL above"
echo "  2. Login with: admin / admin"
echo "  3. Change the password immediately!"
echo ""
echo "Check logs: sudo journalctl -u isp-provisioner -f"
echo ""
