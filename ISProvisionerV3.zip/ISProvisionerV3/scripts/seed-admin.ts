import postgres from 'postgres';
import bcrypt from 'bcryptjs';

async function seedAdmin() {
  const databaseUrl = process.env.DATABASE_URL;
  
  if (!databaseUrl) {
    console.error('ERROR: DATABASE_URL environment variable not set');
    process.exit(1);
  }

  // Use postgres driver for local PostgreSQL (supports both local and Neon)
  const sql = postgres(databaseUrl);

  try {
    // Check if users table exists
    const tables = await sql`
      SELECT EXISTS (
        SELECT FROM information_schema.tables 
        WHERE table_name = 'users'
      ) as exists
    `;
    
    if (!tables[0].exists) {
      console.error('ERROR: users table does not exist. Run migrations first.');
      await sql.end();
      process.exit(1);
    }

    // Check if any users exist
    const existingUsers = await sql`SELECT COUNT(*) as count FROM users`;
    const userCount = parseInt(existingUsers[0].count);

    if (userCount > 0) {
      console.log(`Found ${userCount} existing user(s). Skipping admin creation.`);
      console.log('To reset, run: sudo -u postgres psql isp_provisioner -c "DELETE FROM users;"');
      await sql.end();
      process.exit(0);
    }

    // Create admin:admin user
    const hashedPassword = await bcrypt.hash('admin', 10);
    
    await sql`
      INSERT INTO users (username, password, role)
      VALUES ('admin', ${hashedPassword}, 'admin')
    `;

    console.log('✓ Default admin account created successfully');
    console.log('  Username: admin');
    console.log('  Password: admin');
    console.log('');
    console.log('⚠️  IMPORTANT: Change this password immediately after first login!');
    
    await sql.end();
  } catch (error) {
    console.error('ERROR creating admin user:', error);
    await sql.end();
    process.exit(1);
  }
}

seedAdmin();
