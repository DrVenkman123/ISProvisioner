# ISProvisioner v2.0 - Production Deployment Guide

## Quick Deployment (Ubuntu Server 22.04+)

For a fresh Ubuntu server, simply run the automated installer:

```bash
# Download the application
cd /opt
git clone https://github.com/yourusername/isp-provisioner.git
cd isp-provisioner

# Run the installer (requires root)
sudo chmod +x install.sh
sudo ./install.sh
```

The installer will:
1. Install Node.js 20+
2. Install PostgreSQL
3. Install network scanning tools (nmap, arp-scan, wireless-tools, bluetooth)
4. Create database and user
5. Build the application
6. Configure sudo permissions for network scanning (least-privilege security)
7. Create systemd service (running as dedicated `isp_provisioner` user with security hardening)
8. Start the application on port 5000

Default credentials: **admin / admin** (change after first login)

---

## Manual Deployment Steps

If you prefer manual deployment or need to update an existing installation:

### 1. System Requirements

- Ubuntu Server 22.04 LTS or newer
- Node.js 20+
- PostgreSQL 14+
- Network scanning tools

### 2. Install Dependencies

```bash
# Update system
sudo apt-get update && sudo apt-get upgrade -y

# Install Node.js 20
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt-get install -y nodejs

# Install PostgreSQL
sudo apt-get install -y postgresql postgresql-contrib

# Install network scanning and discovery tools
sudo apt-get install -y nmap arp-scan wireless-tools iw

# Install Bluetooth tools (optional)
sudo apt-get install -y bluetooth bluez bluez-tools
```

### 3. Create Database

```bash
# Switch to postgres user
sudo -u postgres psql

-- In PostgreSQL prompt:
CREATE USER isp_provisioner WITH PASSWORD 'your_secure_password';
CREATE DATABASE isp_provisioner OWNER isp_provisioner;
GRANT ALL PRIVILEGES ON DATABASE isp_provisioner TO isp_provisioner;
\q
```

### 4. Configure Application

```bash
# Create application directory
sudo mkdir -p /opt/isp-provisioner
cd /opt/isp-provisioner

# Copy application files (adjust source path as needed)
sudo cp -r /path/to/source/* .

# Create .env file
sudo nano .env
```

Add the following to `.env`:

```env
# Database Configuration
DATABASE_URL=postgresql://isp_provisioner:your_secure_password@localhost:5432/isp_provisioner
PGHOST=localhost
PGPORT=5432
PGUSER=isp_provisioner
PGPASSWORD=your_secure_password
PGDATABASE=isp_provisioner

# Session Configuration (generate with: openssl rand -hex 32)
SESSION_SECRET=your_random_session_secret_here

# Application Configuration
NODE_ENV=production
PORT=5000
```

Set proper permissions:
```bash
sudo chmod 600 .env
```

### 5. Build Application

```bash
cd /opt/isp-provisioner

# Install dependencies
npm install

# Build application
npm run build

# Push database schema
npm run db:push

# Create default admin user
npx tsx scripts/seed-admin.ts
```

### 6. Create Systemd Service

```bash
sudo nano /etc/systemd/system/isp-provisioner.service
```

Add the following content:

```ini
[Unit]
Description=ISProvisioner v2.0 Network Device Provisioning System
After=network.target postgresql.service

[Service]
Type=simple
User=isp_provisioner
WorkingDirectory=/opt/isp-provisioner
ExecStart=/usr/bin/node /opt/isp-provisioner/dist/index.js
Restart=on-failure
RestartSec=10
StandardOutput=journal
StandardError=journal
SyslogIdentifier=isp-provisioner

# Environment
Environment=NODE_ENV=production
EnvironmentFile=/opt/isp-provisioner/.env

# Security hardening
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=strict
ProtectHome=true
ReadWritePaths=/opt/isp-provisioner

[Install]
WantedBy=multi-user.target
```

Configure sudo permissions for network scanning:

```bash
sudo nano /etc/sudoers.d/isp-provisioner
```

Add the following content:

```bash
# Allow isp_provisioner user to run network scanning tools without password
isp_provisioner ALL=(ALL) NOPASSWD: /usr/bin/arp-scan
isp_provisioner ALL=(ALL) NOPASSWD: /usr/sbin/arp-scan
isp_provisioner ALL=(ALL) NOPASSWD: /usr/bin/nmap
isp_provisioner ALL=(ALL) NOPASSWD: /usr/local/bin/nmap
isp_provisioner ALL=(ALL) NOPASSWD: /usr/bin/bluetoothctl
isp_provisioner ALL=(ALL) NOPASSWD: /usr/bin/hciconfig
isp_provisioner ALL=(ALL) NOPASSWD: /usr/bin/iwconfig
isp_provisioner ALL=(ALL) NOPASSWD: /sbin/iwconfig
```

Set proper permissions:

```bash
sudo chmod 440 /etc/sudoers.d/isp-provisioner
```

Enable and start the service:

```bash
sudo systemctl daemon-reload
sudo systemctl enable isp-provisioner
sudo systemctl start isp-provisioner
```

### 7. Verify Deployment

```bash
# Check service status
sudo systemctl status isp-provisioner

# View logs
sudo journalctl -u isp-provisioner -f

# Test application
curl http://localhost:5000
```

Access the web interface at `http://your-server-ip:5000`

---

## Important Configuration Notes

### Session Cookie Configuration

The application uses HTTP cookies for session management. For production deployment on HTTP (not HTTPS), the session configuration in `server/index.ts` must have:

```typescript
cookie: {
  secure: false,        // Must be false for HTTP
  httpOnly: true,       // Prevents XSS attacks
  maxAge: 1000 * 60 * 60 * 24 * 7,  // 7 days
  sameSite: 'lax',      // CSRF protection
}
```

**If you're getting 401 errors on all API requests**, this is likely the issue. The cookie `secure: true` setting only works with HTTPS.

### Database Driver

For local PostgreSQL (not Neon serverless), the application uses the `postgres` package instead of `@neondatabase/serverless`. This is already configured in the codebase.

Ensure `shared/db.ts` uses:
```typescript
import postgres from 'postgres';
```

### Privilege Escalation for Network Scanning

The application needs elevated privileges for network scanning tools. Instead of running the entire web server as root (which is a security risk), the installer configures **sudoers** to allow specific commands without password:

```bash
# /etc/sudoers.d/isp-provisioner
isp_provisioner ALL=(ALL) NOPASSWD: /usr/bin/arp-scan
isp_provisioner ALL=(ALL) NOPASSWD: /usr/bin/nmap
isp_provisioner ALL=(ALL) NOPASSWD: /usr/bin/bluetoothctl
isp_provisioner ALL=(ALL) NOPASSWD: /usr/bin/hciconfig
isp_provisioner ALL=(ALL) NOPASSWD: /usr/bin/iwconfig
```

This follows the **principle of least privilege** - only the scanning tools run with elevated permissions, not the entire Node.js application.

**Security Considerations:**
- The web server runs as dedicated user `isp_provisioner` (not root)
- Only specific network scanning binaries can be run with sudo
- Do NOT expose port 5000 directly to the internet
- Use a reverse proxy (nginx/Apache) with HTTPS in production
- Firewall the VM to only allow trusted networks

---

## Firewall Configuration

### Basic UFW Setup

```bash
# Install UFW
sudo apt-get install -y ufw

# Allow SSH (important - don't lock yourself out!)
sudo ufw allow 22/tcp

# Allow ISProvisioner (from trusted network only)
sudo ufw allow from 10.0.0.0/8 to any port 5000 proto tcp

# Enable firewall
sudo ufw enable
```

### Recommended: Reverse Proxy with SSL

For production, use nginx with Let's Encrypt:

```bash
# Install nginx
sudo apt-get install -y nginx certbot python3-certbot-nginx

# Create nginx config
sudo nano /etc/nginx/sites-available/isp-provisioner
```

Example nginx configuration:

```nginx
server {
    listen 80;
    server_name provisioner.example.com;

    location / {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

Enable site and get SSL certificate:

```bash
sudo ln -s /etc/nginx/sites-available/isp-provisioner /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl reload nginx
sudo certbot --nginx -d provisioner.example.com
```

**If using HTTPS with reverse proxy**, update `server/index.ts` to set `secure: true` in cookie settings.

---

## Updating Existing Installation

To update an existing installation:

```bash
cd /opt/isp-provisioner

# Stop service
sudo systemctl stop isp-provisioner

# Backup database
sudo -u postgres pg_dump isp_provisioner > backup_$(date +%Y%m%d).sql

# Pull latest code
git pull

# Install dependencies
npm install

# Rebuild
npm run build

# Update database schema
npm run db:push

# Restart service
sudo systemctl start isp-provisioner

# Verify
sudo systemctl status isp-provisioner
sudo journalctl -u isp-provisioner -n 50
```

---

## Troubleshooting

### 401 Authentication Errors

**Symptom:** All API requests return `{"error":"Authentication required"}`

**Solutions:**
1. **Clear browser cookies** for the application
2. Check session cookie configuration in `server/index.ts`:
   - For HTTP: `secure: false`
   - For HTTPS: `secure: true`
3. Verify `SESSION_SECRET` is set in `.env`
4. Check logs: `sudo journalctl -u isp-provisioner -n 100 | grep -i session`

### Database Connection Issues

**Symptom:** Application fails to start with database errors

**Solutions:**
1. Verify PostgreSQL is running: `sudo systemctl status postgresql`
2. Check credentials in `.env` match database:
   ```bash
   sudo -u postgres psql -c "\du"  # List users
   sudo -u postgres psql -c "\l"   # List databases
   ```
3. Test connection manually:
   ```bash
   psql -h localhost -U isp_provisioner -d isp_provisioner
   ```
4. Verify password in `.env` exactly matches (case-sensitive)

### Network Scanning Not Working

**Symptom:** LAN scan returns no devices

**Solutions:**
1. Verify tools installed:
   ```bash
   which arp-scan
   which nmap
   ```
2. Check sudo permissions configured: `sudo cat /etc/sudoers.d/isp-provisioner`
3. Test manually with sudo:
   ```bash
   sudo arp-scan --interface=eth0 --localnet
   sudo nmap -sn 192.168.1.0/24
   ```
4. Check network interface name: `ip addr show`
5. View detailed logs: `sudo journalctl -u isp-provisioner -f`

### WiFi/Bluetooth Discovery Not Working

**Symptom:** WiFi or Bluetooth scans fail

**Solutions:**
1. Verify hardware exists:
   ```bash
   iwconfig           # WiFi adapters
   hciconfig          # Bluetooth adapters
   ```
2. Install tools if missing:
   ```bash
   sudo apt-get install wireless-tools bluetooth bluez
   ```
3. Enable Bluetooth:
   ```bash
   sudo systemctl start bluetooth
   sudo systemctl enable bluetooth
   ```
4. Check sudo permissions are configured in `/etc/sudoers.d/isp-provisioner`
5. Most servers don't have WiFi/Bluetooth - use LAN scanning instead

### Service Won't Start

**Symptom:** `systemctl start isp-provisioner` fails

**Solutions:**
1. Check logs: `sudo journalctl -u isp-provisioner -n 50`
2. Verify build completed: `ls -lh /opt/isp-provisioner/dist/index.js`
3. Test manually:
   ```bash
   cd /opt/isp-provisioner
   export $(cat .env | grep -v '^#' | xargs)
   node dist/index.js
   ```
4. Check port not in use: `sudo lsof -i :5000`

---

## Maintenance

### View Logs

```bash
# Real-time logs
sudo journalctl -u isp-provisioner -f

# Recent logs
sudo journalctl -u isp-provisioner -n 100

# Logs from specific time
sudo journalctl -u isp-provisioner --since "1 hour ago"

# Search logs
sudo journalctl -u isp-provisioner | grep -i error
```

### Database Backup

```bash
# Backup
sudo -u postgres pg_dump isp_provisioner > isp_backup_$(date +%Y%m%d).sql

# Restore
sudo -u postgres psql isp_provisioner < isp_backup_20231029.sql
```

### Restart Service

```bash
sudo systemctl restart isp-provisioner
```

---

## Security Checklist

- [ ] Change default admin password immediately after first login
- [ ] Set strong `SESSION_SECRET` in `.env`
- [ ] Set strong PostgreSQL password
- [ ] Configure firewall to restrict access to port 5000
- [ ] Consider using HTTPS with reverse proxy
- [ ] Keep system packages updated: `sudo apt-get update && sudo apt-get upgrade`
- [ ] Monitor logs regularly for suspicious activity
- [ ] Backup database regularly
- [ ] Limit SSH access to trusted IPs only
- [ ] Disable root SSH login: `PermitRootLogin no` in `/etc/ssh/sshd_config`

---

## Support

Default credentials: `admin` / `admin`

Donation: CashApp **$EricElston123**

For issues, check logs first:
```bash
sudo journalctl -u isp-provisioner -n 100
```
