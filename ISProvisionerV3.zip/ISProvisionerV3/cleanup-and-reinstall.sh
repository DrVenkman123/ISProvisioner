#!/bin/bash

# ISProvisioner v3.0 - Cleanup and Reinstall Script
# This script cleans up a failed installation and reinstalls properly

set -e

echo "============================================="
echo "ISProvisioner v3.0 - Cleanup & Reinstall"
echo "============================================="
echo ""

# Check if running as root
if [ "$EUID" -ne 0 ]; then 
  echo "Please run as root (use sudo ./cleanup-and-reinstall.sh)"
  exit 1
fi

APP_DIR="/opt/isp-provisioner"
APP_USER="isp-provisioner"
DB_NAME="isp_provisioner"
DB_USER="isp_provisioner"
DB_PASSWORD=$(openssl rand -base64 32 | tr -d "=+/" | cut -c1-25)

echo "This script will:"
echo "  1. Stop all ISProvisioner services"
echo "  2. Clean up PostgreSQL database and user"
echo "  3. Remove old installation files"
echo "  4. Run fresh installation"
echo ""
read -p "Continue? (y/n) " -n 1 -r
echo ""
if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    echo "Cleanup cancelled."
    exit 1
fi

echo ""
echo "[1/5] Stopping services..."
systemctl stop isp-provisioner 2>/dev/null || true
systemctl stop isprovisioner 2>/dev/null || true
systemctl disable isp-provisioner 2>/dev/null || true
systemctl disable isprovisioner 2>/dev/null || true

echo ""
echo "[2/5] Cleaning up PostgreSQL..."

# Terminate all connections
echo "Terminating database connections..."
sudo -u postgres psql <<EOF 2>/dev/null || true
SELECT pg_terminate_backend(pid) 
FROM pg_stat_activity 
WHERE datname = '${DB_NAME}' AND pid <> pg_backend_pid();
EOF

# Give connections time to terminate
sleep 2

# Drop database and role (outside of functions - this was the bug!)
echo "Dropping database and user..."
sudo -u postgres psql <<EOF 2>/dev/null || true
DROP DATABASE IF EXISTS ${DB_NAME};
DROP DATABASE IF EXISTS isprov;
EOF

sudo -u postgres psql <<EOF 2>/dev/null || true
DROP ROLE IF EXISTS ${DB_USER};
DROP ROLE IF EXISTS isprov;
EOF

echo "✓ PostgreSQL cleaned up"

echo ""
echo "[3/5] Removing old systemd services..."
rm -f /etc/systemd/system/isp-provisioner.service
rm -f /etc/systemd/system/isprovisioner.service
rm -rf /etc/systemd/system/isp-provisioner.service.d
rm -rf /etc/systemd/system/isprovisioner.service.d
systemctl daemon-reload

echo ""
echo "[4/5] Backing up old installation..."
if [ -d "$APP_DIR" ]; then
    BACKUP_DIR="${APP_DIR}.old.$(date +%Y%m%d_%H%M%S)"
    mv $APP_DIR $BACKUP_DIR
    echo "Old installation backed up to: $BACKUP_DIR"
else
    echo "No existing installation found"
fi

# Also check for /opt/ISProvisioner
if [ -d "/opt/ISProvisioner" ]; then
    BACKUP_DIR="/opt/ISProvisioner.old.$(date +%Y%m%d_%H%M%S)"
    mv /opt/ISProvisioner $BACKUP_DIR
    echo "Old installation backed up to: $BACKUP_DIR"
fi

echo ""
echo "[5/5] Running fresh installation..."
echo ""

# Set non-interactive mode for the installer
export NON_INTERACTIVE=true

# Run the installer
if [ -f "./install.sh" ]; then
    chmod +x ./install.sh
    ./install.sh
else
    echo "ERROR: install.sh not found in current directory"
    exit 1
fi

echo ""
echo "============================================="
echo "Cleanup and Reinstall Complete!"
echo "============================================="
echo ""
echo "Your ISProvisioner v3.0 installation is now clean and running."
echo ""
