#!/bin/bash
set -e

echo "=========================================="
echo "ISProvisioner Production Fix Script"
echo "=========================================="
echo ""

# Check if running as root
if [ "$EUID" -ne 0 ]; then 
    echo "Please run as root (use sudo)"
    exit 1
fi

APP_DIR="/opt/isp-provisioner"
DB_USER="isp_provisioner"
DB_NAME="isp_provisioner"

cd $APP_DIR

echo "[1/6] Reading database password from .env..."
if [ ! -f .env ]; then
    echo "ERROR: .env file not found"
    exit 1
fi

DB_PASSWORD=$(grep "^PGPASSWORD=" .env | cut -d'=' -f2)
if [ -z "$DB_PASSWORD" ]; then
    echo "ERROR: PGPASSWORD not found in .env"
    exit 1
fi

echo "Found password in .env: ${DB_PASSWORD}"

echo ""
echo "[2/6] Resetting PostgreSQL password to match .env..."
sudo -u postgres psql -c "ALTER USER ${DB_USER} WITH PASSWORD '${DB_PASSWORD}';"
echo "✓ Password updated successfully"

echo ""
echo "[3/6] Creating updated seed-admin.ts script..."
cat > $APP_DIR/scripts/seed-admin.ts << 'EOF'
import postgres from 'postgres';
import bcrypt from 'bcryptjs';

async function seedAdmin() {
  const databaseUrl = process.env.DATABASE_URL;
  
  if (!databaseUrl) {
    console.error('ERROR: DATABASE_URL environment variable not set');
    process.exit(1);
  }

  // Use postgres driver for local PostgreSQL (supports both local and Neon)
  const sql = postgres(databaseUrl);

  try {
    // Check if users table exists
    const tables = await sql`
      SELECT EXISTS (
        SELECT FROM information_schema.tables 
        WHERE table_name = 'users'
      ) as exists
    `;
    
    if (!tables[0].exists) {
      console.error('ERROR: users table does not exist. Run migrations first.');
      await sql.end();
      process.exit(1);
    }

    // Check if any users exist
    const existingUsers = await sql`SELECT COUNT(*) as count FROM users`;
    const userCount = parseInt(existingUsers[0].count);

    if (userCount > 0) {
      console.log(`Found ${userCount} existing user(s). Skipping admin creation.`);
      console.log('To reset, run: sudo -u postgres psql isp_provisioner -c "DELETE FROM users;"');
      await sql.end();
      process.exit(0);
    }

    // Create admin:admin user
    const hashedPassword = await bcrypt.hash('admin', 10);
    
    await sql`
      INSERT INTO users (username, password, role)
      VALUES ('admin', ${hashedPassword}, 'admin')
    `;

    console.log('✓ Default admin account created successfully');
    console.log('  Username: admin');
    console.log('  Password: admin');
    console.log('');
    console.log('⚠️  IMPORTANT: Change this password immediately after first login!');
    
    await sql.end();
  } catch (error) {
    console.error('ERROR creating admin user:', error);
    await sql.end();
    process.exit(1);
  }
}

seedAdmin();
EOF

chown isp_provisioner:isp_provisioner $APP_DIR/scripts/seed-admin.ts
echo "✓ seed-admin.ts updated with postgres driver"

echo ""
echo "[4/6] Running database migrations..."
sudo -u isp_provisioner bash -c "cd $APP_DIR && export \$(cat .env | grep -v '^#' | xargs) && npm run db:push --force"

echo ""
echo "[5/6] Creating admin user..."
sudo -u isp_provisioner bash -c "cd $APP_DIR && export \$(cat .env | grep -v '^#' | xargs) && npx tsx scripts/seed-admin.ts"

echo ""
echo "[6/6] Configuring sudo permissions for network scanning..."
cat > /etc/sudoers.d/isp-provisioner << EOF
# Allow isp_provisioner user to run network scanning tools without password
isp_provisioner ALL=(ALL) NOPASSWD: /usr/bin/arp-scan
isp_provisioner ALL=(ALL) NOPASSWD: /usr/sbin/arp-scan
isp_provisioner ALL=(ALL) NOPASSWD: /usr/bin/nmap
isp_provisioner ALL=(ALL) NOPASSWD: /usr/local/bin/nmap
isp_provisioner ALL=(ALL) NOPASSWD: /usr/bin/bluetoothctl
isp_provisioner ALL=(ALL) NOPASSWD: /usr/bin/hciconfig
isp_provisioner ALL=(ALL) NOPASSWD: /usr/bin/iwconfig
isp_provisioner ALL=(ALL) NOPASSWD: /sbin/iwconfig
EOF
chmod 440 /etc/sudoers.d/isp-provisioner
echo "✓ Sudo permissions configured"

echo ""
echo "[7/7] Restarting application service..."
systemctl daemon-reload
systemctl restart isp-provisioner
sleep 2
systemctl status isp-provisioner --no-pager -l

echo ""
echo "=========================================="
echo "✓ Fix Complete!"
echo "=========================================="
echo ""
echo "Next steps:"
echo "  1. Clear browser cookies for http://10.0.0.105:5000"
echo "  2. Login with admin/admin"
echo "  3. Change the admin password immediately"
echo ""
echo "Check logs: sudo journalctl -u isp-provisioner -f"
echo ""
