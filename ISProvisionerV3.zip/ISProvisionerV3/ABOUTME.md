# ISProvisioner v3.0

## Overview

ISProvisioner v3.0 is an enterprise-grade network device provisioning web application designed for configuring and managing Ubiquiti network equipment (NanoStation, NanoBeam, LiteAP, AirCube, UISP switches, EdgeRouter, etc.). The application provides a streamlined workflow for device discovery, configuration, and deployment through an intuitive web interface with real-time SSH execution feedback. Features include IPv4/IPv6 dual-stack support, template-based provisioning, activity logging, and comprehensive device management.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Framework**: React 18 with TypeScript running on Vite for fast development and optimized production builds.

**UI Component System**: Built on shadcn/ui (Radix UI primitives) following a Material/Carbon Design-inspired system approach with enterprise productivity patterns. The design emphasizes functional hierarchy, visual clarity, and progressive disclosure for complex technical workflows.

**State Management**: TanStack Query (React Query) for server state management with optimistic updates and automatic cache invalidation. Local component state managed with React hooks.

**Routing**: Wouter for lightweight client-side routing with support for dashboard, provisioning workflow, template management, and settings pages.

**Styling**: Tailwind CSS with custom design tokens for spacing (2-16 units), typography (Inter primary, JetBrains Mono for technical data), and a comprehensive color system supporting both light and dark modes. Custom CSS variables enable dynamic theming.

**Form Handling**: React Hook Form with Zod validation for type-safe form management across device configuration workflows.

### Backend Architecture

**Runtime**: Node.js with Express.js HTTP server providing RESTful API endpoints.

**Language**: TypeScript with strict mode enabled for type safety across client, server, and shared code.

**API Design**: Resource-oriented REST API with dedicated route handlers for:
- PoP (Point of Presence) profiles
- Configuration templates  
- Device provisioning jobs
- System settings
- Device discovery

**Session Management**: Cookie-based sessions planned (currently mocked in frontend) with JWT authentication strategy referenced in design documents.

**File Organization**: Monorepo structure with shared schema definitions between client and server to ensure type consistency.

### Data Storage

**Primary Database**: PostgreSQL accessed through Neon serverless driver for scalable cloud-native deployment.

**ORM**: Drizzle ORM with schema-first approach using `drizzle-kit` for migrations. Schema includes:
- Users table with role-based access (admin, tech, viewer)
- PoP profiles (SSIDs, WPA keys, beamwidths)
- Configuration templates (device-specific configs)
- Provision jobs (audit trail)
- Key-value settings store

**Data Models**: Strongly typed with Drizzle schema exported as TypeScript types and Zod validation schemas for runtime safety.

### Device Provisioning System

**SSH Integration**: ssh2 library provides low-level SSH client for executing configuration commands on network devices.

**Strategy Pattern**: Device family-specific provisioning strategies handle differences between:
- airMAX devices (system.cfg → cfgmtd → reboot)
- AirCube (UCI scripts)
- UISP switches (JSON API)
- EdgeMAX routers (CLI commands)
- Wave devices (proprietary protocols)

**Discovery Mechanisms**: Multi-method device discovery supporting:
- LAN scanning (nmap-style CIDR-based)
- WiFi adapter scanning
- Bluetooth discovery (for Wave devices)
- ARP table inspection

**Configuration Templates**: Pre-built or user-uploaded device configurations stored in database with version control and device family filtering.

### Interface Configuration

**Advanced Routing**: Support for complex network topologies with:
- IPv4/IPv6 protocol selection with dynamic placeholder hints
- WLAN0/LAN0 interface management
- Bridge configurations
- VLAN tagging (management and data VLANs)
- Static IP and DHCP modes
- MTU and Ethernet speed control

**Port Management**: Visual grid-based interface for switch port configuration with per-port VLAN and PoE settings (24V 2-pair/4-pair).

## External Dependencies

### Third-Party Services

**Neon Database**: Serverless PostgreSQL hosting with HTTP-based connection pooling for production deployments.

**UISP Integration**: Optional integration with Ubiquiti UISP management platform for automated device adoption using API tokens stored in settings.

### Key NPM Packages

**UI Components**: 
- @radix-ui/* (20+ primitive components for accessible UI)
- class-variance-authority + clsx for dynamic styling
- cmdk for command palette
- react-day-picker for date inputs

**Data & Forms**:
- @tanstack/react-query for async state
- @hookform/resolvers + zod for validation
- drizzle-orm + drizzle-zod for database

**Network Operations**:
- ssh2 for SSH connections
- node-arp for MAC address lookup
- node-wifi for wireless adapter discovery

**Authentication** (planned):
- jsonwebtoken for JWT tokens
- connect-pg-simple for PostgreSQL session store

**Development Tools**:
- Vite with HMR and React Fast Refresh
- TypeScript with path aliases (@/, @shared/)
- Replit-specific plugins for cloud IDE integration
- esbuild for production server bundling