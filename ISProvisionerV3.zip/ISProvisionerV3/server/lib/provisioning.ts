import { SSHClient } from './ssh';

export interface DeviceConfig {
  deviceName: string;
  managementIp: string;
  username: string;
  password: string;
  ipMode: 'dhcp' | 'manual';
  staticIp?: string;
  netmask?: string;
  gateway?: string;
  dns?: string;
  managementVlan?: string;
  dataVlans: string[];
  mtu?: string;
  ethernetSpeed: 'auto' | '100' | '1000';
  installDate: string;
  
  // Radio-specific
  mode?: 'ap' | 'station';
  ssid?: string;
  wpaKey?: string;
  channel?: string;
  beamwidth?: number;
  
  // Switch-specific
  ports?: Array<{
    portNumber: number;
    vlan: string;
    poe: '24v-2pair' | '24v-4pair' | 'none';
  }>;
  
  // Interface config
  wlan0?: {
    ssid: string;
    channel: string;
    mode: 'ap' | 'station';
    enabled: boolean;
  };
  lan0?: {
    ipAddress: string;
    subnet: string;
    dhcp: boolean;
  };
  bridge?: {
    enabled: boolean;
    interfaces: string[];
  };
}

export type DeviceFamily = 'airmax' | 'aircube' | 'wave' | 'edgemax' | 'uisp-switch';

export interface ProvisionStrategy {
  generateConfig(config: DeviceConfig): string;
  apply(client: SSHClient, configContent: string, config: DeviceConfig): Promise<string>;
}

// airMAX strategy (NanoStation, NanoBeam, LiteAP)
export class AirMaxStrategy implements ProvisionStrategy {
  generateConfig(config: DeviceConfig): string {
    const lines: string[] = [];
    
    // Wireless config
    if (config.mode === 'ap') {
      lines.push(`wireless.1.mode=master`);
      lines.push(`wireless.1.ssid=${config.ssid || ''}`);
      lines.push(`wireless.1.security=wpapsk`);
      lines.push(`wireless.1.key=${config.wpaKey || ''}`);
      lines.push(`wireless.1.beamwidth=${config.beamwidth || 60}`);
      lines.push(`wireless.1.hide_ssid=0`);
    } else if (config.mode === 'station') {
      lines.push(`wireless.1.mode=sta`);
      lines.push(`wireless.1.ssid=${config.ssid || ''}`);
      lines.push(`wireless.1.security=wpapsk`);
      lines.push(`wireless.1.key=${config.wpaKey || ''}`);
    }
    
    // Network config
    lines.push(`system.hostname=${config.deviceName}`);
    
    if (config.ipMode === 'manual' && config.staticIp) {
      lines.push(`netconf.1.ip=${config.staticIp}`);
      lines.push(`netconf.1.netmask=${config.netmask || '255.255.255.0'}`);
      if (config.gateway) lines.push(`netconf.1.gateway=${config.gateway}`);
    } else {
      lines.push(`netconf.1.autoip.status=enabled`);
    }
    
    if (config.dns) {
      lines.push(`dns.1.server=${config.dns}`);
    }
    
    // VLAN config
    if (config.managementVlan) {
      lines.push(`netconf.1.vlan.status=enabled`);
      lines.push(`netconf.1.vlan.id=${config.managementVlan}`);
    }
    
    // MTU
    if (config.mtu) {
      lines.push(`netconf.1.mtu=${config.mtu}`);
    }
    
    // Users
    lines.push(`users.1.name=${config.username}`);
    lines.push(`users.1.password=${config.password}`);
    
    return lines.join('\n');
  }
  
  async apply(client: SSHClient, configContent: string, config: DeviceConfig): Promise<string> {
    let output = '';
    
    // Upload config to /tmp/system.cfg
    output += 'Uploading configuration file...\n';
    await client.uploadFile(configContent, '/tmp/system.cfg');
    output += 'Configuration file uploaded to /tmp/system.cfg\n';
    
    // Apply config
    output += 'Applying configuration with cfgmtd...\n';
    const cfgResult = await client.exec('cfgmtd -w -p /etc/');
    output += `cfgmtd stdout: ${cfgResult.stdout}\n`;
    if (cfgResult.stderr) output += `cfgmtd stderr: ${cfgResult.stderr}\n`;
    
    // Set install date
    const date = new Date(config.installDate).toISOString();
    output += `Setting install date to ${date}...\n`;
    const dateResult = await client.exec(`date -s "${date}" || true`);
    if (dateResult.stdout) output += `date stdout: ${dateResult.stdout}\n`;
    
    // Save and reboot
    output += 'Saving configuration...\n';
    const saveResult = await client.exec('save');
    output += `save stdout: ${saveResult.stdout}\n`;
    
    output += 'Rebooting device...\n';
    await client.exec('reboot');
    output += 'Reboot command sent\n';
    
    return output;
  }
}

// airCube strategy (UCI-based)
export class AirCubeStrategy implements ProvisionStrategy {
  generateConfig(config: DeviceConfig): string {
    const commands: string[] = [];
    
    commands.push('#!/bin/sh');
    commands.push('set -e');
    
    // Wireless config
    if (config.mode === 'ap') {
      commands.push(`uci set wireless.@wifi-iface[0].mode='ap'`);
      commands.push(`uci set wireless.@wifi-iface[0].ssid='${config.ssid || ''}'`);
      commands.push(`uci set wireless.@wifi-iface[0].encryption='psk2'`);
      commands.push(`uci set wireless.@wifi-iface[0].key='${config.wpaKey || ''}'`);
      commands.push(`uci commit wireless`);
    }
    
    // Hostname
    commands.push(`uci set system.@system[0].hostname='${config.deviceName}'`);
    commands.push(`uci commit system`);
    
    // Network config
    if (config.ipMode === 'manual' && config.staticIp) {
      commands.push(`uci set network.lan.proto='static'`);
      commands.push(`uci set network.lan.ipaddr='${config.staticIp}'`);
      commands.push(`uci set network.lan.netmask='${config.netmask || '255.255.255.0'}'`);
      if (config.gateway) {
        commands.push(`uci set network.lan.gateway='${config.gateway}'`);
      }
      commands.push(`uci commit network`);
    }
    
    // VLAN config for management
    if (config.managementVlan) {
      commands.push(`uci set network.lan.vid='${config.managementVlan}'`);
      commands.push(`uci commit network`);
    }
    
    commands.push('reboot');
    
    return commands.join('\n');
  }
  
  async apply(client: SSHClient, configContent: string, config: DeviceConfig): Promise<string> {
    let output = '';
    
    // Upload script
    output += 'Uploading provisioning script...\n';
    await client.uploadFile(configContent, '/tmp/provision.sh');
    output += 'Script uploaded to /tmp/provision.sh\n';
    
    // Make executable and run
    output += 'Making script executable...\n';
    const chmodResult = await client.exec('chmod +x /tmp/provision.sh');
    output += `chmod stdout: ${chmodResult.stdout}\n`;
    
    output += 'Executing provisioning script...\n';
    const execResult = await client.exec('sh /tmp/provision.sh');
    output += `Script stdout: ${execResult.stdout}\n`;
    if (execResult.stderr) output += `Script stderr: ${execResult.stderr}\n`;
    
    return output;
  }
}

// EdgeMAX strategy (EdgeRouter/EdgeSwitch)
export class EdgeMaxStrategy implements ProvisionStrategy {
  generateConfig(config: DeviceConfig): string {
    const commands: string[] = [];
    
    commands.push('configure');
    
    // Hostname
    commands.push(`set system host-name ${config.deviceName}`);
    
    // Network config
    if (config.ipMode === 'manual' && config.staticIp) {
      commands.push(`set interfaces ethernet eth0 address ${config.staticIp}/${this.cidrFromNetmask(config.netmask || '255.255.255.0')}`);
      if (config.gateway) {
        commands.push(`set protocols static route 0.0.0.0/0 next-hop ${config.gateway}`);
      }
    }
    
    // DNS
    if (config.dns) {
      commands.push(`set system name-server ${config.dns}`);
    }
    
    commands.push('commit');
    commands.push('save');
    commands.push('exit');
    
    return commands.join('\n');
  }
  
  private cidrFromNetmask(netmask: string): number {
    return netmask.split('.').map(octet => 
      (parseInt(octet) >>> 0).toString(2).split('1').length - 1
    ).reduce((a, b) => a + b, 0);
  }
  
  async apply(client: SSHClient, configContent: string, config: DeviceConfig): Promise<string> {
    let output = '';
    
    // EdgeMAX uses interactive configure mode
    const commands = configContent.split('\n');
    output += 'Executing EdgeMAX configuration commands...\n';
    
    for (const cmd of commands) {
      if (cmd.trim()) {
        output += `> ${cmd}\n`;
        const result = await client.exec(cmd);
        if (result.stdout) output += result.stdout + '\n';
        if (result.stderr) output += `ERROR: ${result.stderr}\n`;
      }
    }
    
    output += 'EdgeMAX configuration complete\n';
    return output;
  }
}

// UISP Switch strategy
export class UISPSwitchStrategy implements ProvisionStrategy {
  generateConfig(config: DeviceConfig): string {
    const commands: string[] = [];
    
    // UISP switches are managed via their web UI/API
    // For SSH, we can set basic network config
    commands.push(`configure`);
    commands.push(`set system hostname ${config.deviceName}`);
    
    if (config.ipMode === 'manual' && config.staticIp) {
      commands.push(`set interface address ${config.staticIp}/${24}`);
    }
    
    commands.push(`commit`);
    commands.push(`save`);
    
    return commands.join('\n');
  }
  
  async apply(client: SSHClient, configContent: string, config: DeviceConfig): Promise<string> {
    let output = '';
    const commands = configContent.split('\n');
    output += 'Executing UISP Switch configuration commands...\n';
    
    for (const cmd of commands) {
      if (cmd.trim()) {
        output += `> ${cmd}\n`;
        const result = await client.exec(cmd);
        if (result.stdout) output += result.stdout + '\n';
        if (result.stderr) output += `ERROR: ${result.stderr}\n`;
      }
    }
    
    output += 'UISP Switch configuration complete\n';
    return output;
  }
}

export function getProvisionStrategy(family: DeviceFamily): ProvisionStrategy {
  switch (family) {
    case 'airmax':
      return new AirMaxStrategy();
    case 'aircube':
      return new AirCubeStrategy();
    case 'edgemax':
      return new EdgeMaxStrategy();
    case 'uisp-switch':
      return new UISPSwitchStrategy();
    case 'wave':
      return new AirMaxStrategy(); // Wave uses airOS similar to airMAX
    default:
      throw new Error(`Unknown device family: ${family}`);
  }
}
