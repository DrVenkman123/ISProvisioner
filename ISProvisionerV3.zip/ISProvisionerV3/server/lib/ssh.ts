import { Client, ClientChannel } from 'ssh2';

export interface SSHConnectionOptions {
  host: string;
  port: number;
  username: string;
  password: string;
  timeout?: number;
}

export interface SSHResult {
  stdout: string;
  stderr: string;
  exitCode: number;
}

export class SSHClient {
  private conn: Client | null = null;
  private options: SSHConnectionOptions;

  constructor(options: SSHConnectionOptions) {
    this.options = {
      timeout: 30000,
      ...options,
    };
  }

  async connect(): Promise<void> {
    return new Promise((resolve, reject) => {
      this.conn = new Client();
      
      this.conn.on('ready', () => {
        resolve();
      });

      this.conn.on('error', (err) => {
        reject(err);
      });

      this.conn.connect({
        host: this.options.host,
        port: this.options.port,
        username: this.options.username,
        password: this.options.password,
        readyTimeout: this.options.timeout,
      });
    });
  }

  async exec(command: string): Promise<SSHResult> {
    if (!this.conn) {
      throw new Error('Not connected. Call connect() first.');
    }

    return new Promise((resolve, reject) => {
      this.conn!.exec(command, (err, stream: ClientChannel) => {
        if (err) {
          reject(err);
          return;
        }

        let stdout = '';
        let stderr = '';
        let exitCode = 0;

        stream.on('close', (code: number) => {
          exitCode = code;
          resolve({ stdout, stderr, exitCode });
        });

        stream.on('data', (data: Buffer) => {
          stdout += data.toString();
        });

        stream.stderr.on('data', (data: Buffer) => {
          stderr += data.toString();
        });
      });
    });
  }

  async uploadFile(content: string, remotePath: string): Promise<void> {
    if (!this.conn) {
      throw new Error('Not connected. Call connect() first.');
    }

    return new Promise((resolve, reject) => {
      this.conn!.sftp((err: Error | undefined, sftp: any) => {
        if (err) {
          reject(err);
          return;
        }

        const writeStream = sftp.createWriteStream(remotePath);
        
        writeStream.on('close', () => {
          resolve();
        });

        writeStream.on('error', (err) => {
          reject(err);
        });

        writeStream.write(content);
        writeStream.end();
      });
    });
  }

  disconnect(): void {
    if (this.conn) {
      this.conn.end();
      this.conn = null;
    }
  }
}

export async function withSSH<T>(
  options: SSHConnectionOptions,
  fn: (client: SSHClient) => Promise<T>
): Promise<T> {
  const client = new SSHClient(options);
  try {
    await client.connect();
    return await fn(client);
  } finally {
    client.disconnect();
  }
}
