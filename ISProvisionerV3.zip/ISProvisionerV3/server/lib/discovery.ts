import { exec } from 'child_process';
import { promisify } from 'util';
import arp from 'node-arp';
import wifi from 'node-wifi';
import os from 'os';

const execAsync = promisify(exec);
const arpGetMAC = promisify(arp.getMAC);

export interface DiscoveredDevice {
  ip: string;
  mac: string;
  hostname?: string;
  manufacturer?: string;
  model?: string;
}

export interface ScanOptions {
  cidr?: string;
  timeout?: number;
  interface?: string;
}

export interface NetworkInterface {
  name: string;
  addresses: Array<{
    address: string;
    netmask: string;
    family: string;
    mac: string;
    internal: boolean;
  }>;
}

// Initialize WiFi module
wifi.init({
  iface: null // null means the default interface
});

export class DeviceDiscovery {
  /**
   * Validate CIDR notation
   */
  private validateCIDR(cidr: string): boolean {
    const cidrRegex = /^(\d{1,3}\.){3}\d{1,3}\/\d{1,2}$/;
    if (!cidrRegex.test(cidr)) return false;
    
    const [ip, mask] = cidr.split('/');
    const octets = ip.split('.').map(Number);
    const maskNum = Number(mask);
    
    return octets.every(o => o >= 0 && o <= 255) && maskNum >= 0 && maskNum <= 32;
  }

  /**
   * Validate IP address
   */
  private validateIP(ip: string): boolean {
    const ipRegex = /^(\d{1,3}\.){3}\d{1,3}$/;
    if (!ipRegex.test(ip)) return false;
    
    const octets = ip.split('.').map(Number);
    return octets.every(o => o >= 0 && o <= 255);
  }

  /**
   * Scan LAN for devices using arp-scan or nmap
   */
  async scanLAN(options: ScanOptions = {}): Promise<DiscoveredDevice[]> {
    const cidr = options.cidr || '192.168.1.0/24';
    let iface = options.interface;
    const devices: DiscoveredDevice[] = [];

    // Validate CIDR to prevent command injection
    if (!this.validateCIDR(cidr)) {
      throw new Error('Invalid CIDR notation');
    }

    // Auto-detect interface if not specified
    if (!iface) {
      const interfaces = await this.getNetworkInterfaces();
      // Find first non-loopback interface with IPv4
      for (const nic of interfaces) {
        const ipv4 = nic.addresses.find(addr => addr.family === 'IPv4' && !addr.internal);
        if (ipv4) {
          iface = nic.name;
          console.log(`Auto-detected network interface: ${iface} (${ipv4.address})`);
          break;
        }
      }
      // Default fallback
      if (!iface) {
        iface = 'eth0';
        console.log('No interface auto-detected, using default: eth0');
      }
    }

    // Validate interface name (alphanumeric, dash, and dot only)
    if (!/^[a-zA-Z0-9\-\.]+$/.test(iface)) {
      throw new Error('Invalid interface name');
    }

    console.log(`Starting LAN scan on ${cidr} via interface ${iface}...`);

    try {
      const { spawn } = await import('child_process');
      
      let stdout = '';
      let scanMethod = 'unknown';
      
      try {
        // Try arp-scan first (fastest and most reliable for local network)
        console.log('Attempting arp-scan...');
        scanMethod = 'arp-scan';
        // Use CIDR if provided, otherwise scan local network
        // Run with sudo for proper permissions (sudoers configured in install.sh)
        const arpArgs = ['arp-scan', '--interface', iface];
        if (cidr && cidr !== '192.168.1.0/24') {
          arpArgs.push(cidr);  // Use specific CIDR
        } else {
          arpArgs.push('--localnet');  // Scan local network
        }
        const arpScan = spawn('sudo', arpArgs);
        
        arpScan.stdout.on('data', (data) => {
          stdout += data.toString();
        });
        
        const stderr: string[] = [];
        arpScan.stderr.on('data', (data) => {
          stderr.push(data.toString());
        });
        
        await new Promise((resolve, reject) => {
          arpScan.on('close', (code) => {
            if (code === 0) {
              console.log(`arp-scan completed successfully`);
              resolve(null);
            } else {
              console.log(`arp-scan failed with code ${code}: ${stderr.join('')}`);
              reject(new Error(`arp-scan exited with code ${code}`));
            }
          });
          arpScan.on('error', (err) => {
            console.log(`arp-scan error: ${err.message}`);
            reject(err);
          });
        });
      } catch (arpError) {
        // Fallback to nmap (works everywhere)
        console.log('Falling back to nmap...');
        scanMethod = 'nmap';
        stdout = '';
        
        // Run with sudo for proper permissions (sudoers configured in install.sh)
        const nmapScan = spawn('sudo', ['nmap', '-sn', '-T4', cidr]);
        
        nmapScan.stdout.on('data', (data) => {
          stdout += data.toString();
        });
        
        await new Promise((resolve, reject) => {
          nmapScan.on('close', (code) => {
            if (code === 0) {
              console.log(`nmap completed successfully`);
              resolve(null);
            } else {
              console.log(`nmap failed with code ${code}`);
              reject(new Error(`nmap exited with code ${code}`));
            }
          });
          nmapScan.on('error', (err) => {
            console.log(`nmap error: ${err.message}`);
            reject(err);
          });
        });
      }
      
      // Parse scan output (different for arp-scan vs nmap)
      console.log(`Parsing ${scanMethod} output...`);
      const lines = stdout.split('\n');
      
      if (scanMethod === 'arp-scan') {
        // Parse arp-scan output: "IP   MAC   Manufacturer"
        for (const line of lines) {
          const match = line.match(/^(\d+\.\d+\.\d+\.\d+)\s+([a-fA-F0-9:]+)\s+(.*)/);
          if (match) {
            const [, ip, mac, manufacturer] = match;
            
            // Validate IP before using it
            if (!this.validateIP(ip)) continue;
            
            devices.push({
              ip,
              mac: mac.toUpperCase(),
              manufacturer: manufacturer.trim() || undefined,
            });
          }
        }
      } else if (scanMethod === 'nmap') {
        // Parse nmap output
        let currentIP = '';
        for (const line of lines) {
          // Look for lines like "Nmap scan report for 192.168.1.1"
          const ipMatch = line.match(/Nmap scan report for (?:\S+ \()?(\d+\.\d+\.\d+\.\d+)\)?/);
          if (ipMatch) {
            currentIP = ipMatch[1];
          }
          
          // Look for MAC address lines like "MAC Address: AA:BB:CC:DD:EE:FF (Manufacturer)"
          const macMatch = line.match(/MAC Address:\s+([A-F0-9:]+)\s*(?:\((.+)\))?/i);
          if (macMatch && currentIP) {
            const [, mac, manufacturer] = macMatch;
            
            // Validate IP before using it
            if (!this.validateIP(currentIP)) continue;
            
            devices.push({
              ip: currentIP,
              mac: mac.toUpperCase(),
              manufacturer: manufacturer?.trim() || undefined,
            });
          }
        }
      }
      
      console.log(`Found ${devices.length} devices via ${scanMethod}`);
      
      // Try to resolve hostnames for discovered devices (best effort, don't block)
      const hostnamePromises = devices.map(async (device) => {
        try {
          const hostLookup = spawn('host', [device.ip]);
          let hostOutput = '';
          
          hostLookup.stdout.on('data', (data) => {
            hostOutput += data.toString();
          });
          
          await Promise.race([
            new Promise((resolve) => {
              hostLookup.on('close', () => resolve(null));
              hostLookup.on('error', () => resolve(null));
            }),
            new Promise(resolve => setTimeout(resolve, 1000)) // 1 second timeout
          ]);
          
          const hostMatch = hostOutput.match(/pointer\s+(.+)\./);
          if (hostMatch) {
            device.hostname = hostMatch[1];
          }
        } catch {
          // Hostname lookup failed, device will not have hostname
        }
      });
      
      await Promise.all(hostnamePromises);
    } catch (error) {
      console.error('LAN scan error:', error);
      
      // Fallback: try using arp -a
      try {
        const { stdout } = await execAsync('arp -a');
        const lines = stdout.split('\n');
        
        for (const line of lines) {
          const match = line.match(/\((\d+\.\d+\.\d+\.\d+)\)\s+at\s+([a-fA-F0-9:]+)/i);
          if (match) {
            const [, ip, mac] = match;
            devices.push({
              ip,
              mac: mac.toUpperCase(),
            });
          }
        }
      } catch (fallbackError) {
        console.error('Fallback arp scan error:', fallbackError);
      }
    }

    return devices;
  }

  /**
   * Scan for Bluetooth devices
   * Note: Requires bluetoothctl and appropriate permissions
   */
  async scanBluetooth(duration: number = 10): Promise<DiscoveredDevice[]> {
    const devices: DiscoveredDevice[] = [];

    try {
      // Start Bluetooth scan
      await execAsync('bluetoothctl power on');
      await execAsync('bluetoothctl scan on &');
      
      // Wait for scan duration
      await new Promise(resolve => setTimeout(resolve, duration * 1000));
      
      // Get devices
      const { stdout } = await execAsync('bluetoothctl devices');
      const lines = stdout.split('\n');
      
      for (const line of lines) {
        const match = line.match(/Device\s+([A-F0-9:]+)\s+(.*)/i);
        if (match) {
          const [, mac, name] = match;
          devices.push({
            ip: '', // Bluetooth devices don't have IP until connected
            mac: mac.toUpperCase(),
            hostname: name.trim(),
            manufacturer: 'Bluetooth Device',
          });
        }
      }
      
      // Stop scan
      await execAsync('bluetoothctl scan off');
    } catch (error) {
      console.error('Bluetooth scan error:', error);
    }

    return devices;
  }

  /**
   * Scan WiFi networks
   */
  async scanWiFi(adapter?: string): Promise<Array<{
    ssid: string;
    bssid: string;
    signal: number;
    security: string;
    channel: number;
  }>> {
    try {
      // If adapter specified, use it
      if (adapter) {
        wifi.init({ iface: adapter });
      }
      
      const networks = await wifi.scan();
      
      return networks.map(network => ({
        ssid: network.ssid,
        bssid: network.bssid || '',
        signal: network.signal_level || 0,
        security: network.security || 'Open',
        channel: network.channel || 0,
      }));
    } catch (error) {
      console.error('WiFi scan error:', error);
      return [];
    }
  }

  /**
   * Get all network interfaces (NICs)
   */
  async getNetworkInterfaces(): Promise<NetworkInterface[]> {
    const interfaces = os.networkInterfaces();
    const result: NetworkInterface[] = [];

    for (const [name, addresses] of Object.entries(interfaces)) {
      if (!addresses) continue;
      
      // Filter out loopback and virtual interfaces for cleaner list
      const isPhysical = !name.startsWith('lo') && 
                         !name.startsWith('veth') && 
                         !name.startsWith('docker') &&
                         !name.startsWith('br-');
      
      if (isPhysical) {
        result.push({
          name,
          addresses: addresses.map(addr => ({
            address: addr.address,
            netmask: addr.netmask,
            family: addr.family,
            mac: addr.mac || '',
            internal: addr.internal,
          })),
        });
      }
    }

    return result;
  }

  /**
   * Get available Bluetooth adapters
   */
  async getBluetoothAdapters(): Promise<Array<{name: string; address: string}>> {
    try {
      const { stdout } = await execAsync('hciconfig | grep -E "^hci" | cut -d: -f1');
      const adapters = stdout.split('\n').filter(line => line.trim());
      
      const result = [];
      for (const adapter of adapters) {
        const cleanAdapter = adapter.trim();
        if (!cleanAdapter) continue;
        
        try {
          const { stdout: addrOut } = await execAsync(`hciconfig ${cleanAdapter} | grep "BD Address" | awk '{print $3}'`);
          result.push({
            name: cleanAdapter,
            address: addrOut.trim() || 'Unknown',
          });
        } catch {
          result.push({
            name: cleanAdapter,
            address: 'Unknown',
          });
        }
      }
      
      return result;
    } catch (error) {
      console.error('Bluetooth adapter list error:', error);
      return [];
    }
  }

  /**
   * Get available WiFi adapters
   */
  async getWiFiAdapters(): Promise<string[]> {
    try {
      const { stdout } = await execAsync('iw dev | grep Interface | awk \'{print $2}\'');
      return stdout.split('\n').filter(line => line.trim());
    } catch (error) {
      console.error('WiFi adapter list error:', error);
      return [];
    }
  }

  /**
   * Test SSH connectivity to a device
   */
  async testConnection(ip: string, port: number = 22): Promise<boolean> {
    try {
      const { stdout } = await execAsync(`nc -zv -w 2 ${ip} ${port} 2>&1`);
      return stdout.includes('succeeded') || stdout.includes('open');
    } catch {
      return false;
    }
  }
}

export const deviceDiscovery = new DeviceDiscovery();
