import { SSHClient } from './ssh';

export interface DeviceStats {
  firmware: string;
  model: string;
  hostname: string;
  ipAddress: string;
  netmask: string;
  gateway: string;
  uptime: string;
  signalStrength?: number;
  signalQuality?: number;
  wirelessMode?: 'ap' | 'station';
  ssid?: string;
  frequency?: string;
  txPower?: number;
  cpuLoad?: string;
  memoryUsage?: string;
  temperature?: string;
}

/**
 * Get device stats via SSH for airMAX devices
 */
export async function getAirMaxStats(client: SSHClient): Promise<Partial<DeviceStats>> {
  const stats: Partial<DeviceStats> = {};

  try {
    // Get firmware version
    const fwVersion = await execCommand(client, 'cat /etc/version');
    stats.firmware = fwVersion.trim();

    // Get board info
    const boardInfo = await execCommand(client, 'cat /etc/board.info 2>/dev/null || cat /proc/ubnthal/system.info 2>/dev/null');
    const modelMatch = boardInfo.match(/board\.name=(.*)/);
    if (modelMatch) {
      stats.model = modelMatch[1].trim();
    }

    // Get hostname
    const hostname = await execCommand(client, 'hostname');
    stats.hostname = hostname.trim();

    // Get IP configuration
    const ifconfig = await execCommand(client, 'ifconfig br0 2>/dev/null || ifconfig eth0');
    const ipMatch = ifconfig.match(/inet addr:(\S+)/);
    const maskMatch = ifconfig.match(/Mask:(\S+)/);
    if (ipMatch) stats.ipAddress = ipMatch[1];
    if (maskMatch) stats.netmask = maskMatch[1];

    // Get gateway
    const route = await execCommand(client, 'route -n | grep "^0.0.0.0" | awk \'{print $2}\'');
    stats.gateway = route.trim();

    // Get uptime
    const uptime = await execCommand(client, 'uptime');
    stats.uptime = uptime.trim();

    // Get wireless stats
    const wlanConfig = await execCommand(client, 'mca-status 2>/dev/null || iwconfig ath0 2>/dev/null');
    
    // Try to parse signal strength
    const signalMatch = wlanConfig.match(/Signal level[=:]\s*(-?\d+)/);
    if (signalMatch) {
      stats.signalStrength = parseInt(signalMatch[1]);
    }

    // Get wireless mode
    if (wlanConfig.includes('Master')) {
      stats.wirelessMode = 'ap';
    } else if (wlanConfig.includes('Managed')) {
      stats.wirelessMode = 'station';
    }

    // Get SSID
    const ssidMatch = wlanConfig.match(/ESSID:"([^"]+)"/);
    if (ssidMatch) {
      stats.ssid = ssidMatch[1];
    }

    // Get CPU load
    const loadavg = await execCommand(client, 'cat /proc/loadavg');
    const loadMatch = loadavg.match(/^(\S+)/);
    if (loadMatch) {
      stats.cpuLoad = loadMatch[1];
    }

    // Get memory usage
    const free = await execCommand(client, 'free | grep "Mem:"');
    const memMatch = free.match(/Mem:\s+(\d+)\s+(\d+)/);
    if (memMatch) {
      const total = parseInt(memMatch[1]);
      const used = parseInt(memMatch[2]);
      stats.memoryUsage = `${Math.round(used / total * 100)}%`;
    }

  } catch (error) {
    console.error('Error getting airMAX stats:', error);
  }

  return stats;
}

/**
 * Get device stats via SSH for EdgeMAX devices (EdgeRouter/EdgeSwitch)
 */
export async function getEdgeMaxStats(client: SSHClient): Promise<Partial<DeviceStats>> {
  const stats: Partial<DeviceStats> = {};

  try {
    // Get firmware version
    const showVersion = await execCommand(client, 'show version');
    const versionMatch = showVersion.match(/Version:\s+v(\S+)/);
    if (versionMatch) {
      stats.firmware = versionMatch[1];
    }

    // Get model
    const modelMatch = showVersion.match(/HW model:\s+(.+)/);
    if (modelMatch) {
      stats.model = modelMatch[1].trim();
    }

    // Get hostname
    const hostname = await execCommand(client, 'hostname');
    stats.hostname = hostname.trim();

    // Get IP configuration from first interface
    const showInterfaces = await execCommand(client, 'show interfaces');
    const ipMatch = showInterfaces.match(/inet addr:(\S+)/);
    if (ipMatch) {
      stats.ipAddress = ipMatch[1];
    }

    // Get uptime
    const uptime = await execCommand(client, 'uptime');
    stats.uptime = uptime.trim();

    // Get CPU load
    const loadavg = await execCommand(client, 'cat /proc/loadavg');
    const loadMatch = loadavg.match(/^(\S+)/);
    if (loadMatch) {
      stats.cpuLoad = loadMatch[1];
    }

  } catch (error) {
    console.error('Error getting EdgeMAX stats:', error);
  }

  return stats;
}

/**
 * Get device stats via SSH for AirCube devices
 */
export async function getAirCubeStats(client: SSHClient): Promise<Partial<DeviceStats>> {
  const stats: Partial<DeviceStats> = {};

  try {
    // Get firmware version
    const catRelease = await execCommand(client, 'cat /etc/openwrt_release');
    const versionMatch = catRelease.match(/DISTRIB_RELEASE='([^']+)'/);
    if (versionMatch) {
      stats.firmware = versionMatch[1];
    }

    // Get board/model
    const boardName = await execCommand(client, 'cat /tmp/sysinfo/board_name 2>/dev/null || cat /proc/cpuinfo | grep machine');
    stats.model = boardName.trim();

    // Get hostname
    const uciHostname = await execCommand(client, 'uci get system.@system[0].hostname');
    stats.hostname = uciHostname.trim();

    // Get IP
    const ifstatus = await execCommand(client, 'ifconfig br-lan');
    const ipMatch = ifstatus.match(/inet addr:(\S+)/);
    if (ipMatch) {
      stats.ipAddress = ipMatch[1];
    }

    // Get uptime
    const uptime = await execCommand(client, 'uptime');
    stats.uptime = uptime.trim();

  } catch (error) {
    console.error('Error getting AirCube stats:', error);
  }

  return stats;
}

/**
 * Helper function to execute SSH command and return output
 */
async function execCommand(client: SSHClient, command: string): Promise<string> {
  const result = await client.exec(command);
  if (result.exitCode !== 0) {
    throw new Error(`Command failed: ${result.stderr || result.stdout}`);
  }
  return result.stdout;
}

/**
 * Get device stats based on device family
 */
export async function getDeviceStats(
  client: SSHClient,
  deviceFamily: 'airmax' | 'edgemax' | 'aircube' | 'uisp-switch' | 'wave'
): Promise<Partial<DeviceStats>> {
  switch (deviceFamily) {
    case 'airmax':
    case 'wave':
      return await getAirMaxStats(client);
    case 'edgemax':
      return await getEdgeMaxStats(client);
    case 'aircube':
      return await getAirCubeStats(client);
    case 'uisp-switch':
      // UISP switches use similar commands to EdgeMAX
      return await getEdgeMaxStats(client);
    default:
      return {};
  }
}
