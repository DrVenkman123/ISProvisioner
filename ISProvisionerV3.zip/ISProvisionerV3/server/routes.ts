import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { deviceDiscovery } from "./lib/discovery";
import { withSSH } from "./lib/ssh";
import { getProvisionStrategy, type DeviceConfig, type DeviceFamily } from "./lib/provisioning";
import { getDeviceStats } from "./lib/device-stats";
import { insertPopProfileSchema, insertConfigTemplateSchema, insertProvisionJobSchema, insertUserSchema, insertFavoriteDeviceSchema, type InsertUser } from "@shared/schema";
import { z } from "zod";
import bcrypt from "bcryptjs";

// Validation schemas for authentication
const loginSchema = z.object({
  username: z.string().min(1, "Username required").max(50),
  password: z.string().min(1, "Password required"),
}).strict();

const registerSchema = z.object({
  username: z.string().min(3, "Username must be at least 3 characters").max(50),
  password: z.string().min(8, "Password must be at least 8 characters"),
  role: z.enum(["admin", "tech", "viewer"]).optional(),
}).strict();

// Authentication middleware
function requireAuth(req: any, res: any, next: any) {
  if (!req.session.userId) {
    return res.status(401).json({ error: "Authentication required" });
  }
  next();
}

function requireAdmin(req: any, res: any, next: any) {
  if (!req.session.userId) {
    return res.status(401).json({ error: "Authentication required" });
  }
  if (req.session.role !== "admin") {
    return res.status(403).json({ error: "Admin privileges required" });
  }
  next();
}

export async function registerRoutes(app: Express): Promise<Server> {
  // ===== Authentication =====
  
  // Check if setup is needed (no users exist)
  app.get("/api/auth/setup-needed", async (req, res) => {
    try {
      // Prevent caching to ensure fresh setup status
      res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, private');
      res.setHeader('Pragma', 'no-cache');
      res.setHeader('Expires', '0');
      
      const users = await storage.getAllUsers();
      res.json({ setupNeeded: users.length === 0 });
    } catch (error) {
      res.status(500).json({ error: "Failed to check setup status" });
    }
  });

  app.post("/api/auth/register", async (req, res) => {
    try {
      // Validate input with Zod
      const validationResult = registerSchema.safeParse(req.body);
      if (!validationResult.success) {
        return res.status(400).json({ 
          error: "Validation failed", 
          details: validationResult.error.flatten().fieldErrors 
        });
      }
      const { username, password, role: requestedRole } = validationResult.data;
      
      // Check if user already exists
      const existing = await storage.getUserByUsername(username);
      if (existing) {
        return res.status(409).json({ error: "Username already exists" });
      }
      
      // Get all users to determine if this is first-time setup
      let allUsers;
      try {
        allUsers = await storage.getAllUsers();
      } catch (error) {
        console.error('Database error fetching users:', error);
        return res.status(500).json({ error: "Database error" });
      }
      
      // If no users exist, this is first-time setup - make them admin
      // Otherwise, only allow if current user is admin
      let assignedRole = "tech";
      const isFirstUser = allUsers.length === 0;
      
      if (isFirstUser) {
        assignedRole = "admin"; // First user is admin
      } else {
        // Require admin privileges to create new users
        if (!req.session.userId || req.session.role !== "admin") {
          return res.status(403).json({ error: "Only admins can create new users" });
        }
        // Admin can specify role (already validated by Zod), or default to tech
        assignedRole = requestedRole || "tech";
      }
      
      // Hash password
      const hashedPassword = await bcrypt.hash(password, 10);
      
      // Create user
      let user;
      try {
        user = await storage.createUser({
          username,
          password: hashedPassword,
          role: assignedRole,
        });
      } catch (error) {
        console.error('Database error creating user:', error);
        return res.status(500).json({ error: "Failed to create user account" });
      }
      
      // Only set session for first user (setup) - preserve admin session for subsequent creations
      if (isFirstUser) {
        // Regenerate session to prevent fixation
        req.session.regenerate((err) => {
          if (err) {
            return res.status(500).json({ error: "Session error" });
          }
          req.session.userId = user.id;
          req.session.username = user.username;
          req.session.role = user.role;
          req.session.save((err) => {
            if (err) {
              return res.status(500).json({ error: "Session save error" });
            }
            res.json({ 
              id: user.id, 
              username: user.username, 
              role: user.role 
            });
          });
        });
      } else {
        // Admin creating user - don't change session, just return created user
        res.json({ 
          id: user.id, 
          username: user.username, 
          role: user.role 
        });
      }
    } catch (error) {
      console.error('Unexpected registration error:', error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.post("/api/auth/login", async (req, res) => {
    try {
      // Validate input with Zod
      const validationResult = loginSchema.safeParse(req.body);
      if (!validationResult.success) {
        return res.status(400).json({ 
          error: "Validation failed", 
          details: validationResult.error.flatten().fieldErrors 
        });
      }
      const { username, password } = validationResult.data;
      
      // Find user
      const user = await storage.getUserByUsername(username);
      if (!user) {
        return res.status(401).json({ error: "Invalid credentials" });
      }
      
      // Verify password
      const valid = await bcrypt.compare(password, user.password);
      if (!valid) {
        return res.status(401).json({ error: "Invalid credentials" });
      }
      
      // Regenerate session to prevent fixation attacks
      req.session.regenerate((err) => {
        if (err) {
          return res.status(500).json({ error: "Session error" });
        }
        
        // Store user session
        req.session.userId = user.id;
        req.session.username = user.username;
        req.session.role = user.role;
        
        req.session.save((err) => {
          if (err) {
            return res.status(500).json({ error: "Session save error" });
          }
          
          res.json({ 
            id: user.id, 
            username: user.username, 
            role: user.role 
          });
        });
      });
    } catch (error) {
      console.error('Unexpected login error:', error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.post("/api/auth/logout", (req, res) => {
    req.session.destroy((err) => {
      if (err) {
        return res.status(500).json({ error: "Logout failed" });
      }
      res.json({ success: true });
    });
  });

  app.get("/api/auth/me", (req, res) => {
    if (req.session.userId) {
      res.json({
        id: req.session.userId,
        username: req.session.username,
        role: req.session.role,
      });
    } else {
      res.status(401).json({ error: "Not authenticated" });
    }
  });

  // ===== User Management =====
  
  // Get all users (admin only)
  app.get("/api/users", requireAdmin, async (req, res) => {
    try {
      const users = await storage.getAllUsers();
      // Don't send password hashes to frontend
      const sanitizedUsers = users.map(({ password, ...user }) => user);
      res.json(sanitizedUsers);
    } catch (error) {
      console.error('Get users error:', error);
      res.status(500).json({ error: "Failed to fetch users" });
    }
  });

  // Update user (admin only)
  const updateUserSchema = insertUserSchema.pick({ password: true, role: true }).partial();
  
  app.patch("/api/users/:id", requireAdmin, async (req, res) => {
    try {
      const { id } = req.params;
      
      // Validate input with Zod
      const validationResult = updateUserSchema.safeParse(req.body);
      if (!validationResult.success) {
        return res.status(400).json({ 
          error: "Validation failed", 
          details: validationResult.error.flatten().fieldErrors 
        });
      }
      
      const { password, role } = validationResult.data;
      const updateData: Partial<InsertUser> = {};
      
      // Update role if provided
      if (role) {
        updateData.role = role;
      }
      
      // Update password if provided (hash it first)
      if (password) {
        updateData.password = await bcrypt.hash(password, 10);
      }
      
      if (Object.keys(updateData).length === 0) {
        return res.status(400).json({ error: "No valid fields to update" });
      }
      
      const user = await storage.updateUser(id, updateData);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }
      
      const { password: _, ...sanitizedUser } = user;
      res.json(sanitizedUser);
    } catch (error) {
      console.error('Update user error:', error);
      res.status(500).json({ error: "Failed to update user" });
    }
  });

  // Delete user (admin only)
  app.delete("/api/users/:id", requireAdmin, async (req, res) => {
    try {
      const { id } = req.params;
      
      // Prevent admin from deleting themselves
      if (req.session.userId === id) {
        return res.status(400).json({ error: "Cannot delete your own account" });
      }
      
      await storage.deleteUser(id);
      res.json({ success: true });
    } catch (error) {
      console.error('Delete user error:', error);
      res.status(500).json({ error: "Failed to delete user" });
    }
  });

  // ===== PoP Profiles =====
  
  app.get("/api/pop-profiles", requireAuth, async (req, res) => {
    try {
      const profiles = await storage.getAllPopProfiles();
      res.json(profiles);
    } catch (error) {
      console.error('Get PoP profiles error:', error);
      res.status(500).json({ error: "Failed to fetch PoP profiles" });
    }
  });

  app.post("/api/pop-profiles", requireAdmin, async (req, res) => {
    try {
      const validated = insertPopProfileSchema.parse(req.body);
      const profile = await storage.createPopProfile(validated);
      
      // Log activity
      await storage.createActivityLog({
        eventType: 'pop_created',
        status: 'success',
        metadata: { popProfileId: profile.id, name: profile.name }
      });
      
      res.json(profile);
    } catch (error) {
      console.error('Create PoP profile error:', error);
      res.status(400).json({ error: "Invalid PoP profile data" });
    }
  });

  app.put("/api/pop-profiles/:id", requireAdmin, async (req, res) => {
    try {
      const { id } = req.params;
      const validated = insertPopProfileSchema.partial().parse(req.body);
      const profile = await storage.updatePopProfile(id, validated);
      
      if (!profile) {
        return res.status(404).json({ error: "PoP profile not found" });
      }
      
      // Log activity
      await storage.createActivityLog({
        eventType: 'pop_updated',
        status: 'success',
        metadata: { popProfileId: profile.id, name: profile.name }
      });
      
      res.json(profile);
    } catch (error) {
      console.error('Update PoP profile error:', error);
      res.status(400).json({ error: "Invalid PoP profile data" });
    }
  });

  app.delete("/api/pop-profiles/:id", requireAdmin, async (req, res) => {
    try {
      const { id } = req.params;
      const profile = await storage.getPopProfile(id);
      
      if (!profile) {
        return res.status(404).json({ error: "PoP profile not found" });
      }
      
      await storage.deletePopProfile(id);
      
      // Log activity
      await storage.createActivityLog({
        eventType: 'pop_deleted',
        status: 'success',
        metadata: { popProfileId: id, name: profile.name }
      });
      
      res.json({ success: true });
    } catch (error) {
      console.error('Delete PoP profile error:', error);
      res.status(500).json({ error: "Failed to delete PoP profile" });
    }
  });

  // ===== Config Templates =====
  
  app.get("/api/templates", requireAuth, async (req, res) => {
    try {
      const { family } = req.query;
      const templates = family 
        ? await storage.getConfigTemplatesByFamily(family as string)
        : await storage.getAllConfigTemplates();
      res.json(templates);
    } catch (error) {
      console.error('Get templates error:', error);
      res.status(500).json({ error: "Failed to fetch templates" });
    }
  });

  app.post("/api/templates", requireAdmin, async (req, res) => {
    try {
      const validated = insertConfigTemplateSchema.parse(req.body);
      const template = await storage.createConfigTemplate(validated);
      
      // Log activity
      await storage.createActivityLog({
        eventType: 'template_created',
        deviceType: template.deviceType,
        status: 'success',
        metadata: { templateId: template.id, name: template.name, deviceFamily: template.deviceFamily }
      });
      
      res.json(template);
    } catch (error) {
      console.error('Create template error:', error);
      res.status(400).json({ error: "Invalid template data" });
    }
  });

  app.put("/api/templates/:id", requireAdmin, async (req, res) => {
    try {
      const { id } = req.params;
      const validated = insertConfigTemplateSchema.partial().parse(req.body);
      const template = await storage.updateConfigTemplate(id, validated);
      
      if (!template) {
        return res.status(404).json({ error: "Template not found" });
      }
      
      // Log activity
      await storage.createActivityLog({
        eventType: 'template_updated',
        deviceType: template.deviceType,
        status: 'success',
        metadata: { templateId: template.id, name: template.name, deviceFamily: template.deviceFamily }
      });
      
      res.json(template);
    } catch (error) {
      console.error('Update template error:', error);
      res.status(400).json({ error: "Invalid template data" });
    }
  });

  app.delete("/api/templates/:id", requireAdmin, async (req, res) => {
    try {
      const { id } = req.params;
      const template = await storage.getConfigTemplate(id);
      
      if (!template) {
        return res.status(404).json({ error: "Template not found" });
      }
      
      await storage.deleteConfigTemplate(id);
      
      // Log activity
      await storage.createActivityLog({
        eventType: 'template_deleted',
        deviceType: template.deviceType,
        status: 'success',
        metadata: { templateId: id, name: template.name, deviceFamily: template.deviceFamily }
      });
      
      res.json({ success: true });
    } catch (error) {
      console.error('Delete template error:', error);
      res.status(500).json({ error: "Failed to delete template" });
    }
  });

  // ===== Settings =====
  
  app.get("/api/settings", requireAuth, async (req, res) => {
    try {
      const allSettings = await storage.getAllSettings();
      const settingsObj = allSettings.reduce((acc, setting) => {
        acc[setting.key] = setting.value;
        return acc;
      }, {} as Record<string, any>);
      res.json(settingsObj);
    } catch (error) {
      console.error('Get settings error:', error);
      res.status(500).json({ error: "Failed to fetch settings" });
    }
  });

  app.put("/api/settings", requireAdmin, async (req, res) => {
    try {
      const { key, value } = req.body;
      if (!key) {
        return res.status(400).json({ error: "Setting key is required" });
      }
      const setting = await storage.setSetting(key, value);
      res.json(setting);
    } catch (error) {
      console.error('Update setting error:', error);
      res.status(400).json({ error: "Failed to update setting" });
    }
  });

  // ===== Device Discovery =====
  
  app.post("/api/discovery/lan", requireAuth, async (req, res) => {
    try {
      const { cidr, timeout, interface: iface } = req.body;
      const devices = await deviceDiscovery.scanLAN({ cidr, timeout, interface: iface });
      res.json(devices);
    } catch (error) {
      console.error('LAN scan error:', error);
      res.status(500).json({ error: "LAN scan failed" });
    }
  });

  app.post("/api/discovery/bluetooth", requireAuth, async (req, res) => {
    try {
      const { duration } = req.body;
      const devices = await deviceDiscovery.scanBluetooth(duration || 10);
      res.json(devices);
    } catch (error) {
      console.error('Bluetooth scan error:', error);
      res.status(500).json({ error: "Bluetooth scan failed" });
    }
  });

  app.post("/api/discovery/wifi", requireAuth, async (req, res) => {
    try {
      const { adapter } = req.body;
      const networks = await deviceDiscovery.scanWiFi(adapter);
      res.json(networks);
    } catch (error) {
      console.error('WiFi scan error:', error);
      res.status(500).json({ error: "WiFi scan failed" });
    }
  });

  app.get("/api/discovery/network-interfaces", requireAuth, async (req, res) => {
    try {
      const interfaces = await deviceDiscovery.getNetworkInterfaces();
      res.json(interfaces);
    } catch (error) {
      console.error('Network interface list error:', error);
      res.status(500).json({ error: "Failed to list network interfaces" });
    }
  });

  app.get("/api/discovery/bluetooth-adapters", requireAuth, async (req, res) => {
    try {
      const adapters = await deviceDiscovery.getBluetoothAdapters();
      res.json(adapters);
    } catch (error) {
      console.error('Bluetooth adapter list error:', error);
      res.status(500).json({ error: "Failed to list Bluetooth adapters" });
    }
  });

  app.get("/api/discovery/wifi-adapters", requireAuth, async (req, res) => {
    try {
      const adapters = await deviceDiscovery.getWiFiAdapters();
      res.json(adapters);
    } catch (error) {
      console.error('WiFi adapter list error:', error);
      res.status(500).json({ error: "Failed to list WiFi adapters" });
    }
  });

  app.post("/api/discovery/test-connection", requireAuth, async (req, res) => {
    try {
      const { ip, port } = req.body;
      const isConnected = await deviceDiscovery.testConnection(ip, port || 22);
      res.json({ connected: isConnected });
    } catch (error) {
      console.error('Connection test error:', error);
      res.status(500).json({ error: "Connection test failed" });
    }
  });

  app.post("/api/device/stats", requireAuth, async (req, res) => {
    try {
      const { ip, port, username, password, deviceFamily } = req.body;
      
      let stats = {};
      await withSSH(
        {
          host: ip,
          port: port || 22,
          username: username || 'ubnt',
          password: password || 'ubnt',
          timeout: 15000,
        },
        async (client) => {
          stats = await getDeviceStats(client, deviceFamily);
        }
      );
      
      res.json(stats);
    } catch (error: any) {
      console.error('Device stats error:', error);
      res.status(500).json({ error: error.message || "Failed to get device stats" });
    }
  });

  // ===== Bulk Operations =====

  app.post("/api/bulk-operations/change-credentials", requireAdmin, async (req, res) => {
    try {
      const { devices, currentUsername, currentPassword, newUsername, newPassword } = req.body;
      
      if (!devices || !Array.isArray(devices) || devices.length === 0) {
        return res.status(400).json({ error: "No devices provided" });
      }

      const results = await Promise.all(
        devices.map(async (device: { ip: string; mac: string; hostname?: string }) => {
          try {
            await withSSH(
              {
                host: device.ip,
                port: 22,
                username: currentUsername,
                password: currentPassword,
                timeout: 15000,
              },
              async (client) => {
                // Change password using passwd command
                if (newPassword && newPassword !== currentPassword) {
                  const result = await client.exec(`echo -e "${newPassword}\\n${newPassword}" | passwd ${currentUsername}`);
                  if (result.exitCode !== 0 && !result.stdout.includes('success') && !result.stdout.includes('updated')) {
                    throw new Error('Password change failed');
                  }
                }

                // Note: Changing username requires more complex logic
                // For now, we only support password changes
              }
            );

            return {
              ip: device.ip,
              success: true,
              message: "Credentials updated successfully",
            };
          } catch (error: any) {
            return {
              ip: device.ip,
              success: false,
              message: error.message || "Failed to update credentials",
            };
          }
        })
      );

      res.json(results);
    } catch (error: any) {
      console.error('Bulk operation error:', error);
      res.status(500).json({ error: error.message || "Bulk operation failed" });
    }
  });

  // ===== Provisioning =====
  
  const provisionConfigSchema = z.object({
    deviceFamily: z.enum(['airmax', 'aircube', 'wave', 'edgemax', 'uisp-switch']),
    deviceType: z.string(),
    deviceIp: z.string(),
    sshPort: z.number().default(22),
    sshUsername: z.string(),
    sshPassword: z.string(),
    config: z.any(),
  });

  app.post("/api/provision", requireAuth, async (req, res) => {
    try {
      const validated = provisionConfigSchema.parse(req.body);
      const { deviceFamily, deviceType, deviceIp, sshPort, sshUsername, sshPassword, config } = validated;

      // Create provision job
      const job = await storage.createProvisionJob({
        deviceType,
        deviceFamily,
        deviceIp,
        deviceMode: config.mode,
        config: config as any,
        status: 'running',
        output: '',
      });
      
      // Log provision start
      await storage.createActivityLog({
        eventType: 'provision',
        deviceIp,
        deviceType,
        status: 'in_progress',
        metadata: { provisionJobId: job.id, deviceFamily, mode: config.mode }
      });

      // Execute provisioning in background
      (async () => {
        let output = '';
        try {
          output += `[${new Date().toISOString()}] Starting provisioning for ${deviceType} at ${deviceIp}\n`;

          // Get provisioning strategy
          const strategy = getProvisionStrategy(deviceFamily as DeviceFamily);
          
          // Generate config
          output += `[${new Date().toISOString()}] Generating configuration...\n`;
          const configContent = strategy.generateConfig(config as DeviceConfig);
          output += `[${new Date().toISOString()}] Configuration generated:\n${configContent}\n\n`;

          // Connect and provision via SSH
          output += `[${new Date().toISOString()}] Connecting to device via SSH...\n`;
          await withSSH(
            {
              host: deviceIp,
              port: sshPort,
              username: sshUsername,
              password: sshPassword,
              timeout: 30000,
            },
            async (client) => {
              output += `[${new Date().toISOString()}] SSH connection established\n`;
              
              // Apply configuration
              output += `[${new Date().toISOString()}] Applying configuration...\n`;
              const applyOutput = await strategy.apply(client, configContent, config as DeviceConfig);
              output += applyOutput;
              output += `[${new Date().toISOString()}] Configuration applied successfully\n`;
            }
          );

          output += `[${new Date().toISOString()}] Provisioning completed successfully\n`;
          
          // Update job status
          await storage.updateProvisionJob(job.id, {
            status: 'completed',
            output,
          });
          
          // Log successful completion
          await storage.createActivityLog({
            eventType: 'provision',
            deviceIp,
            deviceType,
            status: 'success',
            metadata: { provisionJobId: job.id, deviceFamily, mode: config.mode }
          });
        } catch (error: any) {
          output += `[${new Date().toISOString()}] ERROR: ${error.message}\n`;
          await storage.updateProvisionJob(job.id, {
            status: 'failed',
            output,
          });
          
          // Log failure
          await storage.createActivityLog({
            eventType: 'provision',
            deviceIp,
            deviceType,
            status: 'error',
            metadata: { provisionJobId: job.id, deviceFamily, mode: config.mode, error: error.message }
          });
        }
      })();

      // Return job immediately
      res.json(job);
    } catch (error) {
      console.error('Provision error:', error);
      res.status(400).json({ error: "Invalid provision request" });
    }
  });

  app.get("/api/provision/:id", requireAuth, async (req, res) => {
    try {
      const { id } = req.params;
      const job = await storage.getProvisionJob(id);
      if (!job) {
        return res.status(404).json({ error: "Provision job not found" });
      }
      res.json(job);
    } catch (error) {
      console.error('Get provision job error:', error);
      res.status(500).json({ error: "Failed to fetch provision job" });
    }
  });

  app.get("/api/provision", requireAuth, async (req, res) => {
    try {
      const jobs = await storage.getAllProvisionJobs();
      res.json(jobs);
    } catch (error) {
      console.error('Get provision jobs error:', error);
      res.status(500).json({ error: "Failed to fetch provision jobs" });
    }
  });

  // Factory reset device
  const factoryResetSchema = z.object({
    host: z.string().min(1, "Host is required"),
    port: z.number().int().positive().default(22),
    username: z.string().min(1, "Username is required"),
    password: z.string().min(1, "Password is required"),
    deviceFamily: z.enum(['airmax', 'aircube', 'edgemax', 'uisp-switch', 'wave']),
  });

  app.post("/api/devices/factory-reset", requireAuth, async (req, res) => {
    try {
      const validationResult = factoryResetSchema.safeParse(req.body);
      if (!validationResult.success) {
        return res.status(400).json({ 
          error: "Validation failed", 
          details: validationResult.error.flatten().fieldErrors 
        });
      }

      const { host, port, username, password, deviceFamily } = validationResult.data;

      let output = '';

      await withSSH({ host, port, username, password }, async (ssh) => {
        output += `Connected to device at ${host}\n`;
        output += 'Executing factory reset...\n';

        switch (deviceFamily) {
          case 'airmax':
          case 'wave':
            // AirMax/Wave: Use cfgmtd -r to restore factory defaults to flash
            output += 'Running: cfgmtd -r\n';
            const airMaxResult = await ssh.exec('cfgmtd -r');
            output += `stdout: ${airMaxResult.stdout}\n`;
            if (airMaxResult.stderr) output += `stderr: ${airMaxResult.stderr}\n`;
            if (airMaxResult.exitCode !== 0) {
              throw new Error(`cfgmtd command failed with exit code ${airMaxResult.exitCode}`);
            }
            
            output += 'Rebooting device...\n';
            const airMaxRebootResult = await ssh.exec('reboot');
            if (airMaxRebootResult.stderr) output += `  reboot stderr: ${airMaxRebootResult.stderr}\n`;
            // Validate reboot execution:
            // - Exit code 0 or 255 (session close) = OK
            // - Undefined with no stderr errors = OK (normal session close during reboot)
            // - Any other exit code or stderr errors = FAIL
            const hasRebootError = airMaxRebootResult.stderr && 
              (airMaxRebootResult.stderr.toLowerCase().includes('error') || 
               airMaxRebootResult.stderr.toLowerCase().includes('failed') ||
               airMaxRebootResult.stderr.toLowerCase().includes('not found'));
            
            if (hasRebootError) {
              throw new Error(`Reboot command failed: ${airMaxRebootResult.stderr}`);
            }
            if (airMaxRebootResult.exitCode !== undefined && 
                airMaxRebootResult.exitCode !== 0 && 
                airMaxRebootResult.exitCode !== 255) {
              throw new Error(`Reboot command failed with exit code ${airMaxRebootResult.exitCode}`);
            }
            output += 'Device will reboot with factory defaults\n';
            break;

          case 'aircube':
            // AirCube: Use firstboot to reset to factory defaults
            output += 'Running: firstboot -y\n';
            const aircubeResult = await ssh.exec('firstboot -y');
            output += `stdout: ${aircubeResult.stdout}\n`;
            if (aircubeResult.stderr) output += `stderr: ${aircubeResult.stderr}\n`;
            if (aircubeResult.exitCode !== 0) {
              throw new Error(`firstboot command failed with exit code ${aircubeResult.exitCode}`);
            }
            
            output += 'Rebooting device...\n';
            const aircubeRebootResult = await ssh.exec('reboot');
            if (aircubeRebootResult.stderr) output += `  reboot stderr: ${aircubeRebootResult.stderr}\n`;
            // Validate reboot execution:
            // - Exit code 0 or 255 (session close) = OK
            // - Undefined with no stderr errors = OK (normal session close during reboot)
            // - Any other exit code or stderr errors = FAIL
            const hasAirCubeRebootError = aircubeRebootResult.stderr && 
              (aircubeRebootResult.stderr.toLowerCase().includes('error') || 
               aircubeRebootResult.stderr.toLowerCase().includes('failed') ||
               aircubeRebootResult.stderr.toLowerCase().includes('not found'));
            
            if (hasAirCubeRebootError) {
              throw new Error(`Reboot command failed: ${aircubeRebootResult.stderr}`);
            }
            if (aircubeRebootResult.exitCode !== undefined && 
                aircubeRebootResult.exitCode !== 0 && 
                aircubeRebootResult.exitCode !== 255) {
              throw new Error(`Reboot command failed with exit code ${aircubeRebootResult.exitCode}`);
            }
            output += 'Device will reboot with factory defaults\n';
            break;

          case 'edgemax':
            // EdgeMax: Use Vyatta shell context to execute configuration commands
            output += 'Running factory reset sequence...\n';
            const edgeCommand = 'vbash -ic "source /opt/vyatta/etc/functions/script-template; configure; load factory-default; commit; save; exit; reboot"';
            output += `> ${edgeCommand}\n`;
            const edgeResult = await ssh.exec(edgeCommand);
            output += `stdout: ${edgeResult.stdout}\n`;
            if (edgeResult.stderr) output += `stderr: ${edgeResult.stderr}\n`;
            // Check for errors in output and exit code
            if (edgeResult.exitCode && edgeResult.exitCode !== 0) {
              throw new Error(`EdgeMax factory reset failed with exit code ${edgeResult.exitCode}`);
            }
            if (edgeResult.stdout.toLowerCase().includes('error') || 
                edgeResult.stdout.toLowerCase().includes('failed') ||
                edgeResult.stdout.toLowerCase().includes('not found') ||
                edgeResult.stderr.toLowerCase().includes('error')) {
              throw new Error(`EdgeMax factory reset failed. Check output for details.`);
            }
            // Note: reboot may not return exit code as session closes, which is expected for successful reboot
            output += 'EdgeMax will reboot with factory defaults\n';
            break;

          case 'uisp-switch':
            // UISP Switch: Use factory reset command
            output += 'Running: factory-reset\n';
            const switchResult = await ssh.exec('factory-reset');
            output += `stdout: ${switchResult.stdout}\n`;
            if (switchResult.stderr) output += `stderr: ${switchResult.stderr}\n`;
            if (switchResult.exitCode !== 0) {
              throw new Error(`factory-reset command failed with exit code ${switchResult.exitCode}`);
            }
            output += 'UISP Switch will reset to factory defaults\n';
            break;
        }

        output += '\n✓ Factory reset command executed successfully\n';
        output += 'Note: Device will reboot and lose all configuration. Default credentials will be restored.\n';
      });

      res.json({ output, success: true });
    } catch (error) {
      console.error('Factory reset error:', error);
      res.status(500).json({ 
        error: "Factory reset failed", 
        message: error instanceof Error ? error.message : String(error)
      });
    }
  });

  // ===== Favorite Devices =====
  
  app.get("/api/favorites", requireAuth, async (req, res) => {
    try {
      const favorites = await storage.getAllFavoriteDevices();
      res.json(favorites);
    } catch (error) {
      console.error('Get favorites error:', error);
      res.status(500).json({ error: "Failed to fetch favorites" });
    }
  });

  app.post("/api/favorites", requireAuth, async (req, res) => {
    try {
      const validated = insertFavoriteDeviceSchema.parse(req.body);
      const favorite = await storage.createFavoriteDevice(validated);
      res.json(favorite);
    } catch (error) {
      console.error('Create favorite error:', error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Validation failed", details: error.flatten().fieldErrors });
      }
      res.status(400).json({ error: "Failed to create favorite" });
    }
  });

  app.patch("/api/favorites/:id", requireAuth, async (req, res) => {
    try {
      const { id } = req.params;
      const validated = insertFavoriteDeviceSchema.partial().parse(req.body);
      const favorite = await storage.updateFavoriteDevice(id, validated);
      res.json(favorite);
    } catch (error) {
      console.error('Update favorite error:', error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Validation failed", details: error.flatten().fieldErrors });
      }
      res.status(400).json({ error: "Failed to update favorite" });
    }
  });

  app.delete("/api/favorites/:id", requireAuth, async (req, res) => {
    try {
      const { id } = req.params;
      await storage.deleteFavoriteDevice(id);
      res.json({ success: true });
    } catch (error) {
      console.error('Delete favorite error:', error);
      res.status(500).json({ error: "Failed to delete favorite" });
    }
  });

  app.post("/api/favorites/:id/ping", requireAuth, async (req, res) => {
    try {
      const { id } = req.params;
      const favorite = await storage.getFavoriteDevice(id);
      
      if (!favorite) {
        return res.status(404).json({ error: "Favorite device not found" });
      }

      // Test SSH authentication
      let status: 'online' | 'offline' = 'offline';
      let errorMessage: string | undefined;
      
      try {
        await withSSH(
          {
            host: favorite.ip,
            port: 22,
            username: favorite.username,
            password: favorite.password,
            timeout: 10000
          },
          async () => {
            // Connection successful
            return true;
          }
        );
        status = 'online';
      } catch (error) {
        status = 'offline';
        errorMessage = error instanceof Error ? error.message : 'Connection failed';
      }

      await storage.updateFavoriteDevicePingStatus(
        id, 
        status, 
        new Date()
      );

      // Log ping activity
      await storage.createActivityLog({
        eventType: 'ping',
        deviceIp: favorite.ip,
        deviceType: favorite.deviceType || undefined,
        status,
        metadata: { favoriteId: id, error: errorMessage }
      });

      res.json({ 
        status, 
        timestamp: new Date(),
        error: errorMessage 
      });
    } catch (error) {
      console.error('Ping favorite error:', error);
      res.status(500).json({ error: "Ping failed", status: 'offline' });
    }
  });

  // ===== Default Credentials =====
  
  app.get("/api/credentials", requireAuth, async (req, res) => {
    try {
      const { family } = req.query;
      const credentials = family 
        ? await storage.getDefaultCredentialsByFamily(family as string)
        : await storage.getAllDefaultCredentials();
      res.json(credentials);
    } catch (error) {
      console.error('Get credentials error:', error);
      res.status(500).json({ error: "Failed to fetch credentials" });
    }
  });

  app.post("/api/credentials", requireAuth, async (req, res) => {
    try {
      const validated = z.object({
        label: z.string().min(1, "Label is required"),
        deviceFamily: z.string().nullable().optional(),
        username: z.string().min(1, "Username is required"),
        password: z.string().min(1, "Password is required"),
        notes: z.string().optional(),
      }).parse(req.body);
      
      const credential = await storage.createDefaultCredential(validated);
      res.json(credential);
    } catch (error) {
      console.error('Create credential error:', error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Validation failed", details: error.flatten().fieldErrors });
      }
      res.status(500).json({ error: "Failed to create credential" });
    }
  });

  app.put("/api/credentials/:id", requireAuth, async (req, res) => {
    try {
      const { id } = req.params;
      const validated = z.object({
        label: z.string().min(1).optional(),
        deviceFamily: z.string().nullable().optional(),
        username: z.string().min(1).optional(),
        password: z.string().min(1).optional(),
        notes: z.string().optional(),
      }).parse(req.body);
      
      const credential = await storage.updateDefaultCredential(id, validated);
      res.json(credential);
    } catch (error) {
      console.error('Update credential error:', error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Validation failed", details: error.flatten().fieldErrors });
      }
      res.status(500).json({ error: "Failed to update credential" });
    }
  });

  app.delete("/api/credentials/:id", requireAuth, async (req, res) => {
    try {
      const { id } = req.params;
      await storage.deleteDefaultCredential(id);
      res.json({ success: true });
    } catch (error) {
      console.error('Delete credential error:', error);
      res.status(500).json({ error: "Failed to delete credential" });
    }
  });

  // ===== Activity Logs =====
  
  app.get("/api/activity", requireAuth, async (req, res) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 50;
      const logs = await storage.getRecentActivityLogs(limit);
      res.json(logs);
    } catch (error) {
      console.error('Get activity logs error:', error);
      res.status(500).json({ error: "Failed to fetch activity logs" });
    }
  });

  // ===== System Operations =====
  
  // Factory Reset - clears all data and resets to admin/admin
  app.post("/api/system/factory-reset", requireAdmin, async (req, res) => {
    try {
      await storage.factoryReset();
      
      // Clear the session after factory reset
      req.session.destroy((err) => {
        if (err) {
          console.error('Session destruction error:', err);
        }
      });
      
      res.json({ 
        success: true, 
        message: "Factory reset completed. All data cleared and admin account reset to admin/admin." 
      });
    } catch (error) {
      console.error('Factory reset error:', error);
      res.status(500).json({ error: "Failed to perform factory reset" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
