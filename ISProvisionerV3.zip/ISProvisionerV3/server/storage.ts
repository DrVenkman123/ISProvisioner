import { db } from "../shared/db";
import { eq, desc, isNull, or } from "drizzle-orm";
import {
  type User,
  type InsertUser,
  users,
  type PopProfile,
  type InsertPopProfile,
  popProfiles,
  type ConfigTemplate,
  type InsertConfigTemplate,
  configTemplates,
  type Setting,
  type InsertSetting,
  settings,
  type ProvisionJob,
  type InsertProvisionJob,
  provisionJobs,
  type FavoriteDevice,
  type InsertFavoriteDevice,
  favoriteDevices,
  type DefaultCredential,
  type InsertDefaultCredential,
  defaultCredentials,
  type ActivityLog,
  type InsertActivityLog,
  activityLogs,
} from "@shared/schema";

export interface IStorage {
  // Users
  getAllUsers(): Promise<User[]>;
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: string, user: Partial<InsertUser>): Promise<User | undefined>;
  deleteUser(id: string): Promise<void>;

  // PoP Profiles
  getAllPopProfiles(): Promise<PopProfile[]>;
  getPopProfile(id: string): Promise<PopProfile | undefined>;
  createPopProfile(profile: InsertPopProfile): Promise<PopProfile>;
  updatePopProfile(id: string, profile: Partial<InsertPopProfile>): Promise<PopProfile>;
  deletePopProfile(id: string): Promise<void>;

  // Config Templates
  getAllConfigTemplates(): Promise<ConfigTemplate[]>;
  getConfigTemplate(id: string): Promise<ConfigTemplate | undefined>;
  getConfigTemplatesByFamily(family: string): Promise<ConfigTemplate[]>;
  createConfigTemplate(template: InsertConfigTemplate): Promise<ConfigTemplate>;
  updateConfigTemplate(id: string, template: Partial<InsertConfigTemplate>): Promise<ConfigTemplate>;
  deleteConfigTemplate(id: string): Promise<void>;

  // Settings
  getSetting(key: string): Promise<Setting | undefined>;
  setSetting(key: string, value: any): Promise<Setting>;
  getAllSettings(): Promise<Setting[]>;

  // Provision Jobs
  getAllProvisionJobs(): Promise<ProvisionJob[]>;
  getProvisionJob(id: string): Promise<ProvisionJob | undefined>;
  createProvisionJob(job: InsertProvisionJob): Promise<ProvisionJob>;
  updateProvisionJob(id: string, job: Partial<InsertProvisionJob>): Promise<ProvisionJob>;

  // Favorite Devices
  getAllFavoriteDevices(): Promise<FavoriteDevice[]>;
  getFavoriteDevice(id: string): Promise<FavoriteDevice | undefined>;
  createFavoriteDevice(device: InsertFavoriteDevice): Promise<FavoriteDevice>;
  updateFavoriteDevice(id: string, device: Partial<InsertFavoriteDevice>): Promise<FavoriteDevice>;
  updateFavoriteDevicePingStatus(id: string, status: string, time: Date): Promise<FavoriteDevice | undefined>;
  deleteFavoriteDevice(id: string): Promise<void>;

  // Default Credentials
  getAllDefaultCredentials(): Promise<DefaultCredential[]>;
  getDefaultCredential(id: string): Promise<DefaultCredential | undefined>;
  getDefaultCredentialsByFamily(family: string | null): Promise<DefaultCredential[]>;
  createDefaultCredential(credential: InsertDefaultCredential): Promise<DefaultCredential>;
  updateDefaultCredential(id: string, credential: Partial<InsertDefaultCredential>): Promise<DefaultCredential>;
  deleteDefaultCredential(id: string): Promise<void>;

  // Activity Logs
  getRecentActivityLogs(limit?: number): Promise<ActivityLog[]>;
  createActivityLog(log: InsertActivityLog): Promise<ActivityLog>;

  // System Operations
  factoryReset(): Promise<void>;
}

export class DbStorage implements IStorage {
  // Users
  async getAllUsers(): Promise<User[]> {
    return await db.select().from(users);
  }

  async getUser(id: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.id, id));
    return result[0];
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.username, username));
    return result[0];
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const result = await db.insert(users).values(insertUser).returning();
    return result[0];
  }

  async updateUser(id: string, updateData: Partial<InsertUser>): Promise<User | undefined> {
    const result = await db.update(users).set(updateData).where(eq(users.id, id)).returning();
    return result[0];
  }

  async deleteUser(id: string): Promise<void> {
    await db.delete(users).where(eq(users.id, id));
  }

  // PoP Profiles
  async getAllPopProfiles(): Promise<PopProfile[]> {
    return await db.select().from(popProfiles);
  }

  async getPopProfile(id: string): Promise<PopProfile | undefined> {
    const result = await db.select().from(popProfiles).where(eq(popProfiles.id, id));
    return result[0];
  }

  async createPopProfile(profile: InsertPopProfile): Promise<PopProfile> {
    const result = await db.insert(popProfiles).values(profile).returning();
    return result[0];
  }

  async updatePopProfile(id: string, profile: Partial<InsertPopProfile>): Promise<PopProfile> {
    const result = await db
      .update(popProfiles)
      .set(profile)
      .where(eq(popProfiles.id, id))
      .returning();
    return result[0];
  }

  async deletePopProfile(id: string): Promise<void> {
    await db.delete(popProfiles).where(eq(popProfiles.id, id));
  }

  // Config Templates
  async getAllConfigTemplates(): Promise<ConfigTemplate[]> {
    return await db.select().from(configTemplates);
  }

  async getConfigTemplate(id: string): Promise<ConfigTemplate | undefined> {
    const result = await db.select().from(configTemplates).where(eq(configTemplates.id, id));
    return result[0];
  }

  async getConfigTemplatesByFamily(family: string): Promise<ConfigTemplate[]> {
    return await db.select().from(configTemplates).where(eq(configTemplates.deviceFamily, family));
  }

  async createConfigTemplate(template: InsertConfigTemplate): Promise<ConfigTemplate> {
    const result = await db.insert(configTemplates).values(template).returning();
    return result[0];
  }

  async updateConfigTemplate(id: string, template: Partial<InsertConfigTemplate>): Promise<ConfigTemplate> {
    const result = await db
      .update(configTemplates)
      .set({ ...template, updatedAt: new Date() })
      .where(eq(configTemplates.id, id))
      .returning();
    return result[0];
  }

  async deleteConfigTemplate(id: string): Promise<void> {
    await db.delete(configTemplates).where(eq(configTemplates.id, id));
  }

  // Settings
  async getSetting(key: string): Promise<Setting | undefined> {
    const result = await db.select().from(settings).where(eq(settings.key, key));
    return result[0];
  }

  async setSetting(key: string, value: any): Promise<Setting> {
    const existing = await this.getSetting(key);
    
    if (existing) {
      const result = await db
        .update(settings)
        .set({ value, updatedAt: new Date() })
        .where(eq(settings.key, key))
        .returning();
      return result[0];
    } else {
      const result = await db
        .insert(settings)
        .values({ key, value })
        .returning();
      return result[0];
    }
  }

  async getAllSettings(): Promise<Setting[]> {
    return await db.select().from(settings);
  }

  // Provision Jobs
  async getAllProvisionJobs(): Promise<ProvisionJob[]> {
    return await db.select().from(provisionJobs);
  }

  async getProvisionJob(id: string): Promise<ProvisionJob | undefined> {
    const result = await db.select().from(provisionJobs).where(eq(provisionJobs.id, id));
    return result[0];
  }

  async createProvisionJob(job: InsertProvisionJob): Promise<ProvisionJob> {
    const result = await db.insert(provisionJobs).values(job).returning();
    return result[0];
  }

  async updateProvisionJob(id: string, job: Partial<InsertProvisionJob>): Promise<ProvisionJob> {
    const updates: any = { ...job };
    
    // Set completedAt timestamp when job finishes
    if (job.status === 'completed' || job.status === 'failed') {
      updates.completedAt = new Date();
    }
    
    const result = await db
      .update(provisionJobs)
      .set(updates)
      .where(eq(provisionJobs.id, id))
      .returning();
    return result[0];
  }

  // Favorite Devices
  async getAllFavoriteDevices(): Promise<FavoriteDevice[]> {
    return await db.select().from(favoriteDevices);
  }

  async getFavoriteDevice(id: string): Promise<FavoriteDevice | undefined> {
    const result = await db.select().from(favoriteDevices).where(eq(favoriteDevices.id, id));
    return result[0];
  }

  async createFavoriteDevice(device: InsertFavoriteDevice): Promise<FavoriteDevice> {
    const result = await db.insert(favoriteDevices).values(device).returning();
    return result[0];
  }

  async updateFavoriteDevice(id: string, device: Partial<InsertFavoriteDevice>): Promise<FavoriteDevice> {
    const result = await db
      .update(favoriteDevices)
      .set(device)
      .where(eq(favoriteDevices.id, id))
      .returning();
    return result[0];
  }

  async updateFavoriteDevicePingStatus(id: string, status: string, time: Date): Promise<FavoriteDevice | undefined> {
    const result = await db
      .update(favoriteDevices)
      .set({ lastPingStatus: status, lastPingTime: time })
      .where(eq(favoriteDevices.id, id))
      .returning();
    return result[0];
  }

  async deleteFavoriteDevice(id: string): Promise<void> {
    await db.delete(favoriteDevices).where(eq(favoriteDevices.id, id));
  }

  // Default Credentials
  async getAllDefaultCredentials(): Promise<DefaultCredential[]> {
    return await db.select().from(defaultCredentials);
  }

  async getDefaultCredential(id: string): Promise<DefaultCredential | undefined> {
    const result = await db.select().from(defaultCredentials).where(eq(defaultCredentials.id, id));
    return result[0];
  }

  async getDefaultCredentialsByFamily(family: string | null): Promise<DefaultCredential[]> {
    if (family === null) {
      // Return all credentials when no family specified
      return await db.select().from(defaultCredentials);
    }
    // Return credentials for specific family OR credentials that apply to all (deviceFamily is null)
    return await db
      .select()
      .from(defaultCredentials)
      .where(or(eq(defaultCredentials.deviceFamily, family), isNull(defaultCredentials.deviceFamily)));
  }

  async createDefaultCredential(credential: InsertDefaultCredential): Promise<DefaultCredential> {
    const result = await db.insert(defaultCredentials).values(credential).returning();
    return result[0];
  }

  async updateDefaultCredential(id: string, credential: Partial<InsertDefaultCredential>): Promise<DefaultCredential> {
    const updates: any = { ...credential, updatedAt: new Date() };
    const result = await db
      .update(defaultCredentials)
      .set(updates)
      .where(eq(defaultCredentials.id, id))
      .returning();
    return result[0];
  }

  async deleteDefaultCredential(id: string): Promise<void> {
    await db.delete(defaultCredentials).where(eq(defaultCredentials.id, id));
  }

  // Activity Logs
  async getRecentActivityLogs(limit: number = 50): Promise<ActivityLog[]> {
    return await db
      .select()
      .from(activityLogs)
      .orderBy(desc(activityLogs.createdAt))
      .limit(limit);
  }

  async createActivityLog(log: InsertActivityLog): Promise<ActivityLog> {
    const result = await db.insert(activityLogs).values(log).returning();
    return result[0];
  }

  // System Operations
  async factoryReset(): Promise<void> {
    // Delete all data from tables (in correct order to respect foreign keys)
    await db.delete(activityLogs);
    await db.delete(provisionJobs);
    await db.delete(favoriteDevices);
    await db.delete(defaultCredentials);
    await db.delete(configTemplates);
    await db.delete(popProfiles);
    await db.delete(settings);
    
    // Delete all users and recreate admin user
    await db.delete(users);
    
    // Create default admin user with admin/admin credentials
    const bcrypt = await import("bcryptjs");
    const hashedPassword = await bcrypt.hash("admin", 10);
    await db.insert(users).values({
      username: "admin",
      password: hashedPassword,
      role: "admin",
    });
  }
}

export const storage = new DbStorage();
