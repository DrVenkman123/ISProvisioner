# ISProvisioner Design Guidelines

## Design Approach
**System-Based Approach**: Enterprise productivity application inspired by Material Design and Carbon Design System principles, optimized for technical workflows and data-dense interfaces. Focus on clarity, efficiency, and reducing cognitive load for technicians performing repetitive configuration tasks.

## Core Design Principles
1. **Functional Hierarchy**: Information architecture prioritizes task completion speed
2. **Visual Clarity**: High contrast, clear labeling, and obvious interaction states
3. **Progressive Disclosure**: Complex configurations revealed as needed
4. **Error Prevention**: Visual feedback and validation before SSH execution
5. **Consistency**: Predictable patterns across all device types

---

## Typography System

### Font Family
- **Primary**: Inter or Roboto (via Google Fonts CDN)
- **Monospace**: JetBrains Mono or Fira Code (for SSH output, IP addresses, MAC addresses, technical data)

### Type Scale & Usage
- **Headings (H1)**: 32px / font-weight: 700 / Page titles, main dashboard header
- **Headings (H2)**: 24px / font-weight: 600 / Section headers, device type labels
- **Headings (H3)**: 18px / font-weight: 600 / Card titles, form section headers
- **Body Large**: 16px / font-weight: 400 / Primary content, form labels
- **Body**: 14px / font-weight: 400 / Secondary content, help text
- **Caption**: 12px / font-weight: 500 / Input labels, port numbers, meta information
- **Code/Technical**: 13px / font-weight: 400 / Monospace for IPs, MACs, SSH output

---

## Layout System

### Spacing Primitives
Use Tailwind units: **2, 3, 4, 6, 8, 12, 16** for consistent rhythm
- **Micro spacing** (gaps within components): 2, 3, 4
- **Component spacing** (between elements): 6, 8
- **Section spacing** (major divisions): 12, 16

### Grid Structure
- **Dashboard Layout**: Sidebar (280px fixed) + Main content area (flex-1)
- **Form Layouts**: Single column max-w-4xl for configuration forms
- **Port Grid**: CSS Grid with dynamic columns based on device (8-port = grid-cols-8, 24-port = grid-cols-12 md:grid-cols-24)
- **Card Grid**: grid-cols-1 md:grid-cols-2 lg:grid-cols-3 for device cards

### Container Widths
- **Sidebar**: 280px fixed width
- **Form Container**: max-w-4xl
- **Port Grid Container**: max-w-6xl
- **Full Dashboard**: w-full with proper padding (px-6, py-4)

---

## Component Library

### Navigation
**Sidebar Navigation**
- Fixed left sidebar with logo at top (h-16)
- Navigation items with icon + label, full-width buttons
- Active state: increased font-weight + visual indicator
- User profile section at bottom with role badge
- Collapsible on mobile (hamburger menu)

### Forms & Inputs

**Text Inputs**
- Height: h-10 (40px)
- Padding: px-3
- Border: 1.5px with rounded-lg (8px radius)
- Labels above input with required asterisk indicator
- Inline validation messaging below field

**Select Dropdowns**
- Custom styled select with chevron icon
- Match text input height and styling
- Group related options with optgroup headers

**Checkbox/Radio**
- Size: 20px × 20px
- Rounded corners (rounded for checkbox, rounded-full for radio)
- Clear checked state with checkmark/dot
- Label positioned inline-start with 8px gap

**Toggle Switches**
- Width: 44px, Height: 24px
- Animated transition (150ms)
- Use for binary settings (PoE on/off, Bridge mode, etc.)

### Port Grid Component
**Visual Structure**
- Grid of clickable squares representing physical ports
- Each square: 64px × 64px on desktop, 48px × 48px on mobile
- Port number displayed in top-left corner (caption text)
- Status indicator dot in top-right (connected/active state)
- Gap between ports: gap-2

**Port Configuration Modal**
- Triggered on port square click
- Displays: Port number (header), VLAN input, PoE mode selector (24v 2-pair / 24v 4-pair / None)
- Apply/Cancel actions at bottom

### Device Configuration Cards
**Structure**
- Card with rounded-xl borders (12px), shadow-md
- Device icon + name in header
- Configuration status badge (Configured / Not Configured)
- "Configure" primary button
- "View Config" secondary text button

### Data Display

**SSH Terminal Output**
- Monospace font in contained box
- Max height with scroll (max-h-96 overflow-y-auto)
- Line numbers optional for error reference
- Auto-scroll to bottom on new output

**Status Indicators**
- Pills/badges with icon + text
- Success: checkmark icon
- Warning: alert triangle icon  
- Error: X circle icon
- In Progress: spinning loader icon

### Buttons

**Primary Button**
- Height: h-10
- Padding: px-6
- Rounded: rounded-lg
- Font: font-semibold
- Full-width on mobile, auto width desktop

**Secondary Button**
- Same dimensions as primary
- Outlined style (border-2)
- Same border-radius and padding

**Icon Button**
- Square: 40px × 40px
- Centered icon (20px)
- Rounded: rounded-lg
- Use for actions like edit, delete, refresh

**Text Button**
- No background
- Underline on hover
- Use for tertiary actions

### Advanced Routing Configuration
**Interface Layout (for NanoStations)**
- Three-column layout showing WLAN0, LAN0, Bridge settings
- Each column has collapsible sections
- Visual connection lines showing interface relationships (optional, use border-l to indicate hierarchy)
- Quick presets at top (Router mode, Bridge mode, Access Point)

### Modals/Overlays
**Structure**
- Centered overlay with backdrop blur
- Max-width: max-w-2xl
- Padding: p-6
- Header with title + close button (×)
- Content area with scroll if needed (max-h-[80vh])
- Footer with action buttons aligned right

### Empty States
- Centered icon (96px) + heading + description
- Primary action button below
- Use when no devices, no configs uploaded, etc.

---

## Animations

**Use Sparingly - Only for Feedback**
- Modal entrance/exit: 200ms fade + scale (0.95 → 1)
- Toast notifications: slide in from top-right
- Button click: subtle scale (0.98) on active state
- Tab switching: 150ms fade between panels
- NO decorative animations, parallax, or scroll effects

---

## Specific Page Layouts

### Login Page
- Centered card (max-w-md)
- Logo above form
- Email + Password inputs stacked
- "Sign In" primary button
- "First time? Register" link below
- Clean, minimal, professional

### Dashboard (Main View)
- Sidebar: Logo, navigation (Dashboard, Devices, Configs, Users [admin only], Settings)
- Main area header: Page title + action button (e.g., "New Device")
- Content: Device cards grid OR active configuration view

### Device Configuration View
- Breadcrumb navigation (Dashboard > Configure NanoBeam)
- Device info summary card at top
- Configuration form in sections with clear headers:
  - Basic Settings (Device name, IP configuration)
  - Network Settings (VLAN, Bridge/Router mode)
  - PoE Settings (if applicable)
  - Advanced Routing (WLAN0/LAN0 for NanoStations)
- Live SSH output terminal at bottom (collapsible)
- Sticky footer with "Cancel" and "Apply Configuration" buttons

### Switch Port Configuration (UISP-S)
- Device selector at top
- Port grid visualization below (responsive to port count)
- Bulk actions: "Apply VLAN to all ports", "Reset all"
- Selected port(s) highlighted
- Configuration panel slides in from right when port(s) selected

### Config Management Page
- Upload area at top (drag-drop + browse button)
- List of uploaded configs as cards with:
  - Config name, device type badge, upload date
  - Actions: Download, Delete, Apply to Device
- Search/filter by device type

### User Management (Admin)
- Table layout with columns: Name, Email, Role, Status, Actions
- "Add User" button top-right
- Inline edit for role changes
- Delete confirmation modal

---

## Accessibility

- All form inputs have associated labels (for/id pairs)
- Keyboard navigation throughout (tab order logical)
- Focus indicators visible (ring-2 ring-offset-2)
- ARIA labels on icon-only buttons
- Error messages announced to screen readers
- Sufficient contrast ratios (WCAG AA minimum)
- Port grid keyboard navigable (arrow keys between ports)

---

## Images
No hero images needed - this is a utility application. Only icons used:
- Device type icons (NanoBeam, NanoStation, AirCube, etc.)
- Status icons (checkmark, warning, error)
- Navigation icons (dashboard, devices, settings, users)
- Use icon library: Heroicons via CDN (solid + outline variants)